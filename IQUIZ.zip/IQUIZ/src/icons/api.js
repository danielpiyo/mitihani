//const express = require('express');
//const router = express.Router();

/* GET api listing. */
//router.get('/', (req, res) => {
 // res.send('api works');
//}); 


const express = require('express');
const app = express();
const router = express.Router();
const bodyParser = require('body-parser');
const oracledb = require('oracledb');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const config = require(__dirname + '/config.js');
const async = require('async');

//////////////paypal trial


const querystring = require("querystring");
const request = require("request");

/**
 * @const {boolean} sandbox Indicates if the sandbox endpoint is used.
 */
const sandbox = true;

/** Production Postback URL */
const PRODUCTION_VERIFY_URI = "https://ipnpb.paypal.com/cgi-bin/webscr";
/** Sandbox Postback URL */
const SANDBOX_VERIFY_URI = "https://ipnpb.sandbox.paypal.com/cgi-bin/webscr";

//////////////


// Use body parser to parse JSON body
router.use(bodyParser.json());

const connAttrs = {
    "user": "CMAST",
    "password": "INSYNCCMAST",
    "connectString": "173.255.200.221/XE"
}


/////////////////paypal trial function
function getPaypalURI() {
  return sandbox ? SANDBOX_VERIFY_URI : PRODUCTION_VERIFY_URI;
}
/////////////////////////////

// Http Method: GET
// URI        : /user_profiles
// Read all the user profiles
router.get('/', function (req, res) {
    res.sendfile('/')
});

router.post('/paypal2', function (req, res) {
    //res.sendfile('/')
    var data = req.body.data;

    res.send(' Done ');
    console.log("Data", res.send(JSON.stringify(data)));
    console.log("Paypal Imefika", data);
});

//
router.get('/cat', function (req, res) {
    "use strict";

    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }

        connection.execute("SELECT TO_CHAR(CLASS) CLASS_ID, DESCRIPTION FROM CGIB.CLASS WHERE CLASS_ACTIVE = 'Y' ORDER BY CLASS", {}, {
            outFormat: oracledb.OBJECT // Return the result as Object
        }, function (err, result) {
            if (err) {
                res.set('Content-Type', 'application/json');
                res.status(500).send(JSON.stringify({
                    status: 500,
                    message: "Error getting the products",
                    detailed_message: err.message
                }));
            } else {

                res.contentType('application/json').status(200);
                res.send(JSON.stringify(result.rows));
            }
            // Release the connection
            connection.release(
                function (err) {
                    if (err) {
                        console.error(err.message);
                    } else {
                        console.log("GET /cat : Connection released");
                    }
                });
        });

    });
});

//selecting class group of the products
router.get('/cls/:CLASS_ID', function (req, res) {
    "use strict";

    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }

        connection.execute("SELECT CLASSGRP CODE, GROUP_DESCRIPTION DESCRIPTION FROM CGIB.CLASSGRP WHERE CLASS = :CLASS_ID", [req.params.CLASS_ID], {
            outFormat: oracledb.OBJECT // Return the result as Object
        }, function (err, result) {
            if (err || result.rows.length < 1) {
                res.set('Content-Type', 'application/json');
                var status = err ? 500 : 404;
                res.status(status).send(JSON.stringify({
                    status: status,
                    message: err ? "Error getting the that PRODUCT" : "PRODUCT doesn't exist",
                    detailed_message: err ? err.message : ""
                }));
            } else {
                res.contentType('application/json').status(200).send(JSON.stringify(result.rows));
            }
            // Release the connection
            connection.release(
                function (err) {
                    if (err) {
                        console.error(err.message);
                    } else {
                        console.log("GET /cls/" + req.params.CLASS_ID + " : Connection released");
                    }
                });
        });
    });
});

//selecting sub section of the products
///
router.get('/sub/:CLASS_ID/:CODE', function (req, res) {
    "use strict";

    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }

        connection.execute("SELECT SECTION_NO, SECTION_DESCRIPTION FROM CGIB.CLASSSECT WHERE CLASS = :CLASS_ID AND CLASSGRP = :CODE", [req.params.CLASS_ID, req.params.CODE], {
            outFormat: oracledb.OBJECT // Return the result as Object
        }, function (err, result) {
            if (err || result.rows.length < 1) {
                res.set('Content-Type', 'application/json');
                var status = err ? 500 : 404;
                res.status(status).send(JSON.stringify({
                    status: status,
                    message: err ? "Error getting the that PRODUCT" : "PRODUCT doesn't exist",
                    detailed_message: err ? err.message : ""
                }));
            } else {
                res.contentType('application/json').status(200).send(JSON.stringify(result.rows));
            }
            // Release the connection
            connection.release(
                function (err) {
                    if (err) {
                        console.error(err.message);
                    } else {
                        console.log("GET /sub/" + req.params.CLASS_ID + req.params.CODE + " : Connection released");
                    }
                });
        });
    });
});


//
router.get('/pro', function (req, res) {
    "use strict";

    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }

        connection.execute("SELECT * FROM CGIB.ONL_VIEW_PRODUCTS", {}, {
            outFormat: oracledb.OBJECT // Return the result as Object
        }, function (err, result) {
            if (err) {
                res.set('Content-Type', 'application/json');
                res.status(500).send(JSON.stringify({
                    status: 500,
                    message: "Error getting the products",
                    detailed_message: err.message
                }));
            } else {
                
                res.contentType('application/json').status(200);
                res.send(JSON.stringify(result.rows));
            }
            // Release the connection
            connection.release(
                function (err) {
                    if (err) {
                        console.error(err.message);
                    } else {
                        console.log("GET /pro : Connection released");
                    }
                });
        });
        
    });
});

// Http method: GET
// URI        : /client/:client_number
// Read the active policies of user given in :client_number
router.get('/client/:CLIENT_NUMBER', function (req, res) {
    "use strict";

    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }

        connection.execute("SELECT * FROM CGIB.ONL_VIEW_ACTIVE_POLICY WHERE client_number = :client_number", [req.params.CLIENT_NUMBER], {
            outFormat: oracledb.OBJECT // Return the result as Object
        }, function (err, result) {
            if (err || result.rows.length < 1) {
                res.set('Content-Type', 'application/json');
                var status = err ? 500 : 404;
                res.status(status).send(JSON.stringify({
                    status: status,
                    message: err ? "Error getting the Policies for this Client" : "Client policy doesn't exist",
                    detailed_message: err ? err.message : ""
                }));
            } else {
                res.contentType('application/json').status(200).send(JSON.stringify(result.rows));
            }
            // Release the connection
            connection.release(
                function (err) {
                    if (err) {
                        console.error(err.message);
                    } else {
                        console.log("GET /client/" + req.params.CLIENT_NUMBER + " : Connection released");
                    }
                });
        });
    });
});
///////////////////

/////
/// Nature of Accident 
router.get('/nature', function (req, res) {
    "use strict";

    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }

        connection.execute("SELECT CODE_DESCRIPTION, CODE_ID FROM CGIB.CGI_GENERAL_CODES WHERE CODE_TYPE = 'NATURE_OF_ACCIDENT' AND NVL(FROZEN,'X') != 'Y'", {}, {
            outFormat: oracledb.OBJECT // Return the result as Object
        }, function (err, result) {
            if (err) {
                res.set('Content-Type', 'application/json');
                res.status(500).send(JSON.stringify({
                    status: 500,
                    message: "Error getting the Nature of Accident",
                    detailed_message: err.message
                }));
            } else {

                res.contentType('application/json').status(200);
                res.send(JSON.stringify(result.rows));
            }
            // Release the connection
            connection.release(
                function (err) {
                    if (err) {
                        console.error(err.message);
                    } else {
                        console.log("GET /nature : Connection released");
                    }
                });
        });

    });
});

/////
//////Accident causes Selection
router.get('/causes', function (req, res) {
    "use strict";

    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }

        connection.execute("SELECT CODE_DESCRIPTION, CODE_ID FROM CGIB.CGI_GENERAL_CODES WHERE CODE_TYPE = 'CLAIM_CAUSE_CODES' AND NVL(FROZEN,'X') != 'Y'", {}, {
            outFormat: oracledb.OBJECT // Return the result as Object
        }, function (err, result) {
            if (err) {
                res.set('Content-Type', 'application/json');
                res.status(500).send(JSON.stringify({
                    status: 500,
                    message: "Error getting the Causes of Accident",
                    detailed_message: err.message
                }));
            } else {

                res.contentType('application/json').status(200);
                res.send(JSON.stringify(result.rows));
            }
            // Release the connection
            connection.release(
                function (err) {
                    if (err) {
                        console.error(err.message);
                    } else {
                        console.log("GET /causes : Connection released");
                    }
                });
        });

    });
});



///////////////////////////
////////////////////////// More details about my query
router.get('/morequery/:CUST_CODE/:INQ_ID', function (req, res) {
    "use strict";

    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }

        connection.execute("SELECT INQ_ID, CUST_CODE, CREATED_DATE, ISSUE_CATEGORY, NARRATION, SOLUTION_DESCRIPTION, SOLUTION_DATE FROM CGIB.CGI_ONLINE_INQUIRY WHERE CUST_CODE = :CUST_CODE AND INQ_ID = :INQ_ID", [req.params.CUST_CODE, req.params.INQ_ID], {
            outFormat: oracledb.OBJECT // Return the result as Object
        }, function (err, result) {
            if (err || result.rows.length < 1) {
                res.set('Content-Type', 'application/json');
                var status = err ? 500 : 404;
                res.status(status).send(JSON.stringify({
                    status: status,
                    message: err ? "Error getting the Query" : "Queries doesn't exist",
                    detailed_message: err ? err.message : ""
                }));
            } else {
                res.contentType('application/json').status(200).send(JSON.stringify(result.rows));
            }
            // Release the connection
            connection.release(
                function (err) {
                    if (err) {
                        console.error(err.message);
                    } else {
                        console.log("GET /morequery/" + req.params.CUST_CODE + req.params.INQ_ID + " : Connection released");
                    }
                });
        });
    });
});


////////////////////////
//////////////////////GETTING TOWNS
// 
router.get('/town/:COUNTRY_CODE', function (req, res) {
    "use strict";

    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }

        connection.execute("SELECT * FROM CMAST.CMS_TOWNS WHERE COUNTRY_CODE = :COUNTRY_CODE ORDER BY TWN_NAME ASC", [req.params.COUNTRY_CODE], {
            outFormat: oracledb.OBJECT // Return the result as Object
        }, function (err, result) {
            if (err || result.rows.length < 1) {
                res.set('Content-Type', 'application/json');
                var status = err ? 500 : 404;
                res.status(status).send(JSON.stringify({
                    status: status,
                    message: err ? "Error getting the list of Towns" : "Towns doesn't exist",
                    detailed_message: err ? err.message : ""
                }));
            } else {
                res.contentType('application/json').status(200).send(JSON.stringify(result.rows));
            }
            // Release the connection
            connection.release(
                function (err) {
                    if (err) {
                        console.error(err.message);
                    } else {
                        console.log("GET /town/" + req.params.COUNTRY_CODE + " : Connection released");
                    }
                });
        });
    });
});

///////////////////////////
////////////////////////// Getting Countries
//viewing products from db
router.get('/country', function (req, res) {
    "use strict";

    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }

        connection.execute("SELECT * FROM CMAST.CMS_COUNTRIES ORDER BY COUNTRY_NAME ASC", {}, {
            outFormat: oracledb.OBJECT // Return the result as Object
        }, function (err, result) {
            if (err) {
                res.set('Content-Type', 'application/json');
                res.status(500).send(JSON.stringify({
                    status: 500,
                    message: "Error getting Countries",
                    detailed_message: err.message
                }));
            } else {

                res.contentType('application/json').status(200);
                res.send(JSON.stringify(result.rows));
            }
            // Release the connection
            connection.release(
                function (err) {
                    if (err) {
                        console.error(err.message);
                    } else {
                        console.log("GET /country : Connection released");
                    }
                });
        });

    });
});


////////////////////
///////////////////////// Iquiz Subject listing
router.get('/iquiztest/:ENTITY_SYS_ID/:CODE_ID/:SUBJECT_CODE', function (req, res) {
    "use strict";

    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }

        connection.execute("SELECT * FROM IQUIZ.IQV_STUDENT_QUIZ_ATTEMPTS WHERE ENTITY_SYS_ID = :ENTITY_SYS_ID AND CLASS_LEVEL_CODE = :CODE_ID AND SUBJECT_CODE = :SUBJECT_CODE AND ACTIVE_YN = 'Y' order by QUIZ_AGE, NO_OF_ATTEMPTS  ASC", [req.params.ENTITY_SYS_ID, req.params.CODE_ID, req.params.SUBJECT_CODE], {
            outFormat: oracledb.OBJECT // Return the result as Object
        }, function (err, result) {
            if (err || result.rows.length < 1) {
                res.set('Content-Type', 'application/json');
                var status = err ? 500 : 404;
                res.status(status).send(JSON.stringify({
                    status: status,
                    message: err ? "Error getting that QUIZ" : "QUIZ doesn't exist",
                    detailed_message: err ? err.message : ""
                }));
            } else {
                res.contentType('application/json').status(200).send(JSON.stringify(result.rows));
            }
            // Release the connection
            connection.release(
                function (err) {
                    if (err) {
                        console.error(err.message);
                    } else {
                        console.log("GET /iquiztest/" + req.params.ENTITY_SYS_ID + '/' + req.params.CODE_ID + '/' + req.params.SUBJECT_CODE + " : Connection released");
                    }
                });
        });
    });
});

////////////////////
///////////////////////// Iquiz Subject listing
router.get('/iquizsubj/:CODE_ID', function (req, res) {
    "use strict";

    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }

        connection.execute("SELECT DISTINCT SUBJECT_CODE FROM IQUIZ.IQ_QUIZ_HEADERS WHERE CLASS_LEVEL_CODE = :CODE_ID AND NVL(ACTIVE_YN,'X') = 'Y'", [req.params.CODE_ID], {
            outFormat: oracledb.OBJECT // Return the result as Object
        }, 
         function (err, result) {
            if (err || result.rows.length < 1) {
                res.set('Content-Type', 'application/json');
                var status = err ? 500 : 404;
                res.status(status).send(JSON.stringify({
                    status: status,
                    message: err ? "Error getting that subject" : " Quizzes for this class/Subject are Comming Soon",
                    detailed_message: err ? err.message : ""
                }));
                

            } else {
                res.contentType('application/json').status(200).send(JSON.stringify(result.rows));
            }
            // Release the connection
            connection.release(
                function (err) {
                    if (err) {
                        console.error(err.message);
                    } else {
                        console.log("GET /iquizsubj/" + req.params.CODE_ID + " : Connection released");
                    }
                });
        });
    });
});

////////////////////////////
//////////////////////////  IQUIZ CLASS DETAILS

router.get('/classiquizdet/:CODE_ID', function (req, res) {
    "use strict";

    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }

        connection.execute("SELECT * FROM IQUIZ.IQ_GENERAL_CODES WHERE CODE_TYPE = 'CLASS_LEVEL_CODE' and CODE_HINT_1 = :CODE_ID ORDER BY CODE_SEQUENCE", [req.params.CODE_ID], {
            outFormat: oracledb.OBJECT // Return the result as Object
        }, function (err, result) {
            if (err || result.rows.length < 1) {
                res.set('Content-Type', 'application/json');
                var status = err ? 500 : 404;
                res.status(status).send(JSON.stringify({
                    status: status,
                    message: err ? "Error getting the that Class details" : "class Details doesn't exist",
                    detailed_message: err ? err.message : ""
                }));
            } else {
                res.contentType('application/json').status(200).send(JSON.stringify(result.rows));
            }
            // Release the connection
            connection.release(
                function (err) {
                    if (err) {
                        console.error(err.message);
                    } else {
                        console.log("GET /classiquizdet/" + req.params.CODE_ID + " : Connection released");
                    }
                });
        });
    });
});

/////////////////////
//////////////////////// IQUIZ CLASS GENERAL
//viewing CLASS from db
router.get('/classiquiz', function (req, res) {
    "use strict";

    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }

        connection.execute("SELECT CODE_ID, CODE_DESCRIPTION FROM  IQUIZ.IQ_GENERAL_CODES WHERE CODE_TYPE = 'CLASS_CATEGORY_CODE' ORDER BY CODE_SEQUENCE", {}, {
            outFormat: oracledb.OBJECT // Return the result as Object
        }, function (err, result) {
            if (err) {
                res.set('Content-Type', 'application/json');
                res.status(500).send(JSON.stringify({
                    status: 500,
                    message: "Error getting the Class list",
                    detailed_message: err.message
                }));
            } else {

                res.contentType('application/json').status(200);
                res.send(JSON.stringify(result.rows));
            }
            // Release the connection
            connection.release(
                function (err) {
                    if (err) {
                        console.error(err.message);
                    } else {
                        console.log("GET /classiquiz : Connection released");
                    }
                });
        });

    });
});


////////////////
////////////////// Viewing More details of quatation
///Viewing Quotations as per the client no
router.get('/morequote/:CLIENT_NUMBER/:DCON_NO', function (req, res) {
    "use strict";

    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }

        connection.execute("SELECT * FROM CGIB.ONL_VIEW_QUOTATIONS WHERE client_number = :client_number AND dcon_no = :dcon_no", [req.params.CLIENT_NUMBER, req.params.DCON_NO], {
            outFormat: oracledb.OBJECT // Return the result as Object
        }, function (err, result) {
            if (err || result.rows.length < 1) {
                res.set('Content-Type', 'application/json');
                var status = err ? 500 : 404;
                res.status(status).send(JSON.stringify({
                    status: status,
                    message: err ? "Error getting the that Quotation" : "Quotation doesn't exist",
                    detailed_message: err ? err.message : ""
                }));
            } else {
                res.contentType('application/json').status(200).send(JSON.stringify(result.rows));
            }
            // Release the connection
            connection.release(
                function (err) {
                    if (err) {
                        console.error(err.message);
                    } else {
                        console.log("GET /morequote/" + req.params.CLIENT_NUMBER + req.params.DCON_NO + " : Connection released");
                    }
                });
        });
    });
});


/////////////////
////////////////// Viewing More details of quatation
///Viewing Quotations as per the client no
router.get('/morepol/:CLIENT_NUMBER/:DCON_NO', function (req, res) {
    "use strict";

    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }

        connection.execute("SELECT * FROM CGIB.ONL_VIEW_ACTIVE_POLICY WHERE client_number = :client_number AND dcon_no = :dcon_no", [req.params.CLIENT_NUMBER, req.params.DCON_NO], {
            outFormat: oracledb.OBJECT // Return the result as Object
        }, function (err, result) {
            if (err || result.rows.length < 1) {
                res.set('Content-Type', 'application/json');
                var status = err ? 500 : 404;
                res.status(status).send(JSON.stringify({
                    status: status,
                    message: err ? "Error getting the that Policy" : "Policy doesn't exist",
                    detailed_message: err ? err.message : ""
                }));
            } else {
                res.contentType('application/json').status(200).send(JSON.stringify(result.rows));
            }
            // Release the connection
            connection.release(
                function (err) {
                    if (err) {
                        console.error(err.message);
                    } else {
                        console.log("GET /morepol/" + req.params.CLIENT_NUMBER + req.params.DCON_NO + " : Connection released");
                    }
                });
        });
    });
});



///////
//////Claim submission 

router.post('/claim', function (req, res) {
    "use strict";
    console.log('req.body', req.body);
    if ("application/json" !== req.get('Content-Type')) {
        res.set('Content-Type', 'application/json').status(415).send(JSON.stringify({
            status: 415,
            message: "Wrong content-type. Only application/json is supported",
            detailed_message: null
        }));
        return;
    }
    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json').status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }
        console.log('req.body', req.body);
        connection.execute("INSERT INTO CGIB.CGI_ONLINE_NOTIF_CLAIMS (RISK_ID, PDOC_NO, OCCURRENCE_DATE, CLASS_CODE, POLICY_NO, DCON_NO, CLAIMANT, NARRATION, CAUSE_CODE, NATURE_OF_ACCIDENT, CLAIM_LOCATION, ESTIMATED_LOSS, CREATED_BY, DATE_NOTIFIED, CREATED_DATE) VALUES " +
            "(:RISK_ID, :PDOC_NO, TO_DATE(:OCCURRENCE_DATE,'YYYY-MM-DD'), :CLASS_CODE, :POLICY_NO, :DCON_NO, :CLAIMANT, :NARRATION, :CAUSE_CODE, :NATURE_OF_ACCIDENT, :CLAIM_LOCATION, :ESTIMATED_LOSS, :CREATED_BY, SYSDATE, SYSDATE)",
            [req.body.RISK_ID, req.body.PDOC_NO, req.body.OCCURRENCE_DATE, req.body.CLASS_CODE, req.body.POLICY_NO, req.body.DCON_NO, req.body.CLAIMANT, req.body.NARRATION, req.body.CAUSE_CODE, req.body.NATURE_OF_ACCIDENT, req.body.CLAIM_LOCATION, req.body.ESTIMATED_LOSS, req.body.CLAIMANT,],
            {
                autoCommit: true,
                outFormat: oracledb.OBJECT // Return the result as Object
            },
            function (err, result) {
                if (err) {
                    // Error
                    res.set('Content-Type', 'application/json');
                    res.status(400).send(JSON.stringify({
                        status: 400,
                        message: err.message.indexOf("ORA-00001") > -1 ? "Problem posting your Claim contact systemadmin" : "Input Error",
                        detailed_message: err.message
                    }));
                } else {
                    // Successfully created the resource
                    res.status(201).set('Location', '/claims/' + req.body.POLICY_NO).end();
                }
                // Release the connection
                connection.release(
                    function (err) {
                        if (err) {
                            console.error(err.message);
                        } else {
                            console.log("POST /claim: Connection released");
                        }
                    });
            });
    });
});


/////////////////
////////////////// 
///Viewing CLAIMS as per the client no
router.get('/myclaims/:CLIENT_NUMBER', function (req, res) {
    "use strict";

    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }

        connection.execute(" SELECT * FROM CGIB.CGI_ONLINE_NOTIF_CLAIMS A, CGIB.ONL_VIEW_ACTIVE_POLICY B WHERE A.POLICY_NO = B.POLICY_NO AND B.CLIENT_NUMBER = :client_number", [req.params.CLIENT_NUMBER], {
            outFormat: oracledb.OBJECT // Return the result as Object
        }, function (err, result) {
            if (err || result.rows.length < 1) {
                res.set('Content-Type', 'application/json');
                var status = err ? 500 : 404;
                res.status(status).send(JSON.stringify({
                    status: status,
                    message: err ? "Error getting the Claims for this client" : "You do not Have claims",
                    detailed_message: err ? err.message : ""
                }));
            } else {
                res.contentType('application/json').status(200).send(JSON.stringify(result.rows));
            }
            // Release the connection
            connection.release(
                function (err) {
                    if (err) {
                        console.error(err.message);
                    } else {
                        console.log("GET /myclaims/" + req.params.CLIENT_NUMBER + " : Connection released");
                    }
                });
        });
    });
});



/////
///// Pulling Risks based on policies dcon_no fro each client.

router.get('/risk/:DCON_NO', function (req, res) {
    "use strict";

    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }

        connection.execute("SELECT * FROM CGIB.CGI_PROV_RISKS WHERE DCON_NO = :DCON_NO", [req.params.DCON_NO], {
            outFormat: oracledb.OBJECT // Return the result as Object
        }, function (err, result) {
            if (err || result.rows.length < 1) {
                res.set('Content-Type', 'application/json');
                var status = err ? 500 : 404;
                res.status(status).send(JSON.stringify({
                    status: status,
                    message: err ? "Error getting the Risks for this Client" : "Client Risk doesn't exist",
                    detailed_message: err ? err.message : ""
                }));
            } else {
                res.contentType('application/json').status(200).send(JSON.stringify(result.rows));
            }
            // Release the connection
            connection.release(
                function (err) {
                    if (err) {
                        console.error(err.message);
                    } else {
                        console.log("GET /risk/" + req.params.DCON_NO + " : Connection released");
                    }
                });
        });
    });
});



///Viewing Quotations as per the client no
router.get('/myquote/:CLIENT_NUMBER', function (req, res) {
    "use strict";

    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }

        connection.execute("SELECT * FROM CGIB.ONL_VIEW_QUOTATIONS WHERE client_number = :client_number", [req.params.CLIENT_NUMBER], {
            outFormat: oracledb.OBJECT // Return the result as Object
        }, function (err, result) {
            if (err || result.rows.length < 1) {
                res.set('Content-Type', 'application/json');
                var status = err ? 500 : 404;
                res.status(status).send(JSON.stringify({
                    status: status,
                    message: err ? "Error getting the that Quotation" : "Quotation doesn't exist",
                    detailed_message: err ? err.message : ""
                }));
            } else {
                res.contentType('application/json').status(200).send(JSON.stringify(result.rows));
            }
            // Release the connection
            connection.release(
                function (err) {
                    if (err) {
                        console.error(err.message);
                    } else {
                        console.log("GET /myquote/" + req.params.CLIENT_NUMBER + " : Connection released");
                    }
                });
        });
    });
});

// Http method: POST
// URI        : /user inquiries


router.post('/query', function (req, res) {
    "use strict";
    console.log('req.body',req.body);
    if ("application/json" !== req.get('Content-Type')) {
        res.set('Content-Type', 'application/json').status(415).send(JSON.stringify({
            status: 415,
            message: "Wrong content-type. Only application/json is supported",
            detailed_message: null
        }));
        return;
    }
    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json').status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }
        console.log('req.body',req.body);
        connection.execute("INSERT INTO CGIB.CGI_ONLINE_INQUIRY (CUST_CODE, ISSUE_CATEGORY, NARRATION, EMAIL) VALUES " +
            "(:CUST_CODE, :ISSUE_CATEGORY, :NARRATION, :EMAIL)",
             [req.body.CUST_CODE, req.body.ISSUE_CATEGORY, req.body.NARRATION,  req.body.EMAIL,],
              {
                autoCommit: true,
                outFormat: oracledb.OBJECT // Return the result as Object
            },
            function (err, result) {
                if (err) {
                    // Error
                    res.set('Content-Type', 'application/json');
                    res.status(400).send(JSON.stringify({
                        status: 400,
                        message: err.message.indexOf("ORA-00001") > -1 ? "Problem posting your query contact systemadmin" : "Input Error",
                        detailed_message: err.message
                    }));
                } else {
                    // Successfully created the resource
                    res.status(201).set('Location', '/query/' + req.body.ISSUE_CATEGORY).end();
                }
                // Release the connection
                connection.release(
                    function (err) {
                        if (err) {
                            console.error(err.message);
                        } else {
                            console.log("POST /query: Connection released");
                        }
                    });
            });
    });
});

//Http method: login
//URI : /login


router.post('/login', function (req, res, next) {
    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }
        console.log('req.body',req.body);

            connection.execute(

                'select cust_code as "cust_code", ' +

                '   email as "email", ' +

                '   online_password as "password", ' +

                '   mobile_no as "mobile_no", ' +

                '   photo as "photo", ' +

                '  telephone_no as "telephone_no", ' +

                '   town as "town", ' +

                '   postal_code as "postal_code", ' +

                '   postal_address as "postal_address", ' +

                '   id_type as "id_type", ' +

                '   id_number as "id_number", ' +

                '   first_name as "first_name", ' +

                '  middle_name as "middle_name", ' +

                '   last_name as "last_name", ' +

                '   country as "country", ' +

                '  contact_person as "contact_person", ' +

                '   pin_number as "pin_number", ' +

                '   gender as "gender", ' +

                '  occup_description as "occup_description" ' +

                'from cms_customers ' +

                'where email = :email',

                {

                    email: req.body.email.toLowerCase()

                },

                {

                    outFormat: oracledb.OBJECT

                },

                function (err, result) {
                    if (err || result.rows.length < 1) {
                        res.set('Content-Type', 'application/json');
                        var status = err ? 500 : 404;
                        res.status(status).send(JSON.stringify({
                            status: status,
                            message: err ? "Error getting the that email" : "Email you have entered is Incorrect. Kindly Try Again. or Contact systemadmin",
                            detailed_message: err ? err.message : ""
                        }));

                        return next(err);

                    }  

                    user = result.rows[0];
                    
                  
                    

                    bcrypt.compare(req.body.password, user.password, function(err, pwMatch) {

                        var payload;

                        if (err) {

                            return next(err);

                        }

                        if (!pwMatch) {

                            res.status(401).send({message: 'Wrong Password. please Try Again .'});

                            return;

                        }

                        payload = {

                            sub: user.email,
                          
                           // password : user.password,

                            cust_code: user.cust_code,

                            photo: user.photo,

                            mobile_no: user.mobile_no,

                            telephone_no: user.telephone_no,

                            town: user.town,

                            postal_code: user.postal_code,

                            postal_address: user.postal_address,

                            id_type: user.id_type,

                            id_number: user.id_number,

                            first_name: user.first_name,

                            middle_name: user.middle_name,

                            last_name: user.last_name,

                            gender : user.gender,

                            pin_number: user.pin_number,

                            contact_person: user.contact_person,

                            occup_description: user.occup_description,

                            country: user.country



                        };

                        res.status(200).json({

                            user: user,
                            
                            cust_code: user.cust_code,
                            
                            email: user.email,

                           // password : user.password,

                            photo: user.photo,

                            mobile_no: user.mobile_no,

                            telephone_no: user.telephone_no,

                            town: user.town,

                            postal_code: user.postal_code,

                            postal_address: user.postal_address,

                            id_type: user.id_type,

                            id_number: user.id_number,

                            first_name: user.first_name,

                            middle_name: user.middle_name,

                            last_name: user.last_name,

                            gender : user.gender,

                            pin_number: user.pin_number,

                            contact_person: user.contact_person,

                            occup_description: user.occup_description,

                            country: user.country,

                       

                            token: jwt.sign(payload, config.jwtSecretKey, {expiresIn : 60*60*24 })

                        });

                    });

                    connection.release(
                        function (err) {
                            if (err) {
                                console.error(err.message);
                            } else {
                                console.log("POST /login: Connection released");
                            }
                        });

                });

        }

    );

});

//////////////////////////////// Iquiz login


router.post('/loginapp', function (req, res, next) {
    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }
        console.log('req.body', req.body);

        connection.execute(

            'select entity_category as "entity_category", ' +

            '   entity_sys_id as "entity_sys_id", ' +

            '   surname as "surname", ' +

            '  other_names as "other_names", ' +

            '  dob as "dob", ' +

            '  town as "town", ' +

            '  country as "country", ' +
          
            '  mobile_number as "mobile_number", ' +
           
            '  email as "email", ' +

            '  registration_date  as "registration_date", ' +

            '  username as "username", ' +

            '  passwrd as "passwrd" ' +            

            ' from iquiz.iq_entities' +

          //  ' where email = :email',
          ' where username = :username',

            {

               // email: req.body.email.toLowerCase()
               username: req.body.username

            },

            {

                outFormat: oracledb.OBJECT

            },

            function (err, result) {
                if (err || result.rows.length < 1) {
                    res.set('Content-Type', 'application/json');
                    var status = err ? 500 : 404;
                    res.status(status).send(JSON.stringify({
                        status: status,
                        message: err ? "Error getting the that Username" : "Username you have entered is Incorrect. Kindly Try Again. or Contact systemadmin",
                        detailed_message: err ? err.message : ""
                    }));

                    return next(err);

                }

                user = result.rows[0];




                bcrypt.compare(req.body.password, user.passwrd, function (err, pwMatch) {

                    var payload;

                    if (err) {

                        return next(err);

                    }

                    if (!pwMatch) {

                        res.status(401).send({ message: 'Wrong Password. please Try Again .' });

                        return;

                    }

                    payload = {

                       // sub: user.email,
                        sub: user.username,

                        // password : user.password,

                        entity_sys_id: user.entity_sys_id,
                        
                        surname: user.surname,

                        other_names: user.other_names,

                        dob: user.dob,
                       
                        town: user.town ,
                        
                        country: user.country,

                        mobile_number: user.mobile_number,

                       // username: user.username,
                        email: user.email,

                        registration_date: user.registration_date


                    };

                    res.status(200).json({

                        user: user,
                       
                        email: user.email,

                        // password : user.password,

                        username: user.username, 

                        entity_category: user.entity_category,
                           
                        entity_sys_id: user.entity_sys_id,

                        surname: user.surname,


                        other_names: user.other_names,

                        dob: user.dob,

                        town: user.town,

                        country: user.country,

                        mobile_number: user.mobile_number,

                        registration_date: user.registration_date,


                        token: jwt.sign(payload, config.jwtSecretKey, {  expiresIn : 60*60*1 })

                    });

                });

                connection.release(
                    function (err) {
                        if (err) {
                            console.error(err.message);
                        } else {
                            console.log("POST /loginapp: Connection released");
                        }
                    });

            });

    }

    );

});


///////////////////////////
////////////////////////// IQUIZ CLASS CODE AND DESCRIPTION


router.get('/iqclass', function (req, res) {
    "use strict";

    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }

        connection.execute("SELECT CODE_ID, CODE_DESCRIPTION FROM IQUIZ.IQ_GENERAL_CODES WHERE CODE_TYPE = 'CLASS_LEVEL_CODE'", {}, {
            outFormat: oracledb.OBJECT // Return the result as Object
        }, function (err, result) {
            if (err) {
                res.set('Content-Type', 'application/json');
                res.status(500).send(JSON.stringify({
                    status: 500,
                    message: "Error getting the Class Levels",
                    detailed_message: err.message
                }));
            } else {

                res.contentType('application/json').status(200);
                res.send(JSON.stringify(result.rows));
            }
            // Release the connection
            connection.release(
                function (err) {
                    if (err) {
                        console.error(err.message);
                    } else {
                        console.log("GET /iqclass : Connection released");
                    }
                });
        });

    });
});



//get
//pulling all active policies

router.get('/poli', function (req, res, next) {

    "use strict";

    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }
            connection.execute(
                
                "SELECT * FROM CGIB.ONL_VIEW_ACTIVE_POLICY",
                {},//no binds
               
                {

                    outFormat: oracledb.OBJECT

                },

                function(err, results){

                    if (err) {

                        connection.release(function(err) {

                            if (err) {

                                console.error(err.message);

                            }

                        });

                        return next(err);

                    }

                    res.status(200).json(results.rows);

                    connection.release(function(err) {

                        if (err) {

                            console.error(err.message);

                        }

                    });

                }

            );

        }

    );

});

//get
//viewing your posted Queries as per cust_code


  
    router.get('/vq/:CUST_CODE', function (req, res) {
        "use strict";
    
        oracledb.getConnection(connAttrs, function (err, connection) {
            if (err) {
                // Error connecting to DB
                res.set('Content-Type', 'application/json');
                res.status(500).send(JSON.stringify({
                    status: 500,
                    message: "Error connecting to DB",
                    detailed_message: err.message
                }));
                return;
            }
    
            connection.execute("SELECT INQ_ID, CUST_CODE, TO_CHAR(CREATED_DATE, 'DD/MM/YYYY') CREATED_DATE, ISSUE_CATEGORY, NARRATION, SOLUTION_DESCRIPTION, TO_CHAR(SOLUTION_DATE, 'DD/MM/YYYY') SOLUTION_DATE FROM CGIB.CGI_ONLINE_INQUIRY WHERE CUST_CODE = :CUST_CODE ORDER BY INQ_ID", [req.params.CUST_CODE], {
                outFormat: oracledb.OBJECT // Return the result as Object
            }, function (err, result) {
                if (err || result.rows.length < 1) {
                    res.set('Content-Type', 'application/json');
                    var status = err ? 500 : 404;
                    res.status(status).send(JSON.stringify({
                        status: status,
                        message: err ? "Error getting the Query" : "Queries doesn't exist",
                        detailed_message: err ? err.message : ""
                    }));
                } else {
                    res.contentType('application/json').status(200).send(JSON.stringify(result.rows));
                }
                // Release the connection
                connection.release(
                    function (err) {
                        if (err) {
                            console.error(err.message);
                        } else {
                            console.log("GET /vq/" + req.params.CUST_CODE + " : Connection released");
                        }
                    });
            });
        });
    });


    ///post
    //registration

    router.post('/reg',  function post(req, res, next) {
        

        var user = {
    
            email: req.body.email,
            first_name : req.body.first_name,
            town: req.body.town,
            dob: req.body.dob,
            cust_type_code: req.body.cust_type_code,
            middle_name: req.body. middle_name,
            last_name: req.body. last_name,
            nationality: req.body.nationality,
            id_type: req.body. id_type,
            id_number: req.body.id_number,
            initials: req.body.initials,
            gender: req.body.gender,
            pin_number: req.body.pin_number,
            telephone_no: req.body.telephone_no,
            mobile_no: req.body.mobile_no,
            phys_address: req.body.phys_address,
            postal_address: req.body.postal_address,
            postal_code: req.body.postal_code,
            contact_person: req.body.contact_person,
            online_username: req.body.username,
        };

        //
        var  unhashedPassword = req.body.password;

        bcrypt.genSalt(10, function(err, salt) {
    
          if (err) {
    
               return next(err);
    
            }
           // console.log(password);

           bcrypt.hash(unhashedPassword, salt, function(err, hash) {
    
            if (err) {
    
                return next(err);
     
             }
             console.log(hash);
   
    
               user.hashedPassword = hash;
     
                insertUser(user, function(err, user) {
    
                    var payload;
    
                    if (err) {
    
                        return next(err);
    
                    }
    
                    payload = {
    
                        sub: user.email,
    
                        cmp_id: user.cmp_id,
    
                       cust_class_code: user.cust_class_code,
    
                        premium_category: user.premium_category
                      
                    };
    
                    res.status(200).json({
    
                        user: user,
    
                        token: jwt.sign(payload, config.jwtSecretKey, {expiresInMinutes: 60})
    
                    });
    
                });
    
          });
    
      })
    });
      
     // module.exports.post = post;

      function insertUser(user, cb) {

        "use strict";
        oracledb.getConnection(connAttrs, function (err, connection) {
            if (err) {
                // Error connecting to DB
                res.set('Content-Type', 'application/json');
                res.status(500).send(JSON.stringify({
                    status: 500,
                    message: "Error connecting to DB please try after sometimes",
                    detailed_message: err.message
                }));
                return;
            }

            //
            connection.execute(
                "SELECT cust_code, email, online_username" +
                " FROM CMS_ONLINE_PRE_CUSTOMERS " +
                " WHERE EMAIL = :email", [user.email],
                function(err, result) {
                  if (err) {
                   // doRelease(connection);
                    return cb(new Error(err));
                  }
                  if (result.rows.length > 0) {
                    //doRelease(connection);
                    return cb(new Error("User with that email already exists"));
                  }

                

               connection.execute(

                'insert into CMS_ONLINE_PRE_CUSTOMERS( ' +

                '   email, ' +

                '   online_password, ' +

                '   town, ' +

                '   dob, ' +

               '   cmp_id, ' +

                '   cust_class_code, ' +

                '  cust_type_code, ' +

                '  premium_category, ' +

                '  middle_name, ' +

                ' last_name, ' +

                ' nationality, ' +
                 
                ' id_type, ' +

                ' id_number, ' +

                '  initials, ' +

                '  gender, ' +

                '  pin_number,' +  
                
                '  telephone_no, ' +  

                '  mobile_no,  ' +

                '  phys_address, ' +

                '  postal_address, ' +

                '  postal_code, ' +

                '  contact_person, ' +

                '  online_username, ' +
             

                '   first_name ' +

                ') ' +

                'values (' +

                '    :email, ' +

                '    :password, ' +

                '    :town, ' +

                '   :dob, ' +

                 ' \'1\', ' +

                 ' \'001\', ' +
                
                '  :cust_type_code, ' +

                ' \'A\', ' +

                '  :middle_name, ' +

                '   :last_name, ' +

                '   :nationality, ' +
                 
                '   :id_type, ' +

                '   :id_number, ' +

                '   :initials, ' +

                '  :gender, ' +

               '   :pin_number,' +     
               
               '   :telephone_no, ' +

               '   :mobile_no,  ' +

               '   :phys_address, ' +

               '  :postal_address, ' +

               '  :postal_code, ' +

               '  :contact_person, ' +

               '  :username, ' +

             '   :FIRST_NAME ' +

                ') ' +

                'returning ' +

                '   cust_code, ' +

                '   email, ' +

                '   town, ' +

                '   dob, ' +

                '  cmp_id, ' +

                '   cust_class_code, ' +

                '  cust_type_code, ' +

                '  premium_category, ' +

                '   middle_name, ' +

                '   last_name, ' +

                '   nationality, ' +
                 
                '   id_type, ' +

                '   id_number, ' +

                '  initials, ' +

                '  gender, ' +

                '  pin_number,' +   
                
                '  telephone_no, ' +  

                '   mobile_no,  ' +

                '  phys_address, ' +

                '  postal_address, ' +

                '  postal_code, ' +

                '  contact_person, ' +

                '  online_username, ' +

                '   first_name ' +

                'into ' +

               '   :rcust_code, ' +

                '   :remail, ' +

                '   :rtown, '+

                '  :rdob ,' +

                '  :rcmp_id, ' +

                '   :rcust_class_code, ' +

                '  :rcust_type_code, ' +

                '  :rpremium_category, ' +

                '  :rmiddle_name, ' +

                '  :rlast_name, ' +

                '  :rnationality, ' +
                 
                '  :rid_type, ' +

                '  :rid_number, ' +

                '  :rinitials, ' +

                '  :rgender, ' +

                '  :rpin_number,' +    
                
                '  :rtelephone_no, ' +  

                '  :rmobile_no,  ' +

                '  :rphys_address, ' +

                '  :rpostal_address, ' +

                '  :rpostal_code, ' +

                '  :rcontact_person, ' +

                '  :ronline_username, ' +

                '   :rfirst_name', 
    
                    
                    {
    
                       
                    email: user.email,

                    password: user.hashedPassword,

                    town: user.town,

                    dob: user.dob,
                   
                    cust_type_code: user.cust_type_code,
                 
                    middle_name: user.middle_name,

                    last_name: user.last_name,

                    nationality: user.nationality,

                    id_type: user.id_type,

                    id_number: user.id_number,

                    initials: user.initials,

                    gender: user.gender,

                    pin_number: user.pin_number,

                    telephone_no: user.telephone_no,

                    mobile_no: user.mobile_no,

                    phys_address: user.phys_address,

                    postal_address: user.postal_address,

                    postal_code: user.postal_code,

                    contact_person: user.contact_person,

                    username: user.online_username,

                    
                    first_name: user.first_name,

                  rcust_code: {

                        type: oracledb.NUMBER,

                       dir: oracledb.BIND_OUT

                   },

                    remail: {

                        type: oracledb.STRING,

                        dir: oracledb.BIND_OUT

                    },

                    rtown: {

                        type: oracledb.STRING,

                        dir: oracledb.BIND_OUT

                    },

                    rdob: {

                        type: oracledb.STRING,

                        dir: oracledb.BIND_OUT

                    },

                   rcmp_id: {

                      type: oracledb.STRING,

                      dir: oracledb.BIND_OUT

                 },

                    rcust_class_code: {

                        type: oracledb.STRING,

                        dir: oracledb.BIND_OUT

                    },

                    rcust_type_code: {

                        type: oracledb.STRING,

                        dir: oracledb.BIND_OUT

                    },

                    rpremium_category: {

                        type: oracledb.STRING,

                        dir: oracledb.BIND_OUT

                    },

                    rmiddle_name: {

                        type: oracledb.STRING,

                        dir: oracledb.BIND_OUT

                    },

                    rlast_name: {

                        type: oracledb.STRING,

                        dir: oracledb.BIND_OUT

                    },

                    rnationality: {

                        type: oracledb.STRING,

                        dir: oracledb.BIND_OUT

                    },

                    rid_type: {

                        type: oracledb.STRING,

                        dir: oracledb.BIND_OUT

                    },

                    rid_number: {

                        type: oracledb.STRING,

                        dir: oracledb.BIND_OUT

                    },

                    rinitials: {

                        type: oracledb.STRING,

                        dir: oracledb.BIND_OUT

                    },

                    rgender: {

                        type: oracledb.STRING,

                        dir: oracledb.BIND_OUT

                    },

                    rpin_number:{

                        type: oracledb.STRING,

                        dir: oracledb.BIND_OUT

                    },


                    rtelephone_no:  {

                        type: oracledb.STRING,

                        dir: oracledb.BIND_OUT

                    },

                    rmobile_no:  {

                        type: oracledb.STRING,

                        dir: oracledb.BIND_OUT

                    },

                    rphys_address:  {

                        type: oracledb.STRING,

                        dir: oracledb.BIND_OUT

                    },

                    rpostal_address:  {

                        type: oracledb.STRING,

                        dir: oracledb.BIND_OUT

                    },

                    rpostal_code:  {

                        type: oracledb.STRING,

                        dir: oracledb.BIND_OUT

                    },
                    rcontact_person: {

                        type: oracledb.STRING,

                        dir: oracledb.BIND_OUT

                    },

                    ronline_username: {

                        type: oracledb.STRING,

                        dir: oracledb.BIND_OUT

                    },


                    rfirst_name: {

                        type: oracledb.STRING,

                        dir: oracledb.BIND_OUT

                    }

                },

                {

                    autoCommit: true

                },

                function(err, results){

                    if (err) {

                        connection.release(function(err) {

                            if (err) {

                                console.error(err.message);

                            }

                        });

                        return cb(err);

                    }

                    cb(null, {

                      cust_code: results.outBinds.rcust_code[0],

                        email: results.outBinds.remail[0],

                        town: results.outBinds.rtown[0],

                        dob: results.outBinds.rdob,

                        cmp_id: results.outBinds.rcmp_id[0],

                        cust_class_code: results.outBinds.rcust_class_code[0],

                        cust_type_code: results.outBinds.rcust_type_code[0],

                        premium_category: results.outBinds.rpremium_category[0],

                        middle_name: results.outBinds.rmiddle_name[0],

                        last_name:results.outBinds.rlast_name[0],

                        nationality: results.outBinds.rnationality[0],

                        id_type: results.outBinds.rid_type[0],

                        id_number: results.outBinds.rid_number[0],

                        initials: results.outBinds.rinitials[0],

                        gender: results.outBinds.rgender[0],

                        pin_number: results.outBinds.rpin_number[0],
                    

                       telephone_no:results.outBinds.rtelephone_no[0],

                       mobile_no: results.outBinds.rmobile_no[0],

                       phys_address: results.outBinds.rphys_address[0],

                        postal_address: results.outBinds.rpostal_address[0],

                        postal_code: results.outBinds.rpostal_code[0],

                        contact_person: results.outBinds.rcontact_person[0],

                        online_username: results.outBinds.ronline_username[0],

                        first_name: results.outBinds.rfirst_name[0]

                    });
    
                        connection.release(
                            function (err) {
                                if (err) {
                                    console.error(err.message);
                                } else {
                                    console.log("POST /reg: Connection released");
                                }
                            });;
    
                    });
    
            }
    
        );
    
    
    })
};
  
///////////////
/////////////////////// Start Exam

router.post('/exam', function post(req, res, next) {


    var user = {

        entity_sys_id: req.body.entity_sys_id,
        class_level_code: req.body.class_level_code,
        subject_code: req.body.subject_code,
        quiz_number: req.body.quiz_number
       
    };

    startExam(user, function (err, user) {

        var payload;

        if (err) {

            return next(err);

        }

        payload = {

            sub: user.entity_sys_id,

            class_level_code: user.class_level_code,

            subject_code: user.subject_code,

            quiz_number: user.quiz_number

        };

        res.status(200).json({

            user: user,

          //  token: jwt.sign(payload, config.jwtSecretKey, { expiresInMinutes: 60 })

        });

    });
   
});

// module.exports.post = post;

function startExam(user, cb) {

    "use strict";
    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB please try after sometimes",
                detailed_message: err.message
            }));
            return;
        }

                connection.execute(

                    'insert into  IQUIZ.IQ_STUDENT_QUIZ_HEADERS( ' +

                    '   entity_sys_id, ' +

                    '   class_level_code, ' +

                    '   subject_code, ' +

                    '   quiz_number ' +

                    ') ' +

                    'values (' +

                    '    :entity_sys_id, ' +

                    '    :class_level_code, ' +

                    '    :subject_code, ' +

                    '    :quiz_number ' +

                    ') ' +

                    'returning ' +

                    '   sqh_id, ' +

                    '   entity_sys_id, ' +

                    '   class_level_code, ' +

                    '   subject_code, ' +
                    
                    '   quiz_number ' +

                    'into ' +

                    '   :rsqh_id, ' +

                    '   :rentity_sys_id, ' +

                    '   :rclass_level_code, ' +

                    '  :rsubject_code ,' +

                    '   :rquiz_number',


                    {


                        entity_sys_id: user.entity_sys_id,

                        class_level_code: user.class_level_code,

                        subject_code: user.subject_code,

                        quiz_number: user.quiz_number,

                        rsqh_id: {

                            type: oracledb.NUMBER,

                            dir: oracledb.BIND_OUT

                        },

                        rentity_sys_id: {

                            type: oracledb.NUMBER,

                            dir: oracledb.BIND_OUT

                        },

                        rclass_level_code: {

                            type: oracledb.STRING,

                            dir: oracledb.BIND_OUT

                        },

                        rsubject_code: {

                            type: oracledb.STRING,

                            dir: oracledb.BIND_OUT

                        },

                        rquiz_number: {

                            type: oracledb.STRING,

                            dir: oracledb.BIND_OUT

                        }

                    },

                    {

                        autoCommit: true

                    },

                    function (err, results) {

                        if (err) {

                            connection.release(function (err) {

                                if (err) {
                              //  res.set('Content-Type', 'application/json');

            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(203).send(JSON.stringify({
                status: 203,
                message: "Error posting Data",
                detailed_message: err.message
            }));
            return;
        

                               //     console.error(err.message);

                                }

                            });

                            return cb(err);

                        }

                        cb(null, {

                            sqh_id: results.outBinds.rsqh_id[0],

                            entity_sys_id: results.outBinds.rentity_sys_id[0],

                            class_level_code: results.outBinds.rclass_level_code[0],
                            

                            subject_code: results.outBinds.rsubject_code[0],

                            quiz_number: results.outBinds.rquiz_number[0]
                            

                        });

                        connection.release(
                            function (err) {
                                if (err) {
                              //  res.set('Content-Type', 'application/json');
                                    console.error(err.message);
                                } else {
                                    console.log("POST /exam: Connection released");
                                }
                            });;

                    });


    })
};


//////////////////////////////////////////
//////////////////////////////// QUESTION pull as per SQH_ID

router.get('/question/:SQH_ID', function (req, res) {
    "use strict";

    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }

        connection.execute(" SELECT * FROM IQUIZ.IQ_STUDENT_QUIZ_QUESTIONS WHERE SQH_ID = :SQH_ID", [req.params.SQH_ID], {
            outFormat: oracledb.OBJECT // Return the result as Object
        }, function (err, result) {
            if (err || result.rows.length < 1) {
                res.set('Content-Type', 'application/json');
                var status = err ? 500 : 404;
                res.status(status).send(JSON.stringify({
                    status: status,
                    message: err ? "Error getting the QUESTION" : "You have no started the session",
                    detailed_message: err ? err.message : ""
                }));
            } else {
                res.contentType('application/json').status(200).send(JSON.stringify(result.rows));
            }
            // Release the connection
            connection.release(
                function (err) {
                    if (err) {
                        console.error(err.message);
                    } else {
                        console.log("GET /question/" + req.params.SQH_ID + " : Connection released");
                    }
                });
        });
    });
});




////////////////////////////
///////////////////////////Answers for Question
router.get('/answer/:SQQ_ID', function (req, res) {
    "use strict";

    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }

        connection.execute(" SELECT * FROM IQUIZ.IQ_STUDENT_QUIZ_ANSWERS WHERE SQQ_ID =: SQQ_ID", [req.params.SQQ_ID], {
            outFormat: oracledb.OBJECT // Return the result as Object
        }, function (err, result) {
            if (err || result.rows.length < 1) {
                res.set('Content-Type', 'application/json');
                var status = err ? 500 : 404;
                res.status(status).send(JSON.stringify({
                    status: status,
                    message: err ? "Error getting the ANSWER" : "You have no started the session",
                    detailed_message: err ? err.message : ""
                }));
            } else {
                res.contentType('application/json').status(200).send(JSON.stringify(result.rows));
            }
            // Release the connection
            connection.release(
                function (err) {
                    if (err) {
                        console.error(err.message);
                    } else {
                        console.log("GET /answer/" + req.params.SQQ_ID + " : Connection released");
                    }
                });
        });
    });
});




////////////////////////////
//////////////////////////// Working Question and Answers
router.get('/questionsAnswers/:sqh_id', function (req, res) {
    "use strict";

    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }
		console.log('req',req);
        connection.execute(
                'select sqh_id, '+
                '   quiz_number, ' +
                '   subject_code \n' +
                'from iquiz.iq_student_quiz_headers \n' +
                'where sqh_id = :sqh_id',
               {
                   sqh_id: req.params.sqh_id
               }, 
                function(err, results) {
                    var sqheaders = {};
                    if (err) {
                       // throw err;
					console.error(err.message);
                    }
					console.log('results',results);
                    sqheaders.sqh_id = results.rows[0][0];
                    sqheaders.quiz_number = results.rows[0][1];
                    sqheaders.subject_code = results.rows[0][2];
					res.set('Content-Type', 'application/json');
                    listquestions( sqheaders, connection,res);
					//getquestiondetails (sqheaders, connection,res);
				} 
            ); // end execute ...
    });
});


function listquestions(sqheaders, connection,res) {
    connection.execute(
        'select sqq_id, \n' +
		'  question_number, ' +
        '   question_narration \n' +
        'from iquiz.iq_student_quiz_questions \n' +
        'where sqh_id = :sqh_id',
        {
            sqh_id: sqheaders.sqh_id
        },
		 
        function(err, results) {
            if (err) throw err;
            sqheaders.questionslist = [];
				results.rows.forEach(function(row) {
					var qlist = {};
					qlist.sqq_id = row[0];
					qlist.question_number = row[1];
					qlist.question_narration = row[2];
					sqheaders.questionslist.push(qlist);
				}); 
				async.eachSeries(
					sqheaders.questionslist,
					function(qlist, cb) {
						connection.execute(
							' select answer_id, \n' +
							'  answer_narration, ' +
							'  question_sys_id\n' +
							' from iquiz.iq_student_quiz_answers \n' +
							' where sqq_id = :sqq_id',
							{
								sqq_id: qlist.sqq_id
							},
							function(err, results) {
								if (err) {
									cb(err);
									return;
								}
								qlist.questionAnswers = [];
								results.rows.forEach(function(row) {
									var qa = {};
									qa.answer_id = row[0];
									qa.answer_narration = row[1];
									qa.question_sys_id = row[2]; 
									qlist.questionAnswers.push(qa);
								});
								cb();
							}
						);
					},
					function(err) {
						if (err) throw err;
						//callback(null, JSON.stringify(department));
						res.send(JSON.stringify(sqheaders));
						connection.release(function(err) {
							if (err) {
								console.error(err);
							}
						});
					}
				);
			 
			//res.send(JSON.stringify(sqheaders));
			   
		}   ///function (err,results)  
				
		);
}


router.get('/questionsiquiz/:sqh_id', function (req, res) {
    "use strict";

    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }
		console.log('req',req);
        connection.execute(
                'select sqh_id, '+
                '   quiz_number, ' +
                 'revision_type_yn, ' +
                '   subject_code \n' +
                'from iquiz.iq_student_quiz_headers \n' +
                'where sqh_id = :sqh_id',
               {
                   sqh_id: req.params.sqh_id
               }, 
                function(err, results) {
                    var sqheaders = {};
                    if (err) {
                       // throw err;
					console.error(err.message);
                    }
					console.log('results',results);
                    sqheaders.id = results.rows[0][0];
                    sqheaders.number = results.rows[0][1];
                    sqheaders.secondary = results.rows[0][2];
                     sqheaders.description = results.rows[0][3];
					res.set('Content-Type', 'application/json');
                    listquestions( sqheaders, connection,res);
					//getquestiondetails (sqheaders, connection,res);
				} 
            ); // end execute ...
    });
});


function listquestions(sqheaders, connection,res) {
    connection.execute(
        'select sqq_id, \n' +
        '  question_number, ' +
        '  questionTypeId, ' +
        '   image_link, ' +
        '   answer_narration, ' +
        '   answer_image_link, ' +
        '   passage, ' +   
        '   actual_answer, ' +     
        '   requires_actual_answer_yn, ' +      
        '   shared_map_yn, ' +    
        '   before_image_link, ' +  
        '   passage_header, ' +  
        '   display_passage_yn, ' +   
        '   other_passage, ' +     
        '   question_narration \n' +
        'from iquiz.IQV_STUDENT_QUIZ_QUESTIONS \n' +
        'where sqh_id = :sqh_id',
        {
            sqh_id: sqheaders.id
        },
		 
        function(err, results) {
            if (err) throw err;
            sqheaders.questions = [];
				results.rows.forEach(function(row) {
					var qlist = {};
					qlist.id = row[0];
					qlist.question_number = row[1];
                                         qlist.questionTypeId = row[2];  
                                         qlist.image = row[3];    
                                         qlist.answer_narration = row[4]; 
                                         qlist.answer_image_link = row[5];                                            
                                         qlist.passage = row[6]; 
                                          qlist.actual_answer = row[7];                                         
                                         qlist.requires_actual_answer_yn = row[8];
                                         qlist.shared_map_yn = row[9];
                                          qlist.before_image_link = row[10];
                                          qlist.passage_header = row[11];
                                          qlist.display_passage_yn = row[12];
                                          qlist.other_passage = row[13];
                                          qlist.name = row[14];                                                              
				 	sqheaders.questions.push(qlist);
				}); 
				async.eachSeries(
					sqheaders.questions,
					function(qlist, cb) {
						connection.execute(
							' select answer_id, \n' +
                                                         '  answer_narration, ' +
                                                           '  isAnswer, ' +                                                        
							'  question_sys_id\n' +
							' from iquiz.iq_student_quiz_answers \n' +
							' where sqq_id = :sqq_id',
							{
								sqq_id: qlist.id
							},
							function(err, results) {
								if (err) {
									cb(err);
									return;
								}
								qlist.options = [];
								results.rows.forEach(function(row) {
									var qa = {};
									qa.id = row[0];
                                                                        qa.name = row[1];
                                                                        qa.isAnswer = row[2];
									qa.questionId = row[3]; 
									qlist.options.push(qa);
								});
								cb();
							}
						);
					},
					function(err) {
						if (err) throw err;
						//callback(null, JSON.stringify(department));
						res.send(JSON.stringify(sqheaders));
						connection.release(function(err) {
							if (err) {
								console.error(err);
							}
						});
					}
				);
			 
			//res.send(JSON.stringify(sqheaders));
			   
		}   ///function (err,results)  
				
		);
}

/////////////////////////////
////////////////////////////UPDATE


// Build UPDATE statement and prepare bind variables
var buildUpdateStatement = function buildUpdateStatement(req) {
    "use strict";

    var statement = "",
        bindValues = {};
    if (req.body.STUDENT_CHECKED_ANSWER) {
        statement += "STUDENT_CHECKED_ANSWER = :STUDENT_CHECKED_ANSWER";
        bindValues.STUDENT_CHECKED_ANSWER = req.body.STUDENT_CHECKED_ANSWER;
    }

    statement += " WHERE SQQ_ID = :SQQ_ID AND QUESTION_SYS_ID = :QUESTION_SYS_ID AND ANSWER_ID = :ANSWER_ID";
    bindValues.SQQ_ID = req.body.SQQ_ID;
    bindValues.QUESTION_SYS_ID = req.body.QUESTION_SYS_ID;
    bindValues.ANSWER_ID = req.body.ANSWER_ID;
    statement = "UPDATE IQUIZ.IQ_STUDENT_QUIZ_ANSWERS SET " + statement;

    return {
        statement: statement,
        bindValues: bindValues
    };
};

// Http method: PUT
// URI        : /user_profiles/:USER_NAME
// Update the profile of user given in :USER_NAME
router.put('/updateanswer', function (req, res) {
    "use strict";

    if ("application/json" !== req.get('Content-Type')) {
        res.set('Content-Type', 'application/json').status(415).send(JSON.stringify({
            status: 415,
            message: "Wrong content-type. Only application/json is supported",
            detailed_message: null
        }));
        return;
    }

    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json').status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }

        var updateStatement = buildUpdateStatement(req);
        connection.execute(updateStatement.statement, updateStatement.bindValues, {
                autoCommit: true,
                outFormat: oracledb.OBJECT // Return the result as Object
            },
            function (err, result) {
                if (err || result.rowsAffected === 0) {
                    // Error
                    res.set('Content-Type', 'application/json');
                    res.status(400).send(JSON.stringify({
                        status: 400,
                        message: err ? "Input Error" : "User doesn't exist",
                        detailed_message: err ? err.message : ""
                    }));
                } else {
                    // Resource successfully updated. Sending an empty response body. 
                    res.status(204).end();
                }
                // Release the connection
                connection.release(
                    function (err) {
                        if (err) {
                            console.error(err.message);
                        } else {
                            console.log("PUT /updateanswer/" + " : Connection released ");
                        }
                    });
            });
    });
});
/////////////////////////////last exam submit
///////////////////
router.post('/submit', function (req, res) {
    "use strict";
    console.log('req.body', req.body);
    if ("application/json" !== req.get('Content-Type')) {
        res.set('Content-Type', 'application/json').status(415).send(JSON.stringify({
            status: 415,
            message: "Wrong content-type. Only application/json is supported",
            detailed_message: null
        }));
        return;
    }
    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json').status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }
        console.log('req.body', req.body);
        connection.execute("begin IQUIZ.PROC_MARK_IQUIZ (:SQH_ID); end;",
             [req.body.SQH_ID,],
            {
                autoCommit: true,
                outFormat: oracledb.OBJECT // Return the result as Object
            },
            function (err, result) {
                if (err) {
                    // Error
                    res.set('Content-Type', 'application/json');
                    res.status(400).send(JSON.stringify({
                        status: 400,
                        message: err.message.indexOf("ORA-00001") > -1 ? "Problem posting your query contact systemadmin" : "Input Error",
                        detailed_message: err.message
                    }));
                } else {
                    // Successfully created the resource
                    res.status(201).set('Location', '/query/' + req.body.SQH_ID).end();
                }
                // Release the connection
                connection.release(
                    function (err) {
                        if (err) {
                            console.error(err.message);
                        } else {
                            console.log("POST /submit: Connection released");
                        }
                    });
            });
    });
});


//////////////////////////
////////////////Getting results
router.get('/result/:SQH_ID', function (req, res) {
    "use strict";

    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }

        connection.execute("SELECT TOTAL_QUIZ_QUESTIONS,  CORRECT_ANSWERS,   PERFORMANCE_GRADE FROM IQUIZ.IQ_STUDENT_QUIZ_HEADERS WHERE SQH_ID = :SQH_ID", [req.params.SQH_ID], {
            outFormat: oracledb.OBJECT // Return the result as Object
        }, function (err, result) {
            if (err || result.rows.length < 1) {
                res.set('Content-Type', 'application/json');
                var status = err ? 500 : 404;
                res.status(status).send(JSON.stringify({
                    status: status,
                    message: err ? "Error getting the results" : "Results doesn't exist",
                    detailed_message: err ? err.message : ""
                }));
            } else {
                res.contentType('application/json').status(200).send(JSON.stringify(result.rows));
            }
            // Release the connection
            connection.release(
                function (err) {
                    if (err) {
                        console.error(err.message);
                    } else {
                        console.log("GET /result/" + req.params.SQH_ID + " : Connection released");
                    }
                });
        });
    });
});

//////////////////////
///////////////////incomplete Quizes
router.get('/incomplete/:ENTITY_SYS_ID', function (req, res) {
    "use strict";

    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }

        connection.execute("SELECT SQH_ID, QUIZ_NUMBER, SUBJECT_CODE, CLASS_LEVEL_CODE, START_DATETIME, CAPTURED_DATE FROM IQUIZ.VW_INCOMPLETE_STUDENT_QUIZES WHERE CAPTURED_DATE IS NOT NULL AND ENTITY_SYS_ID = :ENTITY_SYS_ID ORDER BY CAPTURED_DATE DESC", [req.params.ENTITY_SYS_ID], {
            outFormat: oracledb.OBJECT // Return the result as Object
        }, function (err, result) {
            if (err || result.rows.length < 1) {
                res.set('Content-Type', 'application/json');
                var status = err ? 500 : 404;
                res.status(status).send(JSON.stringify({
                    status: status,
                    message: err ? "Error getting the results" : "Results doesn't exist",
                    detailed_message: err ? err.message : ""
                }));
            } else {
                res.contentType('application/json').status(200).send(JSON.stringify(result.rows));
            }
            // Release the connection
            connection.release(
                function (err) {
                    if (err) {
                        console.error(err.message);
                    } else {
                        console.log("GET /incomplete/" + req.params.ENTITY_SYS_ID + " : Connection released");
                    }
                });
        });
    });
});




//////////////////////////
////////////////////////UPDATING ALL ANSWERES ON SELECT
router.post('/updatepro', function (req, res) {
    "use strict";
    console.log('req.body', req.body);
    if ("application/json" !== req.get('Content-Type')) {
        res.set('Content-Type', 'application/json').status(415).send(JSON.stringify({
            status: 415,
            message: "Wrong content-type. Only application/json is supported",
            detailed_message: null
        }));
        return;
    }
    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json').status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }
        console.log('req.body', req.body);
        connection.execute("begin IQUIZ.CALL_UPD_STUDENT_ANSWER(:P_QUESTION_SYS_ID, :P_SQQ_ID, :P_ANSWER_ID); end;",
             [req.body.P_QUESTION_SYS_ID, req.body.P_SQQ_ID, req.body.P_ANSWER_ID,],
            {
                autoCommit: true,
                outFormat: oracledb.OBJECT // Return the result as Object
            },
            function (err, result) {
                if (err) {
                    // Error
                    res.set('Content-Type', 'application/json');
                    res.status(400).send(JSON.stringify({
                        status: 400,
                        message: err.message.indexOf("ORA-00001") > -1 ? "Problem posting your query contact systemadmin" : "Input Error",
                        detailed_message: err.message
                    }));
                } else {
                    // Successfully created the resource
                    res.status(201).set('Location', '/query/' + req.body.SQH_ID).end();
                }
                // Release the connection
                connection.release(
                    function (err) {
                        if (err) {
                            console.error(err.message);
                        } else {
                            console.log("POST /updatepro: Connection released");
                        }
                    });
            });
    });
});

///////////////////////////////
///////////////////////////


//////////////////////////
////////////////////////UPDATING ALL ANSWERES ON SELECT
router.post('/updatetype', function (req, res) {
    "use strict";
    console.log('req.body', req.body);
    if ("application/json" !== req.get('Content-Type')) {
        res.set('Content-Type', 'application/json').status(415).send(JSON.stringify({
            status: 415,
            message: "Wrong content-type. Only application/json is supported",
            detailed_message: null
        }));
        return;
    }
    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json').status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }
        console.log('req.body', req.body);
        connection.execute("begin IQUIZ.call_upd_student_typed_answer (:P_SQQ_ID, :P_TYPED_ANSWER); end;",
             [req.body.P_SQQ_ID, req.body.P_TYPED_ANSWER,],
            {
                autoCommit: true,
                outFormat: oracledb.OBJECT // Return the result as Object
            },
            function (err, result) {
                if (err) {
                    // Error
                    res.set('Content-Type', 'application/json');
                    res.status(400).send(JSON.stringify({
                        status: 400,
                        message: err.message.indexOf("ORA-00001") > -1 ? "Problem updating the Answer" : "Input Error",
                        detailed_message: err.message
                    }));
                } else {
                    // Successfully created the resource
                    res.status(201).set('Location', '/query/' + req.body.SQH_ID).end();
                }
                // Release the connection
                connection.release(
                    function (err) {
                        if (err) {
                            console.error(err.message);
                        } else {
                            console.log("POST /updatetype: Connection released");
                        }
                    });
            });
    });
});



////////////////////////iquiz registration

router.post('/iquizreg', function (req, res, next) {


    var user = {

        email: req.body.email,
        surname: req.body.surname,
        town: req.body.town,
        dob: req.body.dob,
        country: req.body.country,
        other_names: req.body.other_names,
        entity_category: req.body.entity_category,
        mobile_number: req.body.mobile_number,
        brief_narration: req.body.brief_narration,        
        username: req.body.username,
    };

    //
    var unhashedPassword = req.body.passwrd;

    bcrypt.genSalt(10, function (err, salt) {

        if (err) {

            return next(err);

        }
        // console.log(password);

        bcrypt.hash(unhashedPassword, salt, function (err, hash) {

            if (err) {

                return next(err);

            }
            console.log(hash);


            user.hashedPassword = hash;

            addUser(user, function (err, user) {

                var payload;

                if (err) {

                    return next(err);

                }

                payload = {

                    sub: user.email,

                    category: user.category,

                    dob: user.dob

                };

                res.status(200).json({

                    user: user,

                  token: jwt.sign(payload, config.jwtSecretKey, { expiresIn : 60*60*24 })

                });

            });

        });

    })
});

// module.exports.post = post;

function addUser(user, cb) {

    "use strict";
    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB please try after sometimes",
                detailed_message: err.message
            }));
            return;
        }

        //
        connection.execute(
            "SELECT entity_sys_id, email, username" +
            " FROM IQUIZ.IQ_ENTITIES " +
            " WHERE USERNAME = :username", [user.username],
           function(err, result) {
                  if (err) {
                   // doRelease(connection);
                    return cb(new Error(err));
                  }
                  if (result.rows.length > 0) {
                    //doRelease(connection);
                    return cb(new Error("User with that Username already exists Choose another one please. "));
                  }



                connection.execute("INSERT INTO IQUIZ.IQ_ENTITIES( EMAIL, PASSWRD, TOWN, DOB, COUNTRY, ENTITY_CATEGORY, MOBILE_NUMBER, BRIEF_NARRATION, OTHER_NAMES, CREATED_DATE, REGISTRATION_DATE, USERNAME, SURNAME ) VALUES" +
                " (:EMAIL, :PASSWRD, :TOWN, TO_DATE(:DOB,'YYYY-MM-DD'), :COUNTRY, :ENTITY_CATEGORY, :MOBILE_NUMBER,  :BRIEF_NARRATION,:OTHER_NAMES, SYSDATE , SYSDATE , :USERNAME, :SURNAME) " +

                    'returning ' +

                    '   entity_sys_id, ' +

                    '   email, ' +

                    '   town, ' +

                    '   dob, ' +

                    '  country, ' +

                    '   entity_category, ' +

                    '  mobile_number, ' +

                    '  brief_narration, ' +

                    '   other_names, ' +                  

                    '  username, ' +

                    '   surname ' +

                    'into ' +

                    '   :rentity_sys_id, ' +

                    '   :remail, ' +

                    '   :rtown, ' +

                    '  :rdob ,' +

                    '  :rcountry, ' +

                    '   :rentity_category, ' +

                    '  :rmobile_number, ' +

                    '  :rbrief_narration, ' +

                    '  :rother_names, ' +                

                    '  :rusername, ' +

                    '   :rsurname',


                    {


                        email: user.email,

                        passwrd: user.hashedPassword,

                        town: user.town,

                        dob: user.dob,

                        country: user.country,

                        entity_category: user.entity_category,

                        other_names: user.other_names,

                        mobile_number: user.mobile_number,

                        brief_narration: user.brief_narration,  

                        username: user.username,


                        surname: user.surname,

                        rentity_sys_id: {

                            type: oracledb.NUMBER,

                            dir: oracledb.BIND_OUT

                        },

                        remail: {

                            type: oracledb.STRING,

                            dir: oracledb.BIND_OUT

                        },

                        rtown: {

                            type: oracledb.STRING,

                            dir: oracledb.BIND_OUT

                        },

                        rdob: {

                            type: oracledb.STRING,

                            dir: oracledb.BIND_OUT

                        },

                        rcountry: {

                            type: oracledb.STRING,

                            dir: oracledb.BIND_OUT

                        },

                        rentity_category: {

                            type: oracledb.STRING,

                            dir: oracledb.BIND_OUT

                        },

                        rmobile_number: {

                            type: oracledb.STRING,

                            dir: oracledb.BIND_OUT

                        },

                        rbrief_narration: {

                            type: oracledb.STRING,

                            dir: oracledb.BIND_OUT

                        },

                        rother_names: {

                            type: oracledb.STRING,

                            dir: oracledb.BIND_OUT

                        },

                        rusername: {

                            type: oracledb.STRING,

                            dir: oracledb.BIND_OUT

                        },

                        rsurname: {

                            type: oracledb.STRING,

                            dir: oracledb.BIND_OUT

                        }

                    },

                    {

                        autoCommit: true

                    },

                    function (err, results) {

                        if (err) {

                            connection.release(function (err) {

                                if (err) {

                                    console.error(err.message);

                                }

                            });

                            return cb(err);

                        }

                        cb(null, {

                            entity_sys_id: results.outBinds.rentity_sys_id[0],

                            email: results.outBinds.remail[0],

                            town: results.outBinds.rtown[0],

                            dob: results.outBinds.rdob,

                            country: results.outBinds.rcountry[0],

                            entity_category: results.outBinds.rentity_category[0],

                            mobile_number: results.outBinds.rmobile_number[0],

                            brief_narration: results.outBinds.rbrief_narration[0],

                            other_names: results.outBinds.rother_names[0],                          
                          
                            username: results.outBinds.rusername[0],

                            surname: results.outBinds.rsurname[0]

                        });

                        connection.release(
                            function (err) {
                                if (err) {
                                    console.error(err.message);
                                } else {
                                    console.log("POST /iquizreg: Connection released");
                                }
                            });

                    });

            }

        );


    })
};

///////////////paypal trial


router.post('/pal', function ipnHandler(req, res) {

    console.log("IPN Notification Event Received");
  
    if (req.method !== "POST") {
      console.error("Request method not allowed.");
      res.status(405).send("Method Not Allowed");
    } else {
      // Return empty 200 response to acknowledge IPN post success.
      console.log("IPN Notification Event received successfully.");
      res.status(200).end();
    }
  
    // JSON object of the IPN message consisting of transaction details.
    let ipnTransactionMessage = req.body;
    // Convert JSON ipn data to a query string since Google Cloud Function does not expose raw request data.
    let formUrlEncodedBody = querystring.stringify(ipnTransactionMessage);
    // Build the body of the verification post message by prefixing 'cmd=_notify-validate'.
    let verificationBody = `cmd=_notify-validate&${formUrlEncodedBody}`;
  
    console.log(`Verifying IPN: ${verificationBody}`);
  
    let options = {
      method: "POST",
      uri: getPaypalURI(),
      body: verificationBody,
    };
  
    // POST verification IPN data to paypal to validate.
    request(options, function callback(error, response, body) {
      if (!error && response.statusCode == 200) {
        // Check the response body for validation results.
        if (body === "VERIFIED") {
          console.log(
            `Verified IPN: IPN message for Transaction ID: ${ipnTransactionMessage.txn_id} is verified.`
          );
          // TODO: Implement post verification logic on ipnTransactionMessage
        } else if (body === "INVALID") {
          console.error(
            `Invalid IPN: IPN message for Transaction ID: ${ipnTransactionMessage.txn_id} is invalid.`
          );
        } else {
          console.error("Unexpected reponse body.");
        }
      } else {
        // Error occured while posting to PayPal.
        console.error(error);
        console.log(body);
      }
    })
})



////////////////////
///////////////////////// Iquiz Subject listing
router.get('/iquizlesson/:CODE_ID/:SUBJECT_CODE', function (req, res) {
    "use strict";

    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }

        connection.execute("SELECT * FROM IQUIZ.IQ_LESSON_HEADERS WHERE CLASS_LEVEL_CODE = :CODE_ID AND SUBJECT_CODE = :SUBJECT_CODE AND ACTIVE_YN = 'Y' ORDER BY LESSON_SERIAL_NO ASC", [req.params.CODE_ID, req.params.SUBJECT_CODE], {
            outFormat: oracledb.OBJECT // Return the result as Object
        }, function (err, result) {
            if (err || result.rows.length < 1) {
                res.set('Content-Type', 'application/json');
                var status = err ? 500 : 404;
                res.status(status).send(JSON.stringify({
                    status: status,
                    message: err ? "Error getting that QUIZ" : "QUIZ doesn't exist",
                    detailed_message: err ? err.message : ""
                }));
            } else {
                res.contentType('application/json').status(200).send(JSON.stringify(result.rows));
            }
            // Release the connection
            connection.release(
                function (err) {
                    if (err) {
                        console.error(err.message);
                    } else {
                        console.log("GET /iquizlesson/" + req.params.CODE_ID + req.params.SUBJECT_CODE + " : Connection released");
                    }
                });
        });
    });
});



///////////////paypal trial


router.post('/paypal ', function ipnHandler(req, res) {

    console.log("IPN Notification Event Received");
  
    if (req.method !== "POST") {
      console.error("Request method not allowed.");
      res.status(405).send("Method Not Allowed");
    } else {
       console.log("Response", res);
      // Return empty 200 response to acknowledge IPN post success.
      console.log("IPN Notification Event received successfully.");
      res.status(200).end();
    }
  
   
})



//selecting class group of the products
router.get('/iquizlesson/:LSH_ID', function (req, res) {
    "use strict";

    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }

        connection.execute("SELECT * FROM IQUIZ.IQ_LESSON_DETAILS WHERE LD_LSH_ID = :LSH_ID ", [req.params.LSH_ID], {
            outFormat: oracledb.OBJECT // Return the result as Object
        }, function (err, result) {
            if (err || result.rows.length < 1) {
                res.set('Content-Type', 'application/json');
                var status = err ? 500 : 404;
                res.status(status).send(JSON.stringify({
                    status: status,
                    message: err ? "Error getting the that LESSON" : "LESSON doesn't exist",
                    detailed_message: err ? err.message : ""
                }));
            } else {
                res.contentType('application/json').status(200).send(JSON.stringify(result.rows));
            }
            // Release the connection
            connection.release(
                function (err) {
                    if (err) {
                        console.error(err.message);
                    } else {
                        console.log("GET /iquizlesson/" + req.params.LSH_ID + " : Connection released");
                    }
                });
        });
    });
});


////////GET LESSON NARRATION


//selecting class group of the products
router.get('/lessonnarration/:LSD_ID', function (req, res) {
    "use strict";

    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }

        connection.execute("SELECT LSD_ID, SERIAL_NO, SUB_TITLE, NARRATION FROM IQUIZ.IQ_LESSON_NARRATIONS WHERE LSD_ID = :LSD_ID ORDER BY SERIAL_NO ASC ", [req.params.LSD_ID], {
            outFormat: oracledb.OBJECT // Return the result as Object
        }, function (err, result) {
            if (err || result.rows.length < 1) {
                res.set('Content-Type', 'application/json');
                var status = err ? 500 : 404;
                res.status(status).send(JSON.stringify({
                    status: status,
                    message: err ? "Error getting the that LESSON" : "LESSON doesn't exist",
                    detailed_message: err ? err.message : ""
                }));
            } else {
                res.contentType('application/json').status(200).send(JSON.stringify(result.rows));
            }
            // Release the connection
            connection.release(
                function (err) {
                    if (err) {
                        console.error(err.message);
                    } else {
                        console.log("GET /lessonnarration/" + req.params.LSD_ID + " : Connection released");
                    }
                });
        });
    });
});


////////////////////
///////////////////////// Iquiz Subject listing
router.get('/lesssubj/:CODE_ID', function (req, res) {
    "use strict";

    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }

        connection.execute("SELECT DISTINCT SUBJECT_CODE FROM IQUIZ.IQ_LESSON_HEADERS WHERE CLASS_LEVEL_CODE = :CODE_ID AND NVL(ACTIVE_YN,'X') = 'Y'", [req.params.CODE_ID], {
            outFormat: oracledb.OBJECT // Return the result as Object
        }, 
         function (err, result) {
            if (err || result.rows.length < 1) {
                res.set('Content-Type', 'application/json');
                var status = err ? 500 : 404;
                res.status(status).send(JSON.stringify({
                    status: status,
                    message: err ? "Error getting that subject" : "Subject doesn't exist",
                    detailed_message: err ? err.message : ""
                }));
                

            } else {
                res.contentType('application/json').status(200).send(JSON.stringify(result.rows));
            }
            // Release the connection
            connection.release(
                function (err) {
                    if (err) {
                        console.error(err.message);
                    } else {
                        console.log("GET /lesssubj/" + req.params.CODE_ID + " : Connection released");
                    }
                });
        });
    });
});
////////////////New lesson start Api


router.get('/lessonstart/:lsh_id', function (req, res) {
    "use strict";

    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }
		console.log('req',req);
        connection.execute(
                'select lsh_id, '+
                ' lesson_description, ' +
                 'lesson_narration, ' +
                 'lesson_summary, ' +
                 'lesson_image_link, ' +
                 'quiz_qh_id, ' +
                '   subject_code \n' +
                'from iquiz.iq_lesson_headers \n' +
                'where lsh_id = :lsh_id',
               {
                   lsh_id: req.params.lsh_id
               }, 
                function(err, results) {
                    var sqheaders = {};
                    if (err) {
                       // throw err;
					console.error(err.message);
                    }
					console.log('results',results);
                    sqheaders.lsh_id = results.rows[0][0];
                    sqheaders.lesson_description = results.rows[0][1];
                    sqheaders.lesson_narration = results.rows[0][2];
                     sqheaders.lesson_summary = results.rows[0][3];
                     sqheaders.lesson_image_link = results.rows[0][4];
                     sqheaders.quiz_qh_id = results.rows[0][5];
                     sqheaders.subject_code = results.rows[0][6];
					res.set('Content-Type', 'application/json');
                    lessondetails( sqheaders, connection,res);
					//getquestiondetails (sqheaders, connection,res);
				} 
            ); // end execute ...
    });
});


function lessondetails(sqheaders, connection,res) {
    connection.execute(
        'select lsd_id, \n' +
        '  ld_lsh_id, ' +
        '  topic_title, ' +
        '   topic_image_link, ' +
        '   topic_summary, ' +              
        '   serial_no \n' +
        'from iquiz.IQ_LESSON_DETAILS \n' +
        'where ld_lsh_id = :lsh_id',
        {
            lsh_id: sqheaders.lsh_id
        },
		 
        function(err, results) {
            if (err) throw err;
            sqheaders.lessons = [];
				results.rows.forEach(function(row) {
					var qlist = {};
					qlist.lsd_id = row[0];
					qlist.ld_lsh_id = row[1];
                    qlist.topic_title = row[2];  
                    qlist.topic_image_link = row[3];    
                    qlist.topic_summary = row[4]; 
                    qlist.serial_no = row[5];  
                  //  sqheaders.quiz_qh_id = row[6];
                   // sqheaders.lesson_description = rows[7];                                     
				 	sqheaders.lessons.push(qlist);
				}); 
				async.eachSeries(
					sqheaders.lessons,
					function(qlist, cb) {
						connection.execute(
							' select lsd_id, \n' +
                            '  serial_no, ' +
                            '  sub_title, ' +                                                        
							'  narration\n' +
							' from iquiz.IQ_LESSON_NARRATIONS \n' +
							' where lsd_id = :lsd_id',
							{
								lsd_id: qlist.lsd_id
							},
							function(err, results) {
								if (err) {
									cb(err);
									return;
								}
								qlist.sublessons = [];
								results.rows.forEach(function(row) {
									var qa = {};
									qa.lsd_id = row[0];
                                    qa.serial_no = row[1];
                                    qa.sub_title = row[2];
									qa.narration = row[3]; 
									qlist.sublessons.push(qa);
								});
								cb();
							}
						);
					},
					function(err) {
						if (err) throw err;
						//callback(null, JSON.stringify(department));
						res.send(JSON.stringify(sqheaders));
						connection.release(function(err) {
							if (err) {
								console.error(err);
							}
						});
					}
				);
			 
			//res.send(JSON.stringify(sqheaders));
			   
		}   ///function (err,results)  
				
		);
}


////////////////////////////
//////////////////////////  Pulling Quiz numbers for lessons

router.get('/lessonquizno/:QUIZ_QH_ID', function (req, res) {
    "use strict";

    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }

        connection.execute("SELECT class_level_code, subject_code, quiz_number FROM IQUIZ.IQ_QUIZ_HEADERS WHERE QH_ID = :QUIZ_QH_ID", [req.params.QUIZ_QH_ID], {
            outFormat: oracledb.OBJECT // Return the result as Object
        }, function (err, result) {
            if (err || result.rows.length < 1) {
                res.set('Content-Type', 'application/json');
                var status = err ? 500 : 404;
                res.status(status).send(JSON.stringify({
                    status: status,
                    message: err ? "Error getting the those quiz Numbers" : "Quiz Numbers doesn't exist",
                    detailed_message: err ? err.message : ""
                }));
            } else {
                res.contentType('application/json').status(200).send(JSON.stringify(result.rows));
            }
            // Release the connection
            connection.release(
                function (err) {
                    if (err) {
                        console.error(err.message);
                    } else {
                        console.log("GET /lessonquizno/" + req.params.QUIZ_QH_ID + " : Connection released");
                    }
                });
        });
    });
});


//selecting class Available Subjects
/////////////////
router.get('/staffSub/:CODE_ID', function (req, res) {
    "use strict";

    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }

        connection.execute("SELECT SUBJECT_CODE FROM  IQUIZ.IQ_CLASS_APPLICABLE_SUBJECTS WHERE CLASS_LEVEL_CODE = :CODE_ID AND NVL(ACTIVE_YN,'X') = 'Y'", [req.params.CODE_ID], {
            outFormat: oracledb.OBJECT // Return the result as Object
        }, function (err, result) {
            if (err || result.rows.length < 1) {
                res.set('Content-Type', 'application/json');
                var status = err ? 500 : 404;
                res.status(status).send(JSON.stringify({
                    status: status,
                    message: err ? "Error getting the list of Subjects" : "Subjects doesn't exist",
                    detailed_message: err ? err.message : ""
                }));
            } else {
                res.contentType('application/json').status(200).send(JSON.stringify(result.rows));
            }
            // Release the connection
            connection.release(
                function (err) {
                    if (err) {
                        console.error(err.message);
                    } else {
                        console.log("GET /staffSub/" + req.params.CODE_ID + " : Connection released");
                    }
                });
        });
    });
});


///////////////
/////////////////////// Insert into the Setting QuizHeader

router.post('/setHeader', function post(req, res, next) {


    var user = {

        entity_sys_id: req.body.entity_sys_id,
        class_level_code: req.body.class_level_code,
        subject_code: req.body.subject_code,
        quiz_description: req.body.quiz_description,
        created_by: req.body.created_by,
        prepared_by: req.body.prepared_by,
        brand: req.body.brand
       
    };

    quizHeader(user, function (err, user) {

        var payload;

        if (err) {

            return next(err);

        }

        payload = {

            sub: user.entity_sys_id,

            class_level_code: user.class_level_code,

            subject_code: user.subject_code,

            quiz_description: user.quiz_description,

            created_by: user.created_by,

            prepared_by: user.prepared_by,

            brand: user.brand

        };

        res.status(200).json({

            user: user,

          //  token: jwt.sign(payload, config.jwtSecretKey, { expiresInMinutes: 60 })

        });

    });
   
});

// module.exports.post = post;

function quizHeader(user, cb) {

    "use strict";
    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB please try after sometimes",
                detailed_message: err.message
            }));
            return;
        }

                connection.execute(

                    'insert into  IQUIZ.IQ_PRE_QUIZ_HEADERS( ' +

                    '   entity_sys_id, ' +

                    '   class_level_code, ' +

                    '   subject_code, ' +

                    '   quiz_description, ' +

                    '   created_by, ' +

                    '   prepared_by, ' +

                    '   brand, ' +

                    '   created_date, ' +

                    '   prepared_date ' +

                    ') ' +

                    'values (' +

                    '    :entity_sys_id, ' +

                    '    :class_level_code, ' +

                    '    :subject_code, ' +

                    '    :quiz_description, ' +

                    '   :created_by, ' +

                    '   :prepared_by, ' +

                    '   :brand, ' +

                    '   sysdate, ' +

                    '   sysdate ' +

                    ') ' +

                    'returning ' +

                    '    pqh_id, ' +

                    '   entity_sys_id, ' +

                    '   class_level_code, ' +

                    '   subject_code, ' +
                    
                    '   quiz_description ' +

                    'into ' +

                    '   :rpqh_id, ' +

                    '   :rentity_sys_id, ' +

                    '   :rclass_level_code, ' +

                    '  :rsubject_code ,' +

                    '   :rquiz_description',


                    {


                        entity_sys_id: user.entity_sys_id,

                        class_level_code: user.class_level_code,

                        subject_code: user.subject_code,

                        quiz_description: user.quiz_description,

                        created_by: user.created_by,

                        prepared_by: user.prepared_by,

                        brand: user.brand,

                        rpqh_id: {

                            type: oracledb.NUMBER,

                            dir: oracledb.BIND_OUT

                        },

                        rentity_sys_id: {

                            type: oracledb.NUMBER,

                            dir: oracledb.BIND_OUT

                        },

                        rclass_level_code: {

                            type: oracledb.STRING,

                            dir: oracledb.BIND_OUT

                        },

                        rsubject_code: {

                            type: oracledb.STRING,

                            dir: oracledb.BIND_OUT

                        },

                        rquiz_description: {

                            type: oracledb.STRING,

                            dir: oracledb.BIND_OUT

                        }

                    },

                    {

                        autoCommit: true

                    },

                    function (err, results) {

                        if (err) {

                            connection.release(function (err) {

                                if (err) {

                                    console.error(err.message);

                                }

                            });

                            return cb(err);

                        }

                        cb(null, {

                            pqh_id: results.outBinds.rpqh_id[0],

                            entity_sys_id: results.outBinds.rentity_sys_id[0],

                            class_level_code: results.outBinds.rclass_level_code[0],
                            

                            subject_code: results.outBinds.rsubject_code[0],

                            quiz_description: results.outBinds.rquiz_description[0]
                            

                        });

                        connection.release(
                            function (err) {
                                if (err) {
                                    console.error(err.message);
                                } else {
                                    console.log("POST /setHeader: Connection released");
                                }
                            });;

                    });


    })
};


//////////////////////////////// Iquiz Admin login


router.post('/loginAdminapp', function (req, res, next) {
    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }
        console.log('req.body', req.body);

        connection.execute(

            'select entity_category as "entity_category", ' +

            '   entity_sys_id as "entity_sys_id", ' +

            '   surname as "surname", ' +

            '  other_names as "other_names", ' +

            '  dob as "dob", ' +

            '  town as "town", ' +

            '  country as "country", ' +
          
            '  mobile_number as "mobile_number", ' +
           
            '  email as "email", ' +

            '  registration_date  as "registration_date", ' +

            '  username as "username", ' +

            '  passwrd as "passwrd" ' +            

            ' from iquiz.IQV_TEACHER_ENTITIES' +

           // ' where teacher_yn is not null' +

            ' where username = :username',

            {

               // email: req.body.email.toLowerCase()
             //   Yes: 'Y'
               username: req.body.username

            },

            {

                outFormat: oracledb.OBJECT

            },

            function (err, result) {
                if (err || result.rows.length < 1) {
                    res.set('Content-Type', 'application/json');
                    var status = err ? 500 : 404;
                    res.status(status).send(JSON.stringify({
                        status: status,
                        message: err ? "Error getting the that Username It seems you are not approved yet. Please contact systemAdmin" : "Username you have entered is Incorrect. Kindly Try Again. or Contact systemadmin",
                        detailed_message: err ? err.message : ""
                    }));

                    return next(err);

                }

                user = result.rows[0];




                bcrypt.compare(req.body.password, user.passwrd, function (err, pwMatch) {

                    var payload;

                    if (err) {

                        return next(err);

                    }

                    if (!pwMatch) {

                        res.status(401).send({ message: 'Wrong Password. please Try Again .' });

                        return;

                    }

                    payload = {

                       // sub: user.email,
                        sub: user.username,

                        // password : user.password,

                        entity_sys_id: user.entity_sys_id,
                        
                        surname: user.surname,

                        other_names: user.other_names,

                        dob: user.dob,
                       
                        town: user.town ,
                        
                        country: user.country,

                        mobile_number: user.mobile_number,

                        // username: user.username,
                        email: user.email,

                        registration_date: user.registration_date


                    };

                    res.status(200).json({

                        user: user,
                       
                        email: user.email,

                        // password : user.password,

                        username: user.username, 

                        entity_category: user.entity_category,
                           
                        entity_sys_id: user.entity_sys_id,

                        surname: user.surname,


                        other_names: user.other_names,

                        dob: user.dob,

                        town: user.town,

                        country: user.country,

                        mobile_number: user.mobile_number,

                        registration_date: user.registration_date,


                        token: jwt.sign(payload, config.jwtSecretKey, {  expiresIn : 60*60*1 })

                    });

                });

                connection.release(
                    function (err) {
                        if (err) {
                            console.error(err.message);
                        } else {
                            console.log("POST /loginAdminapp: Connection released");
                        }
                    });

            });

    }

    );

});



///////////////
/////////////////////// Insert into the Setting QuizQuestions


///////////////
/////////////////////// Insert into the Setting QuizHeader

router.post('/setQuestion', function post(req, res, next) {


    var user = {

        question_sequence: req.body.question_sequence,
        question_passage: req.body.question_passage,
        question_narration: req.body.question_narration,
        passage_header: req.body.passage_header,
        created_by: req.body.created_by,
        pqh_id: req.body.pqh_id
       
    };

    quizQuestions(user, function (err, user) {

        var payload;

        if (err) {

            return next(err);

        }

        payload = {

            sub: user.pqh_id,

            question_narration: user.question_narration,

            question_passage: user.question_passage,

            question_sequence: user.question_sequence,

            created_by: user.created_by,

            passage_header: user.passage_header

        };

        res.status(200).json({

            user: user,

          //  token: jwt.sign(payload, config.jwtSecretKey, { expiresInMinutes: 60 })

        });

    });
   
});

// module.exports.post = post;

function quizQuestions(user, cb) {

    "use strict";
    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB please try after sometimes",
                detailed_message: err.message
            }));
            return;
        }

                connection.execute(

                    'insert into  IQUIZ.IQ_PRE_QUIZ_QUESTIONS( ' +

                    '   pqh_id, ' +

                    '   question_sequence, ' +

                    '   question_passage, ' +

                    '   question_narration, ' +

                    '   passage_header, ' +

                    '   created_by, ' +

                 //   '   prepared_by, ' +

                    '   created_date ' +

                    ') ' +

                    'values (' +

                    '    :pqh_id, ' +

                    '    :question_sequence, ' +

                    '    :question_passage, ' +

                    '    :question_narration, ' +

                    '    :passage_header, ' +

                    '   :created_by, ' +

                    '   sysdate ' +

                    ') ' +

                    'returning ' +

                    '    pqq_id, ' +

                    '    pqh_id, ' +

                    '   question_sequence, ' +

                    '   passage_header ' +
                    
                   // '   quiz_description ' +

                    'into ' +

                    '   :rpqq_id, ' +

                    '   :rpqh_id, ' +

                    '   :rquestion_sequence, ' +

                    '   :rpassage_header',


                    {


                        pqh_id: user.pqh_id,

                        question_narration: user.question_narration,

                        question_passage: user.question_passage,

                        question_sequence: user.question_sequence,

                        created_by: user.created_by,

                        passage_header: user.passage_header,

                        rpqh_id: {

                            type: oracledb.NUMBER,

                            dir: oracledb.BIND_OUT

                        },

                        rpqq_id: {

                            type: oracledb.NUMBER,

                            dir: oracledb.BIND_OUT

                        },

                        rquestion_sequence: {

                            type: oracledb.NUMBER,

                            dir: oracledb.BIND_OUT

                        },

                        rpassage_header: {

                            type: oracledb.STRING,

                            dir: oracledb.BIND_OUT

                        }

                    },

                    {

                        autoCommit: true

                    },

                    function (err, results) {

                        if (err) {

                            connection.release(function (err) {

                                if (err) {

                                    console.error(err.message);

                                }

                            });

                            return cb(err);

                        }

                        cb(null, {

                            pqh_id: results.outBinds.rpqh_id[0],

                            pqq_id: results.outBinds.rpqq_id[0],

                            question_sequence: results.outBinds.rquestion_sequence[0],                            

                            passage_header: results.outBinds.rpassage_header[0]

                           
                            

                        });

                        connection.release(
                            function (err) {
                                if (err) {
                                    console.error(err.message);
                                } else {
                                    console.log("POST /setQuestion: Connection released");
                                }
                            });;

                    });


    })
};


// Http method: POST
// URI        : /user Admin posting Answers

router.post('/setAnswer', function (req, res) {
    "use strict";
    console.log('req.body',req.body);
    if ("application/json" !== req.get('Content-Type')) {
        res.set('Content-Type', 'application/json').status(415).send(JSON.stringify({
            status: 415,
            message: "Wrong content-type. Only application/json is supported",
            detailed_message: null
        }));
        return;
    }
    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json').status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }
        console.log('req.body',req.body);
        connection.execute("INSERT INTO IQUIZ.IQ_PRE_QUIZ_ANSWERS (PQQ_ID, ANSWER_ID, ANSWER_NARRATION, CORRECT_YN, CORRECT_YN_EXPLANATION) VALUES " +
            "(:PQQ_ID, :ANSWER_ID, :ANSWER_NARRATION, :CORRECT_YN, :CORRECT_YN_EXPLANATION)",
             [req.body.pqq_id, req.body.answer_id, req.body.answer_narration,  req.body.correct_yn, req.body.correct_yn_explanation,],
           //  [req.body.pqq_id, req.body.answer_id1, req.body.answer_narration1,  req.body.correct_yn1, req.body.correct_yn_explanation1,],
            // [req.body.pqq_id, req.body.answer_id2, req.body.answer_narration2,  req.body.correct_yn2, req.body.correct_yn_explanation2,],
            // [req.body.pqq_id, req.body.answer_id3, req.body.answer_narration3,  req.body.correct_yn3, req.body.correct_yn_explanation3,],
              {
                autoCommit: true,
                outFormat: oracledb.OBJECT // Return the result as Object
            },
            function (err, result) {
                if (err) {
                    // Error
                    res.set('Content-Type', 'application/json');
                    res.status(400).send(JSON.stringify({
                        status: 400,
                        message: err.message.indexOf("ORA-00001") > -1 ? "Problem posting your Answers" : "Input Error",
                        detailed_message: err.message
                    }));
                } else {
                    // Successfully created the resource
                    res.status(201).set('Location', '/query/' + req.body.pqq_id).end();
                }
                // Release the connection
                connection.release(
                    function (err) {
                        if (err) {
                            console.error(err.message);
                        } else {
                            console.log("POST /setAnswer: Connection released");
                        }
                    });
            });
    });
});


//selecting already set Question
/////////////////
router.get('/alreadyQuestion/:PQH_ID', function (req, res) {
    "use strict";

    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }

        connection.execute("SELECT PQQ_ID, QUESTION_SEQUENCE, QUESTION_PASSAGE, QUESTION_NARRATION, PASSAGE_HEADER FROM IQUIZ.IQ_PRE_QUIZ_QUESTIONS WHERE PQH_ID = :PQH_ID", [req.params.PQH_ID], {
            outFormat: oracledb.OBJECT // Return the result as Object
        }, function (err, result) {
            if (err || result.rows.length < 1) {
                res.set('Content-Type', 'application/json');
                var status = err ? 500 : 404;
                res.status(status).send(JSON.stringify({
                    status: status,
                    message: err ? "Error getting the list of QUESTION" : "SORRY YOU HAVE NO QUESTIONS",
                    detailed_message: err ? err.message : ""
                }));
            } else {
                res.contentType('application/json').status(200).send(JSON.stringify(result.rows));
            }
            // Release the connection
            connection.release(
                function (err) {
                    if (err) {
                        console.error(err.message);
                    } else {
                        console.log("GET /alreadyQuestion/" + req.params.PQH_ID + " : Connection released");
                    }
                });
        });
    });
});


//selecting already set Question ANSWERS
/////////////////
router.get('/alreadyAnswers/:PQQ_ID', function (req, res) {
    "use strict";

    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }

        connection.execute("SELECT PQQ_ID, PQA_ID, ANSWER_ID, ANSWER_NARRATION, CORRECT_YN, CORRECT_YN_EXPLANATION FROM IQUIZ.IQ_PRE_QUIZ_ANSWERS WHERE PQQ_ID = :PQQ_ID", [req.params.PQQ_ID], {
            outFormat: oracledb.OBJECT // Return the result as Object
        }, function (err, result) {
            if (err || result.rows.length < 1) {
                res.set('Content-Type', 'application/json');
                var status = err ? 500 : 404;
                res.status(status).send(JSON.stringify({
                    status: status,
                    message: err ? "Error getting the list of ANSWERS" : "SORRY YOU HAVE NO ANSWERS",
                    detailed_message: err ? err.message : ""
                }));
            } else {
                res.contentType('application/json').status(200).send(JSON.stringify(result.rows));
            }
            // Release the connection
            connection.release(
                function (err) {
                    if (err) {
                        console.error(err.message);
                    } else {
                        console.log("GET /alreadyAnswers/" + req.params.PQQ_ID + " : Connection released");
                    }
                });
        });
    });
});



//////////////////////////
////////////////////////UPDATING QUESTIONS
router.post('/questionUpdate', function (req, res) {
    "use strict";
    console.log('req.body', req.body);
    if ("application/json" !== req.get('Content-Type')) {
        res.set('Content-Type', 'application/json').status(415).send(JSON.stringify({
            status: 415,
            message: "Wrong content-type. Only application/json is supported",
            detailed_message: null
        }));
        return;
    }
    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json').status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }
        console.log('req.body', req.body);
        connection.execute("begin IQUIZ.CALL_UPD_PRE_QUIZ_QUESTIONS (:P_PQH_ID, :P_PQQ_ID, :P_PASSAGE_HEADER, :P_QUESTION_NARRATION, :P_QUESTION_PASSAGE, :P_QUESTION_SEQUENCE, :P_MODIFIED_BY); end;",
             [req.body.pqh_id, req.body.pqq_id, req.body.passage_header, req.body.question_narration, req.body.question_passage, req.body.question_sequence, req.body.modified_by,],
            {
                autoCommit: true,
                outFormat: oracledb.OBJECT // Return the result as Object
            },
            function (err, result) {
                if (err) {
                    // Error
                    res.set('Content-Type', 'application/json');
                    res.status(400).send(JSON.stringify({
                        status: 400,
                        message: err.message.indexOf("ORA-00001") > -1 ? "Problem updating your question contact systemadmin" : "Input Error",
                        detailed_message: err.message
                    }));
                } else {
                    // Successfully created the resource
                    res.status(201).set('Location', '/query/' + req.body.pqq_id).end();
                }
                // Release the connection
                connection.release(
                    function (err) {
                        if (err) {
                            console.error(err.message);
                        } else {
                            console.log("POST /questionUpdate: Connection released");
                        }
                    });
            });
    });
});




//////////////////////////
////////////////////////UPDATING Existing Answers by Admin
router.post('/AnswersUpdate', function (req, res) {
    "use strict";
    console.log('req.body', req.body);
    if ("application/json" !== req.get('Content-Type')) {
        res.set('Content-Type', 'application/json').status(415).send(JSON.stringify({
            status: 415,
            message: "Wrong content-type. Only application/json is supported",
            detailed_message: null
        }));
        return;
    }
    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json').status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }
        console.log('req.body', req.body);
        connection.execute("begin IQUIZ.CALL_UPD_PRE_QUIZ_ANSWERS (:P_PQA_ID , :P_PQQ_ID , :P_ANSWER_ID , :P_ANSWER_NARRATION ,:P_CORRECT_YN , :P_CORRECT_YN_EXPLANATION ); end;",
             [req.body.pqa_id, req.body.pqq_id, req.body.answer_id, req.body.answer_narration, req.body.correct_yn, req.body.correct_yn_explanation,],
            {
                autoCommit: true,
                outFormat: oracledb.OBJECT // Return the result as Object
            },
            function (err, result) {
                if (err) {
                    // Error
                    res.set('Content-Type', 'application/json');
                    res.status(400).send(JSON.stringify({
                        status: 400,
                        message: err.message.indexOf("ORA-00001") > -1 ? "Problem updating your Answers contact systemadmin" : "Input Error",
                        detailed_message: err.message
                    }));
                } else {
                    // Successfully created the resource
                    res.status(201).set('Location', '/query/' + req.body.pqq_id).end();
                }
                // Release the connection
                connection.release(
                    function (err) {
                        if (err) {
                            console.error(err.message);
                        } else {
                            console.log("POST /AnswersUpdate: Connection released");
                        }
                    });
            });
    });
});



//selecting already set incomplete Question 
/////////////////
router.get('/adminIncomplete/:ENTITY_SYS_ID', function (req, res) {
    "use strict";

    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }

        connection.execute("SELECT * FROM IQUIZ.IQ_PRE_QUIZ_HEADERS WHERE LINKED_QH_ID IS NULL AND ENTITY_SYS_ID = :ENTITY_SYS_ID", [req.params.ENTITY_SYS_ID], {
            outFormat: oracledb.OBJECT // Return the result as Object
        }, function (err, result) {
            if (err || result.rows.length < 1) {
                res.set('Content-Type', 'application/json');
                var status = err ? 500 : 404;
                res.status(status).send(JSON.stringify({
                    status: status,
                    message: err ? "Error getting the list of QUESTIONS" : "SORRY YOU HAVE NO INCOMPLETE OR UNAPROVED QUESTIONS",
                    detailed_message: err ? err.message : ""
                }));
            } else {
                res.contentType('application/json').status(200).send(JSON.stringify(result.rows));
            }
            // Release the connection
            connection.release(
                function (err) {
                    if (err) {
                        console.error(err.message);
                    } else {
                        console.log("GET /adminIncomplete/" + req.params.ENTITY_SYS_ID + " : Connection released");
                    }
                });
        });
    });
});



//selecting already set complete and aprroved Question 
/////////////////
router.get('/admincomplete/:ENTITY_SYS_ID', function (req, res) {
    "use strict";

    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }

        connection.execute("SELECT * FROM IQUIZ.IQ_PRE_QUIZ_HEADERS WHERE LINKED_QH_ID IS NOT NULL AND ENTITY_SYS_ID = :ENTITY_SYS_ID", [req.params.ENTITY_SYS_ID], {
            outFormat: oracledb.OBJECT // Return the result as Object
        }, function (err, result) {
            if (err || result.rows.length < 1) {
                res.set('Content-Type', 'application/json');
                var status = err ? 500 : 404;
                res.status(status).send(JSON.stringify({
                    status: status,
                    message: err ? "Error getting the list of QUESTIONS" : "SORRY YOU HAVE NO APPROVED QUESTIONS",
                    detailed_message: err ? err.message : "IF YOU ARE SURE YOU SHOULD HAVE. Please contact the system Admin"
                }));
            } else {
                res.contentType('application/json').status(200).send(JSON.stringify(result.rows));
            }
            // Release the connection
            connection.release(
                function (err) {
                    if (err) {
                        console.error(err.message);
                    } else {
                        console.log("GET /admincomplete/" + req.params.ENTITY_SYS_ID + " : Connection released");
                    }
                });
        });
    });
});


//////////////////////////
////////////////////////Starting the Quiz set process by a procidure
router.post('/QuestionSet', function (req, res) {
    "use strict";
    console.log('req.body', req.body);
    if ("application/json" !== req.get('Content-Type')) {
        res.set('Content-Type', 'application/json').status(415).send(JSON.stringify({
            status: 415,
            message: "Wrong content-type. Only application/json is supported",
            detailed_message: null
        }));
        return;
    }
    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json').status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }
        console.log('req.body', req.body);
        connection.execute("begin IQUIZ.IQ_APPROVE_PRE_QUIZ (:P_PQH_ID, :P_USER); end;",
             [req.body.pqh_id, req.body.created_by,],
            {
                autoCommit: true,
                outFormat: oracledb.OBJECT // Return the result as Object
            },
            function (err, result) {
                if (err) {
                    // Error
                    res.set('Content-Type', 'application/json');
                    res.status(400).send(JSON.stringify({
                        status: 400,
                        message: err.message.indexOf("ORA-00001") > -1 ? "Problem Setting the Quiz" : "Setting Quiz Error. Contact systemAdmin",
                        detailed_message: err.message
                    }));
                } else {
                    // Successfully created the resource
                    res.status(201).set('Location', '/query/' + req.body.pqh_id).end();
                }
                // Release the connection
                connection.release(
                    function (err) {
                        if (err) {
                            console.error(err.message);
                        } else {
                            console.log("POST /QuestionSet: Connection released");
                        }
                    });
            });
    });
});



//selecting LIST OF SUBJECTS THAT YOU HAVE DONE THEIR QUIZ FOR QUIZ ANALYSIS
/////////////////
router.get('/iquizPerfom/:ENTITY_SYS_ID', function (req, res) {
    "use strict";

    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }

        connection.execute("SELECT DISTINCT CLASS_LEVEL_CODE FROM IQUIZ.VW_A_PERFORM_CLASSSUBJECTWISE  WHERE YOUR_MEAN_SCORE IS NOT NULL AND ENTITY_SYS_ID =:ENTITY_SYS_ID", [req.params.ENTITY_SYS_ID], {
            outFormat: oracledb.OBJECT // Return the result as Object
        }, function (err, result) {
            if (err || result.rows.length < 1) {
                res.set('Content-Type', 'application/json');
                var status = err ? 500 : 404;
                res.status(status).send(JSON.stringify({
                    status: status,
                    message: err ? "Error getting the list of SUBJECTS DONE" : "SORRY YOU DONT HAVE ANY RECORD",
                    detailed_message: err ? err.message : "IF YOU ARE SURE YOU SHOULD HAVE. Please contact the system Admin"
                }));
            } else {
                res.contentType('application/json').status(200).send(JSON.stringify(result.rows));
            }
            // Release the connection
            connection.release(
                function (err) {
                    if (err) {
                        console.error(err.message);
                    } else {
                        console.log("GET /iquizPerfom/" + req.params.ENTITY_SYS_ID + " : Connection released");
                    }
                });
        });
    });
});




//selecting LIST OF SUBJECTS performance THAT YOU HAVE DONE THEIR QUIZ FOR QUIZ ANALYSIS
/////////////////
router.get('/iquizGraph/:CLASS_LEVEL_CODE/:ENTITY_SYS_ID', function (req, res) {
    "use strict";

    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }

        connection.execute("SELECT * FROM IQUIZ.VW_A_PERFORM_CLASSSUBJECTWISE WHERE YOUR_MEAN_SCORE IS NOT NULL AND CLASS_LEVEL_CODE =:CLASS_LEVEL_CODE AND ENTITY_SYS_ID =:ENTITY_SYS_ID", [req.params.CLASS_LEVEL_CODE, req.params.ENTITY_SYS_ID], {
            outFormat: oracledb.OBJECT // Return the result as Object
        }, function (err, result) {
            if (err || result.rows.length < 1) {
                res.set('Content-Type', 'application/json');
                var status = err ? 500 : 404;
                res.status(status).send(JSON.stringify({
                    status: status,
                    message: err ? "Error getting the list of SUBJECTS Performance" : "SORRY YOU DONT HAVE ANY RECORD",
                    detailed_message: err ? err.message : "IF YOU ARE SURE YOU SHOULD HAVE. Please contact the system Admin"
                }));
            } else {
                res.contentType('application/json').status(200).send(JSON.stringify(result.rows));
            }
            // Release the connection
            connection.release(
                function (err) {
                    if (err) {
                        console.error(err.message);
                    } else {
                        console.log("GET /iquizGraph/" + req.params.CLASS_LEVEL_CODE + "/"+ req.params.ENTITY_SYS_ID + " : Connection released");
                    }
                });
        });
    });
});



//selecting LIST OF All Results THAT YOU HAVE DONE THEIR QUIZ FOR QUIZ ANALYSIS
/////////////////
router.get('/yourResultIquiz/:ENTITY_SYS_ID', function (req, res) {
    "use strict";

    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }

        connection.execute("SELECT * FROM IQUIZ.VW_A_PERFORMANCE_ALL WHERE PERCENTAGE IS NOT NULL AND ENTITY_SYS_ID =:ENTITY_SYS_ID", [req.params.ENTITY_SYS_ID], {
            outFormat: oracledb.OBJECT // Return the result as Object
        }, function (err, result) {
            if (err || result.rows.length < 1) {
                res.set('Content-Type', 'application/json');
                var status = err ? 500 : 404;
                res.status(status).send(JSON.stringify({
                    status: status,
                    message: err ? "Error getting the list of Overal Performance" : "SORRY YOU DONT HAVE ANY RECORD",
                    detailed_message: err ? err.message : "IF YOU ARE SURE YOU SHOULD HAVE. Please contact the system Admin"
                }));
            } else {
                res.contentType('application/json').status(200).send(JSON.stringify(result.rows));
            }
            // Release the connection
            connection.release(
                function (err) {
                    if (err) {
                        console.error(err.message);
                    } else {
                        console.log("GET /yourResultIquiz/" + req.params.ENTITY_SYS_ID + " : Connection released");
                    }
                });
        });
    });
});


/////////////////////
//////////////////////// Teacher Iquiz Brands
//viewing CLASS from db
router.get('/iquizbrand', function (req, res) {
    "use strict";

    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }

        connection.execute("SELECT CODE_ID, CODE_DESCRIPTION FROM  IQUIZ.IQ_GENERAL_CODES WHERE CODE_TYPE = 'QUIZ_BRAND'", {}, {
            outFormat: oracledb.OBJECT // Return the result as Object
        }, function (err, result) {
            if (err) {
                res.set('Content-Type', 'application/json');
                res.status(500).send(JSON.stringify({
                    status: 500,
                    message: "Error getting the Class list",
                    detailed_message: err.message
                }));
            } else {

                res.contentType('application/json').status(200);
                res.send(JSON.stringify(result.rows));
            }
            // Release the connection
            connection.release(
                function (err) {
                    if (err) {
                        console.error(err.message);
                    } else {
                        console.log("GET /iquizbrand : Connection released");
                    }
                });
        });

    });
});


/////////////////////////////last exam1 trial submit
///////////////////
router.post('/exam1', function (req, res) {
    "use strict";
    console.log('req.body', req.body);
   /* if ("application/json" == req.get('Content-Type')) {
        res.set('Content-Type', 'application/json').status(415).send(JSON.stringify({
            status: 415,
            message: "Wrong content-type. Only application/json is supported",
            detailed_message: null
        }));
        return;
    } */
    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json').status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }
        console.log('req.body', req.body);
        connection.execute("INSERT INTO IQUIZ.IQ_STUDENT_QUIZ_HEADERS(entity_sys_id, class_level_code, subject_code, quiz_number ) VALUES" +
        " (:entity_sys_id, :class_level_code, :subject_code, :quiz_number)",
             [req.body.entity_sys_id, req.body.class_level_code, req.body.subject_code, req.body.quiz_number, ],
            {
                autoCommit: true,
                outFormat: oracledb.OBJECT // Return the result as Object
            },
            function (err, result) {
                if (err) {
                    // Error
                    res.set('Content-Type', 'application/json');
                    res.status(400).send(JSON.stringify({
                        status: 400,
                        message: err.message.indexOf("ORA-00001") > -1 ? "Problem posting your query contact systemadmin" : "Input Error",
                        detailed_message: err.message
                    }));
                } else {
                    // Successfully created the resource
                    res.status(201).set('Location', '/query/' + req.body.entity_sys_id).end();
                }
                // Release the connection
                connection.release(
                    function (err) {
                        if (err) {
                            console.error(err.message);
                        } else {
                            console.log("POST /exam1: Connection released");
                        }
                    });
            });
    });
});

module.exports = router;