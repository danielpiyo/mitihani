
/////Testing new quatation endpoint

router.post('/newQuote', function post(req, res, next) {


    var user = {

        p_client_code: req.body.p_client_code,
        p_broker_code: req.body.p_broker_code,
        p_risk_name: req.body.p_risk_name,
        p_branch: req.body.p_branch,

        p_class: req.body.p_class,
        p_classgrp: req.body.p_classgrp,
        p_classsect: req.body.p_classsect,
        p_start_date: req.body.p_start_date,

        p_end_date: req.body.p_end_date,
        p_age: req.body.p_age,
        p_sum_insured: req.body.p_sum_insured,
        p_user_id: req.body.p_user_id,
        p_control_no: req.body.p_control_no,
        p_premium: req.body.p_premium

       
    };

    applyQuote(user, function (err, user) {

        var payload;

        if (err) {

            return next(err);

        }

        payload = {

            sub: user.p_client_code,

            p_broker_code: user.p_broker_code,

            p_risk_name: user.p_risk_name,

            p_sum_insured: user.p_sum_insured

        };

        res.status(200).json({

            user: user,

          //  token: jwt.sign(payload, config.jwtSecretKey, { expiresInMinutes: 60 })

        });

    });
   
});

// module.exports.post = post;

function applyQuote(user, cb) {

    "use strict";
    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB please try after sometimes",
                detailed_message: err.message
            }));
            return;
        }

        connection.execute("begin CGIB.GEN_UW_QUOTE_NEW( :p_client_code , :p_broker_code ,:p_risk_name,:p_branch,:p_class ," +
                "        :p_classgrp,:p_classsect,TO_DATE(:p_start_date,'YYYY-MM-DD'),TO_DATE(:p_end_date,'YYYY-MM-DD'),:p_age,:p_sum_insured," +
                "       :p_user_id,:p_control_no,:p_premium ) " +
               "        End " +

            "returning " +

            "   p_premium, " +
            
            "   p_control_no " +

            "into " +

            "   :rp_premium, " +
           
            "   :rp_control_no",


                    {


                        p_client_code: user.p_client_code,
                        p_broker_code: user.p_broker_code,
                        p_risk_name: user.p_risk_name,
                        p_branch: user.p_branch,
                
                        p_class: user.p_class,
                        p_classgrp: user.p_classgrp,
                        p_classsect: user.p_classsect,
                        p_start_date: user.p_start_date,
                
                        p_end_date: user.p_end_date,
                        p_age: user.p_age,
                        p_sum_insured: user.p_sum_insured,
                        p_user_id: user.p_user_id,
                        p_control_no: user.p_control_no,
                        p_premium: user.p_premium,

                        rp_premium: {

                            type: oracledb.NUMBER,

                            dir: oracledb.BIND_OUT

                        },                        

                        rp_control_no: {

                            type: oracledb.NUMBER,

                            dir: oracledb.BIND_OUT

                        }

                    },

                    {

                        autoCommit: true

                    },

                    function (err, results) {

                        if (err) {

                            connection.release(function (err) {

                                if (err) {
                              //  res.set('Content-Type', 'application/json');

            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(203).send(JSON.stringify({
                status: 203,
                message: "Error posting Data",
                detailed_message: err.message
            }));
            return;
        

                               //     console.error(err.message);

                                }

                            });

                            return cb(err);

                        }

                        cb(null, {

                            p_premium: results.outBinds.rp_premium[0],

                            p_control_no: results.outBinds.rp_control_no[0]
                            

                        });

                        connection.release(
                            function (err) {
                                if (err) {
                              //  res.set('Content-Type', 'application/json');
                                    console.error(err.message);
                                } else {
                                    console.log("POST /newQuatation: Connection released");
                                }
                            });;

                    });


    })
};
