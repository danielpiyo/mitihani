import { QuizConfig } from './quiz-config';
import { Question } from './question';

export class Quiz {
    id: number;
    number: number;
    secondary: string;
    requires_actual_answer_yn: string;
    description: string;
    config: QuizConfig;
    questions: Question[];

    constructor(data: any) {
        if (data) {
            this.id = data.id;
            this.number = data.number;
            this.secondary = data.secondary;
            this.requires_actual_answer_yn = data.requires_actual_answer_yn;
            this.description = data.description;
            this.config = new QuizConfig(data.config);
            this.questions = [];
             data.questions.forEach((question) => {
                this.questions.push(new Question(question));
            });
        }
    }
}
