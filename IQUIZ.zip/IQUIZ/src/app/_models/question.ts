import { Option } from './option';

export class Question {
    id: number;
    name: string;
    image: string;
    answer_narration: String;
    answer_image_link: String;
    questionTypeId: number;
    passage: any;   
    requires_actual_answer_yn: any;  
    shared_map_yn: any;
    actual_answer: any;  
    typedAnswered: any;
    before_image_link: any;
    passage_header: string;
    display_passage_yn: any;
    other_passage: string;
    options: Option[];
    answered: any;

    constructor(data: any) {
        data = data || {};
        this.id = data.id;
        this.image = data.image;
        this.answer_narration = data.answer_narration;
        this.answer_image_link = data.answer_image_link;
        this.name = data.name;
        this.questionTypeId = data.questionTypeId;
        this.passage = data.passage; 
        this.actual_answer = data.actual_answer;       
        this.requires_actual_answer_yn = data.requires_actual_answer_yn; 
        this.shared_map_yn = data.shared_map_yn;  
        this.before_image_link= data.before_image_link;
        this.passage_header= data.passage_header;
        this.display_passage_yn = data.display_passage_yn;
        this.other_passage = data.other_passage;     
        this.options = [];
        data.options.forEach(o => {
            this.options.push(new Option(o));
        });
    }
}
