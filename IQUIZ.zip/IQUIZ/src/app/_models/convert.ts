export class IsAnswer {
    function(isAnswer){
        switch(isAnswer.toLowerCase().trim()){
            case "True": case "Y":  return true;
            case "false": case "N": case null: return false;
            default: return Boolean(isAnswer);
        }
    }
}