export class Exam {
    sqh_id: number;
    entity_sys_id: number;
    class_level_code: string;
    subject_code: string;
    quiz_number: number;
}