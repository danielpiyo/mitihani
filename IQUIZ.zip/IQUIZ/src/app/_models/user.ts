﻿export class User {
    entity_sys_id: number;
    id_number: number;
    id: number;
    surname: String;
    other_names:String;
    mobile_number: string;
    class_id: String;
    code: String; 
    country:String;
    town:String;
    email: string;
    dob: Date;
    breif_narration: String;
    entity_category: String;
   
}
