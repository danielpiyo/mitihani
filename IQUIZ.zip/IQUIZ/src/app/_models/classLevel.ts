export class Level{
    code_id: String;
    code_description: String;
}