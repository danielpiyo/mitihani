import { Sublesson } from './lsub';

export class Lesson {
    lsd_id: number;
    ld_lsh_id: number;
    topic_title: string;
    topic_summary: String;
    topic_image_link: String;
    serial_no: number;    
    sublessons: Sublesson[];
    answered: any;

    constructor(data: any) {
        data = data || {};
        this.lsd_id = data.lsd_id;
        this.ld_lsh_id = data.ld_lsh_id;
        this.topic_title = data.topic_title;
        this.topic_summary = data.topic_summary;
        this.topic_image_link = data.topic_image_link;
        this.serial_no = data.serial_no;                
        this.sublessons = [];
        data.sublessons.forEach(s => {
            this.sublessons.push(new Sublesson(s))
        });
    }
}
