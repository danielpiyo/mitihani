import { QuizConfig } from './quiz-config';
import { Lesson } from './llesson';

export class Head {
    lsh_id: number;
    subject_code: number;
    lesson_description: string;
    lesson_narration: string;
    lesson_summary: string;
    lesson_image_link : string;
    quiz_qh_id : string;
    config: QuizConfig;
    lessons: Lesson[];

    constructor(data: any) {
        if (data) {
            this.lsh_id = data.lsh_id;
            this.subject_code = data.subject_code;
            this.lesson_description = data.lesson_description;
            this.lesson_narration = data.lesson_narration;
            this.lesson_summary = data.lesson_summary;
            this.lesson_image_link = data.lesson_image_link;
            this.quiz_qh_id = data.quiz_qh_id;
            this.config = new QuizConfig(data.config);
            this.lessons = [];
             data.lessons.forEach(l => {
                this.lessons.push(new Lesson(l));
            });
        }
    }
}
