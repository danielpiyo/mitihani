export class Sublesson {
    lsd_id: number;
    serial_no: number;
    sub_title: string;
    narration: string;    
    selected: boolean;
    
    constructor(data: any) {
        data = data || {};
        this.lsd_id = data.lsd_id;
        this.serial_no = data.serial_no;
        this.sub_title = data.sub_title;        
        this.narration = data.narration;
    }
}
