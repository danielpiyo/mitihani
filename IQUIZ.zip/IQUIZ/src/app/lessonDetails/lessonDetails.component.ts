import { Component } from '@angular/core';
import { LessonDetailsService } from './lessonDetails.service';
import { User } from '../_models/index';
import { UserService } from '../_services/index';
import { AlertService } from '../_services/index';
import { Router } from '@angular/router';
import { HomeComponent } from '../home/home.component';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs/Subscription';
import { LessonService } from '../lesson/lesson.service';
import { ActivatedRoute, Params } from '@angular/router';
import { QuoteModel } from '../home/quoteModel';
import { QuizsummaryService } from '../quizsummary/quizsummary.service';
import { LdetailsService } from '../ldetails/ldetails.service';

@Component({
  moduleId: module.id.toString(),
  selector: 'lessonDetails.component',
  templateUrl: 'lessonDetails.component.html',
  providers: [LessonDetailsService]
})

export class LessonDetailsComponent {

  currentUser: User;
  subjectCode: String;
  users: User[] = [];
  testSubject = [];
  allQuiz = [];
  test: String;
  quickQuote: QuoteModel = new QuoteModel();
  quizNumber: Number;
  startQuizSubscription: Subscription;
  toggleMenu = false;

  constructor(
    private _ldetailsService: LdetailsService,
    private quizsummaryService: QuizsummaryService,
    private _lessonService: LessonService,
    private routes: ActivatedRoute,
    private router: Router,
    private _lessonDetailsService: LessonDetailsService,
    private alertService: AlertService) {
    this.currentUser = JSON.parse(localStorage.getItem('currentUser'));

  }

  //  quiz1 :any;
  lessonToken: any;

  ngOnInit() {
    this.testSubject = this._lessonDetailsService.getQuiz();
    // this.quiz1 = this.router.getNavigatedData();
    this.lessonToken = JSON.parse(localStorage.getItem('lesson1'));
    //  console.log('LessonToken', this.lessonToken);
    /// console.log('Wanted', this.quiz1);

  }

  onToggleMenu() {
    if (this.toggleMenu === true) {
      this.toggleMenu = false;
    }
    else {
      this.toggleMenu = true;
    }
  }



  goToLesson(subject_code: any, subject: any) {
    console.log('Selected Subject', subject_code)
    this.test = this.lessonToken + "/" + subject_code
    //  console.log('SubjectCode', this.test);  
    this.subjectCode = subject_code;
    this._lessonService.getTest(this.test)
      .subscribe(
        (response) => {
          this.allQuiz = response;
          //console.log("AllQuiz",this.allQuiz);
          this._ldetailsService.setQuiz(JSON.parse(JSON.stringify(response)))
          ////////////////////

          this.router.navigate(['/l-details']);
          /*this.router.navigateByData({
           url: ['/details'],
           data: this.quizToken, //data - <any> type            
           //extras: {} - <NavigationExtras> type, optional parameter
       });  */

          //  console.log('Quiz', this.allQuiz);
        },
        (error) => {
          this.alertService.error(error.message);
          console.log('error', error);
        });
  }

  logout() {
    localStorage.removeItem('currentUser')
    this.router.navigate(['/']);
  }
}

