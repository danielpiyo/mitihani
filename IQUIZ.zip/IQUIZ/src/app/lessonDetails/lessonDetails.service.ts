import { Injectable } from '@angular/core';
//import { HttpClient } from '@angular/common/http';
import { Http, Headers, RequestOptions, Response } from '@angular/http';  
import { User } from '../_models/index';
//import { Job } from '../_models/index';
import { Observable } from 'rxjs/Observable';  
import { Subject } from 'rxjs/Subject';  
import 'rxjs'; //get everything from Rx  
import 'rxjs/add/operator/toPromise';  

@Injectable()
export class LessonDetailsService {

private static quizSummary:any;
private static quizTest:any;

public _subject = new Subject<any>();

constructor(private _http: Http) {

 }  
 
 

 alert(alertType: string) {
    this._subject.next({ type: alertType });
}

getMessage(): Observable<any> {
    return this._subject.asObservable();
}


getQuiz():any{
    //console.log('this.quizSummary2',localStorage.getItem('ClaimsService.quizSummary'));
    return   JSON.parse(localStorage.getItem('ClaimsService.quizSummary'));
   }

setQuiz(quote:any){

    LessonDetailsService.quizSummary=quote;
   /// console.log('this.quizSummary',LessonDetailsService.quizSummary);
    localStorage.setItem('ClaimsService.quizSummary',JSON.stringify(quote));
    
    
 
}
  
setTest(quiz:any){

    LessonDetailsService.quizTest=quiz;
   // console.log('this.quizTest',LessonDetailsService.quizTest);
    localStorage.setItem('ClaimsService.quizTest',JSON.stringify(quiz));
}
    
getTest():any{
   // console.log('this.quizTest2',localStorage.getItem('ClaimsService.quizTest'));
    return   JSON.parse(localStorage.getItem('ClaimsService.quizTest'));
   } 

   
    
}