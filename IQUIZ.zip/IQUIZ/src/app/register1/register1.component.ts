﻿import { Component } from '@angular/core';
import { Register1Service } from './register1.service';
import { AlertService } from '../_services/index';
import { Router } from '@angular/router';
import { Register1 } from './register1';
import { Observable } from 'rxjs/Observable';
import { Subscription } from 'rxjs';
@Component({
    moduleId: module.id.toString(),
    selector: 'register1.component',
    templateUrl: 'register1.component.html',

    //providers: [Register1Service]  
})

export class Register1Component {
    model: any = {};
    loading = false;
    registrationSubscription: Subscription;
    countriesSubscription: Subscription;
    townSubscription: Subscription;
    countries = [];
    towns = [];
    countryCode: String;
    location = {};
    //query: Observable<any[]>; 

    constructor(
        private router: Router,
        private _register1Service: Register1Service,
        private alertService: AlertService) { }

    ngOnInit() {
        this.getCountry();

       /* if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(position => {
                this.location = position.coords;
                console.log('Location', position.coords);
            });
        }*/
    }
    register() {
         if(this.model.cpasswrd !== this.model.passwrd){
             alert('Your password Do not Match');
             this.loading = false;
         }
         else{
            this.loading = true;
            this.registrationSubscription = this._register1Service.create(this.model)
                .subscribe(
                    data => {
                        // this.alertService.success('Registration successful', true);
                        alert('Registration Succesful')
                        this.router.navigate(['/login']);
                    },
                    error => {
                        // this.alertService.error(error);
                        alert(error.message);
                        this.loading = false;
                    });
            console.log('Model', this.model);
        }
         }
       
    ngonDestroy() {
        if (this.registrationSubscription) {
            this.registrationSubscription.unsubscribe();
        }

    }
    goToLogin() {
        this.router.navigate(['/login']);
    }

    getCountry() {
        this.countriesSubscription = this._register1Service.getCountry()
            .subscribe((data) => {
                this.countries = data;
                //  console.log('Countries', this.countries);
            },
                (error) => {
                    alert(error.message)
                })
    }

    onSelect(country_code: any) {
        console.log('country_code', country_code);
        this.countryCode = country_code;
        this.townSubscription = this._register1Service.getTowns(country_code)
            .subscribe((data) => {
                this.towns = data;
                ///   console.log('Towns', this.towns);
            },
                (error) => {
                    alert(error.message)
                })
    }
}
