export class Register1 {
    constructor(
    email:'String' ,
	town:'String',
	surname:'String',
	dob :'Date',
	entity_category :'String',
	other_names:'String',	
	mobile_number:'String',
	brief_narration:'String',
	country:'String',	
	username:'String',
	passwrd:'String'
    )
    { }
    
}


    