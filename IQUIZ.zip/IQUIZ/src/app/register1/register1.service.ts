import { Injectable } from '@angular/core';
//import { HttpClient } from '@angular/common/http';
import { Http, Headers, RequestOptions, Response } from '@angular/http';  
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';
import { Observable } from 'rxjs/Observable';  
import { Subject } from 'rxjs/Subject';
import 'rxjs'; //get everything from Rx  
import 'rxjs/add/operator/toPromise';  
import { Register1 } from './register1';



@Injectable()
export class Register1Service {
apiUrl: string = "https://www.api.cloudplace.org:4000/api/iquizreg";// Web API URL
apiUrl3: string = "https://www.api.cloudplace.org:4000/api/country/"

 apiUrl4: string = "https://www.api.cloudplace.org:4000/api/town/"

constructor(private _http: Http) { }  


    create(user: Register1) {
        return this._http.post(this.apiUrl, user)
        //.map((res) => res.json())
        .catch((error: any) => Observable.throw('Specified username may have been taken. Please specify a different username.'));
        
    }


getCountry(){
    return this._http.get(this.apiUrl3)
    .map((response) => response.json())
    .catch((error: any) => Observable.throw(error.json() || 'Server error'));
  }
  
  getTowns(country_code:any){
    return this._http.get(this.apiUrl4 + country_code)
    .map((response) => response.json())
    .catch((error: any) => Observable.throw(error.json() || 'Server error'));
  }
}

