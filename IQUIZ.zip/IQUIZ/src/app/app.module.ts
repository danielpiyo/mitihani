﻿import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { HttpModule } from '@angular/http';

import { fakeBackendProvider } from './_helpers/index';
import { QuizdetailsComponent} from './quizdetails/index';
import { QuizdetailsService } from './quizdetails/quizdetails.service';
import { AppComponent } from './app.component';
import { routing } from './app.routing';
import { Register1Service } from './register1/register1.service';
import { HomeService } from './home/home.service';
import { AlertComponent } from './_directives/index';
import { ClaimsComponent } from './claims/index';
import {ClaimsService } from './claims/claims.service';
import { AuthGuard } from './_guards/index';
import { JwtInterceptor } from './_helpers/index';
import { AlertService, UserService, PagerService, HelperService, LessonPagerService } from './_services/index';
import { LoginService } from './login/login.service';
import { HomeComponent } from './home/index';
import { LoginComponent } from './login/index';
import { Register1Component } from './register1/index';
import { QuizsummaryComponent } from './quizsummary/index';
import {QuizsummaryService } from './quizsummary/quizsummary.service';
import { ProfileComponent } from './profile/index';
import { FlexLayoutModule } from "@angular/flex-layout";
import { from } from 'rxjs/observable/from';
import { DialogModule } from 'primeng/primeng';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { MatButtonModule, MatIconModule, MatInputModule, MatSelectModule, MatSliderModule,
        MatToolbarModule, MatSnackBarModule, MatCardModule, MatSlideToggleModule, MatDatepickerModule,MatNativeDateModule} from "@angular/material";
 import {MatExpansionModule} from '@angular/material/expansion';
 import {MatTabsModule} from '@angular/material/tabs';
 import {MatListModule} from '@angular/material/list';
 import {FieldsetModule} from 'primeng/fieldset';
 import {PanelModule} from 'primeng/panel';
 import {RadioButtonModule} from 'primeng/radiobutton';
 import {PaginatorModule} from 'primeng/paginator';
 import 'angular2-navigate-with-data';
 import {LandComponent } from './land/index';
 import { IncompleteComponent} from './incomplete/index';
 import { IncompleteService} from './incomplete/incomplete.service';
 import {ProgressSpinnerModule} from 'primeng/progressspinner';
import { DashbordComponent} from './dashbord/index';
import { PaypalComponent } from './paypal/index';
import { DashbordService} from './dashbord/dashbord.service';
import { ServiceWorkerModule } from '@angular/service-worker';
import 'hammerjs';
import { ChartsModule } from 'ng2-charts';
import {ChartModule} from 'primeng/chart';
import {ImageZoomModule} from 'angular2-image-zoom';
import { LessonComponent} from './lesson/index';
import { LessonService} from './lesson/lesson.service';
import { LessonDetailsComponent} from './lessonDetails/index';
import { LessonDetailsService} from './lessonDetails/lessonDetails.service';
import { LdetailsComponent} from './ldetails/index';
import { LdetailsService} from './ldetails/ldetails.service';
import { ProfileService} from './profile/profile.service';

@NgModule({
    imports: [
        BrowserModule,
        ChartsModule,
        ChartModule,
        ImageZoomModule,
        MatListModule,
        PaginatorModule,
        RadioButtonModule,
        MatTabsModule,
        MatExpansionModule,
        BrowserAnimationsModule,
        MatButtonModule,
         MatIconModule, 
         MatInputModule, 
         DialogModule,
         MatSelectModule, 
         MatSliderModule,
         MatToolbarModule,
         MatCardModule,
         MatDatepickerModule,
          MatSlideToggleModule,
          MatNativeDateModule,
        FormsModule,
        FieldsetModule,
        HttpClientModule,
        PanelModule,
        HttpModule,
        FlexLayoutModule,        
        ReactiveFormsModule,
        routing,
        ProgressSpinnerModule,
        MatSnackBarModule,
        ServiceWorkerModule
        
        
    ],
    declarations: [
        AppComponent,
        AlertComponent,
        HomeComponent,
        LoginComponent,
        QuizsummaryComponent,
        ClaimsComponent,
        Register1Component,
        QuizdetailsComponent,
        ProfileComponent,
        LandComponent,
        IncompleteComponent,
        DashbordComponent,
        PaypalComponent,
        LessonComponent,
        LessonDetailsComponent,
        LdetailsComponent
     
       
       


    ],
    providers: [
        AuthGuard,
        AlertService,       
        UserService,
        Register1Service,        
        LoginService,
        HomeService ,
        QuizsummaryService,
        ClaimsService,
        QuizdetailsService,
        PagerService,
        HelperService,
        IncompleteService,
        DashbordService,
        LessonService,
        LessonDetailsService,
        LdetailsService,
        LessonPagerService,
        ProfileService,

        {
            provide: HTTP_INTERCEPTORS,
            useClass: JwtInterceptor,
            multi: true
        },

        // provider used to create fake backend
        fakeBackendProvider
    ],
    bootstrap: [AppComponent]
})

export class AppModule { }