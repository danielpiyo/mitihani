export class Questions {
  
   sqh_id: Number;
   quiz_number : Number;
   subject_code : String;
   class_level_code  : String;
   start_datetime  : Date;
   captured_date: Date;
   
    
    
}


  