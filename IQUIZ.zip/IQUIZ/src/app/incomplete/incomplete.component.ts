﻿import { Component, OnInit } from '@angular/core';
import { IncompleteService } from './incomplete.service';
import { User } from '../_models/index';
import { UserService, PagerService } from '../_services/index';
import { Observable } from 'rxjs/Observable';
import { Questions } from './incomplete';
import { Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { QuizsummaryService } from '../quizsummary/quizsummary.service';
import { AnswerModel } from '../quizsummary/answerModel';
import { HelperService } from '../_services/helper.service';
import { Option, Question, Quiz, QuizConfig } from '../_models/index';
import { AlertService } from '../_services/index';
import { SubbmitModel } from '../quizsummary/submitModel';
import { MyAnswerModel } from '../quizsummary/myAnswer';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { AnswerTypeModel } from '../quizsummary/answerTypeModel';



@Component({
    moduleId: module.id.toString(),
    selector: 'incomplete.component',
    templateUrl: 'incomplete.component.html',
    providers: [IncompleteService]
})
     
   
export class IncompleteComponent implements OnInit {

    apiUrl: string = "https://www.api.cloudplace.org:4000/api/submit";
    quickSubbmit: SubbmitModel = new SubbmitModel();
    quickMyanswer: MyAnswerModel = new MyAnswerModel()
    indexed: Number;
    correctAnswer: any;
    correctAnswerId: any;
    public smartQuestion = [];
    ////////////////////
    //////////////////
    quizes: any[];
    quiz: Quiz = new Quiz(null);
    mode: string = 'incomplete';
    config: QuizConfig = {
        'allowBack': true,
        'allowReview': true,
        'autoMove': false,  // if true, it will move to next question automatically when answered.
        'duration': 0,  // indicates the time in which quiz needs to be completed. 0 means unlimited.
        'pageSize': 1,
        'requiredAll': false,  // indicates if you must answer all the questions before submitting.
        'richText': false,
        'shuffleQuestions': false,
        'shuffleOptions': false,
        'showClock': false,
        'showPager': true,
        'theme': 'none'
    };
    results: any;
    myAnswer: boolean;
    loading = false;
    pager = {
        index: 0,
        size: 1,
        count: 1
    };
    toggleMenu = false;
    ///////////////////////
    questions: Questions[];
    selectedPolicy: Questions = new Questions();
    myPolicy: Observable<Question[]>;
    policy: Question;
    errorMessage: String;
    dataAvailableById = true;
    //  policies: Observable<any[]>;
    currentUser: User;
    users: User[] = [];
    //  cust_code :String;
    sqhId: any;

    incompletePager: any = {};
    
    // paged items
    incompletePagedItems: any[];
    correctTypedAnswer: any;
    quickAnswerType: AnswerTypeModel = new AnswerTypeModel();
    
    constructor(
      private pagerService: PagerService,
        private _http: Http,
        private _quizSummaryService: QuizsummaryService,
        private router: Router,
        private alertService: AlertService,
        private _incompleteService: IncompleteService,
        private userService: UserService) {
        this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
        //this.cust_code=localStorage.getItem('cust_code')
    }

       myTime: Number;
             
    ngOnInit() {
      this.myTime = Date.now();
        this.loadAllUsers();
        this.getQuestions();
    }


////////////////
///////////////// Setting Paged items for Incomplete quiz

setPage(page: number) {
  if (page < 1 || page > this.incompletePager.totalPages) {
      return;
  }

  // get pager object from service
  this.incompletePager = this.pagerService.getPager(this.questions.length, page);

  // get current page of items
  this.incompletePagedItems = this.questions.slice(this.incompletePager.startIndex, this.incompletePager.endIndex + 1);
}

//Moving to next list of incomplete quiz
    NextIncomplete(){
      this.mode = 'incomplete';
    }

    onToggleMenu(){
        if(this.toggleMenu === true){
            this.toggleMenu = false;
        }
        else{
            this.toggleMenu = true;
        }
    }

    // All incomplete Quiz
    getQuestions() {
        //   debugger  
        // console.log('this.currentUser',this.currentUser);
         this._incompleteService.getQuestions(this.currentUser.entity_sys_id)
         .subscribe((response)=>{
          this.questions = response;
        //  console.log('Incomplete', response);
          this.setPage(1);
         },
        (error) =>{
          alert(error.message);
          this.router.navigate(['/home']);
        })
        
    }

    private loadAllUsers() {
        this.userService.getAll().subscribe(users => { this.users = users; });
    }

    onSelect(sqh_id: any) {
        console.log('SqhId', sqh_id);
        this._quizSummaryService.getQuestion(sqh_id)
            .subscribe((response) => {

                this.quiz = new Quiz(response);
             //   console.log('Response', this.quiz);
                this.pager.count = this.quiz.questions.length;
             //   console.log('Incomplete', response);
            },
                ((error) => {
                    console.log('IncompleteError', error);
                    alert(error.message);
                }))
       
             this.sqhId = sqh_id;
             this.mode= 'quiz';
        
    }

    get filteredQuestions() {
        return (this.quiz.questions) ?
          this.smartQuestion = this.quiz.questions.slice(this.pager.index, this.pager.index + this.pager.size) : [];
      }
    
      onSelection(question: Question, option: Option) {
        if (question.questionTypeId === 1) {
          question.options.forEach((x) => {
            if (x.id !== option.id) x.selected = false; x.isAnswer;
            if (x.selected != false) {
              if (String(x.selected) == x.isAnswer) {
                this.myAnswer = true;
               console.log('Answer right');
    
              }
              else {
                this.myAnswer = false;
             console.log('Answer wrong');
              }
            //  this.quickSubbmit.P_STUDENT_CHECKED_ANSWER = String(this.myAnswer);
              this.quickSubbmit.P_ANSWER_ID = x.id;
              this.quickSubbmit.P_SQQ_ID = question.id;
              this.quickSubbmit.P_QUESTION_SYS_ID = x.questionId;
    
              this._quizSummaryService.answerUpdate(this.quickSubbmit)
                .subscribe((response) => {
                 // this.alertService.success('You selected: ' + String(x.id))
                },
                  error => {
                    this.alertService.error(error.message);
                  });
           //   console.log('quickSubbmit', this.quickSubbmit);
    
            //  console.log(x.id, x.questionId, question.id);
           //  console.log('selected', x.selected)
            //  console.log('this.myAnswer', this.myAnswer);
            }
          });
    
        }
    
        if (this.config.autoMove) {
          this.goTo(this.pager.index + 1);
        }
      }
    

      goTo(index: number) {
        if (index >= 0 && index < this.pager.count) {
          this.pager.index = index;
          this.mode = 'quiz';
        }
      }
    
      isAnswered(index) {
        this.indexed = index
        return this.quiz.questions[index].options.find((x) => x.selected) ? 'Answered' : 'Not Answered';
    
      };
    
///////////////////////
//////////////////////////// On typing the answere
onTypedAnswer(question: Question) {
  this.quickAnswerType.P_SQQ_ID = question.id;
  this.quickAnswerType.P_TYPED_ANSWER = question.typedAnswered;
  this._quizSummaryService.typedAnswerUpdate(this.quickAnswerType)
  .subscribe((response) =>{
   // alert('Good');
  },
  (error) =>{
    alert(error.message);
  }
)
//  console.log('QuickAnswerType', this.quickAnswerType);
 
}


      /////Kiswahili
   isSawa(question: Question) {
    return question.options.every((x) => String(x.selected) == x.isAnswer) ? 'sawa' : 'umenowa'
  
  };
  
  ////kiswali right response
  isSawaAnswer(question: Question) {
    let correct1;
    correct1 = question.options.find((x) => x.isAnswer == 'true')
    this.correctAnswer = correct1.id +". " + correct1.name;
  //console.log('Answer1', this.correctAnswer);
    return this.correctAnswer
  };


/////correct typed answer checking
isCorrectTypedAnswer(question: Question) {
  return question.typedAnswered == question.actual_answer ? 'correct' : 'wrong'

};

////correct typed answer confirmed
isCorrectTypedAnswerRight(question: Question) {

this.correctTypedAnswer = question.actual_answer;
//console.log('Answer1', this.correctAnswer);
return this.correctTypedAnswer
};

      isCorrect(question: Question) {
        return question.options.every((x) => String(x.selected) == x.isAnswer) ? 'correct' : 'wrong'
    
      };
    
      isCorrectAnswer(question: Question) {
        let correct1;
        correct1 = question.options.find((x) => x.isAnswer == 'true')
        this.correctAnswer = correct1.id +". " + correct1.name;
      //console.log('Answer1', this.correctAnswer);
        return this.correctAnswer
      };
    
    
      onSubmit() {
        let answers = [];
        let answerObject = {};
        this.quiz.questions.forEach(x => { answers.push({ 'SQH_ID': this.quiz.id, 'SQQ_ID': x.id, 'Answered': x.answered, 'MyAnsweres': this.myAnswer }) });
      //  console.log('Answers', answers);
        answerObject = Object.assign({}, answers);
      // console.log('AnswerOblect', answerObject);
        this.loading = true;
        this.quickMyanswer.SQH_ID = this.quiz.id;
        let summeryObject;
        summeryObject = Object.assign(this.quickMyanswer)
      //  console.log('QuickMyanswer', summeryObject);
        this._http.post(this.apiUrl, summeryObject)
          .subscribe((response) => {
            //this.alertService.success('Quiz submitted succesfully')
            alert('Quiz submitted succesfully');
          },
            (error) => {
              //this.alertService.error(error.message)
              alert(error.message);
              this.loading = false;
            })
            
        // Post your data to the server here. answers contains the questionId and the users' answer.
      //  console.log('quiz.questionsID', this.quiz.questions);
    
        this.mode = 'result';
        if(this.mode = 'result'){
          this._quizSummaryService.getResults(this.quiz.id)
        .subscribe((response) =>{
          this.results = response
        //  console.log('ResultsAfter',response);
        },
      (error)=>{
        alert(error.message)
        console.log('ResultsError',error);
         });
      
        }
      }
    
      display: boolean = false;
    
      showDialog() {
        this.display = true;
      }
     
      getResults(){
        this._quizSummaryService.getResults(this.quiz.id)
        .subscribe((response) =>{
          this.results = response
         // console.log('ResultsAfter',response);
        },
      (error)=>{
        alert(error.message)
        console.log('ResultsError',error);
      })
      }

      logout() {
        // remove user from local storage to log user out
        localStorage.removeItem('currentUser');
        this.router.navigate(['/']);
    }

    goToLessons(){
      this.router.navigate(['/lesson']);
  }

attempNew(){ 
          this.mode='incomplete';
          }
}   
