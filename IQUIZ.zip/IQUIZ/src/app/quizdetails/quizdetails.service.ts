import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { User } from '../_models/index';
import { Observable } from 'rxjs/Observable';
import {  Subject } from 'rxjs/Subject';  
import 'rxjs'; //get everything from Rx  
import 'rxjs/add/operator/toPromise';  
import 'rxjs/add/observable/forkJoin';

@Injectable()
export class QuizdetailsService {
//apiUrl: string = "http://173.255.200.221:4000/api/question";// Web API URL
apiUrl: string = "https://www.api.cloudplace.org:4000/api/question";// Web API URL
apiUrl1: string = "https://www.api.cloudplace.org:4000/api/answer/";// Web API URL
//apiUrl2: string = "http://173.255.200.221:4000/api/answerss";// Web API URL
apiUrl2: string = "https://www.api.cloudplace.org:4000/api/questionsAnswers";// Web API URL

private static quizDetails:any;
sqqId : Number;

constructor(private _http: Http) { }  

getQuestion(sqh_id:any){  
    return this._http.get(this.apiUrl + "/" + sqh_id)
    .map((res: Response) => res.json()[0].BODY) 
    .catch((error: any) => Observable.throw(error.json() || 'Server error'));  
    }  


    getQuiz():any{
       // console.log('this.quizDetails2',localStorage.getItem('QuizdetailsService.quizDetails'));
        return   JSON.parse(localStorage.getItem('QuizdetailsService.quizDetails'));
       }

    setQuiz(quiz:any){

        QuizdetailsService.quizDetails=quiz;
       // console.log('this.quizDetails',QuizdetailsService.quizDetails);
        localStorage.setItem('QuizdetailsService.quizDetails',JSON.stringify(quiz));
        
     
    }
     getAnswers(sqq_id:any){
         return this._http.get(this.apiUrl1 + sqq_id)
         .map((res: Response) => res.json())  
         .catch((error: any) => Observable.throw(error.json() || 'Server error'));  
     }

      getQuestionss(sqh_id:any){  
        return this._http.get(this.apiUrl2 + "/" + sqh_id)
        .map((res: Response) => res.json().questionslist) 
        .catch((error: any) => Observable.throw(error.json() || 'Server error'));  
        }  
    } 

    

