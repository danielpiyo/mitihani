export class Details{
    ACTIVE_FROM_DATE: Date;
    ACTIVE_TO_DATE: Date;
    ACTIVE_YN: String;
    CLASS_LEVEL_CODE: String;
    CREATED_BY: String;
    CREATED_DATE: Date;
    PREPARED_BY: String;
    PREPARED_DATE: Date;
    QH_ID: Number;
    QUIZ_DESCRIPTION: String;
    QUIZ_NUMBER: Number;
    SUBJECT_CODE: String;
    POINTS_BALANCE: Number;
}