﻿export * from './quizdetails.component';
