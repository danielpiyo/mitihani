﻿import { Component } from '@angular/core';
import { QuizdetailsService } from './quizdetails.service'; 
import { UserService, PagerService } from '../_services/index'; 
import { Router } from '@angular/router';
import { User } from '../_models/index';
import { Observable } from 'rxjs/Observable';
import { Exam } from '../_models/exam';
import { Subscription } from 'rxjs/Subscription';
import { QuoteModel} from '../home/quoteModel';
import { HomeService} from '../home/home.service';
import { AlertService } from '../_services/index';
import { QuizsummaryService} from '../quizsummary/quizsummary.service';
import { Details} from './examDetails';


@Component({  
moduleId: module.id.toString(),  
selector: 'quizdetails.component',  
templateUrl: 'quizdetails.component.html',  
providers: [QuizdetailsService]  
})  

export class QuizdetailsComponent {  
    benefits: any;
    risk: any;
  //quickUpload : UploadModel = new UploadModel(); //upload object
    //quickExam : Observable<Details[]>;
    quickExam : Details[];
    public question = [];
    public answer ={};
    question1 = []; 
 
    allAnswers: Observable<any[]>;
    currentExam : Exam;
    currentUser: User;
        users: User[] = [];  
 
    sqqId: Number;
     public lastQuestion = [];
    public lastAnswer = [];
    Users = [];
    quickQuote: QuoteModel = new QuoteModel();
    quizNumber: String;
    startQuizSubscription : Subscription;
    subjectCode: String;
    tokenBalance = {}
    mode = 'normal';

    detailsPager: any = {};
    
    // paged items
    detailsPagedItems: any[];
    toggleMenu: boolean= false;

    constructor(
        private pagerService: PagerService,
        private quizsummaryService: QuizsummaryService,
        private _homeService : HomeService,
        private alertService: AlertService,
        private router: Router,
        private _quizdetailsService: QuizdetailsService,
        private userService: UserService) 
        { 
            
             this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
           //  this.currentExam = JSON.parse(localStorage.getItem('currentExam'));
            
        }
           quiz2:any;

        ngOnInit() {  
           
           this.getAllquiz();

            this.quiz2 = JSON.parse(localStorage.getItem('1'));

            //this.quiz2 = this.router.getNavigatedData(); ///Using routernavigate by data component.
            
           // console.log('Quiz2',this.quiz2);
          
        }

        onToggleMenu(){
            if(this.toggleMenu === true){
                this.toggleMenu = false;
            }
            else{
                this.toggleMenu = true;
            }
        }

////////////////
///////////////// Setting Paged items for details quiz

setPage(page: number) {
    if (page < 1 || page > this.detailsPager.totalPages) {
        return;
    }
  
    // get pager object from service
    this.detailsPager = this.pagerService.getPager(this.quickExam.length, page);
  
    // get current page of items
    this.detailsPagedItems = this.quickExam.slice(this.detailsPager.startIndex, this.detailsPager.endIndex + 1);
  }

        startQuiz(quiz_number: any, point_balance: any){
            console.log('POINTBALANCE', point_balance);
            if(point_balance < 5 ){
                alert('You have run out of points. Please click OK to proceed to the purchases page.')
               this.router.navigate(['/land']);
            }
            else{
              // console.log('quiz_number', quiz_number);
            this.quizNumber = quiz_number;
            this.quickQuote.entity_sys_id = this.currentUser.entity_sys_id;
            this.quickQuote.class_level_code = this.quiz2;
            this.quickQuote.subject_code = this.subjectCode;
            this.quickQuote.quiz_number = this.quizNumber;
            console.log('SelectedNumber', this.quizNumber);
       console.log('QuickQuote', this.quickQuote);
       this.startQuizSubscription = this._homeService.startQuiz(this.quickQuote)
       .subscribe(
           (response) => {
           console.log('Data Results', response);
         //  this.alertService.success('Quiz Starts successful', true);
         alert('Quiz Started succesfully. Click OK to proceed');
           this.quizsummaryService.setQuiz(JSON.parse(response._body).user)
            this.router.navigate(['/start']);
          // console.log('body', response._body);
       },     
       (error) => {
        //this.alertService.error(error.message);
        alert('Sorry' + '_' + this.currentUser.surname + '_' + 'Looks like there is a problem with the quiz selected. Please click Ok to report the Error.');
        //this.mode ='error';
       // this.router.navigate(['/land']);
         console.log('error', error);
    })

            }
          
        }
  
    getAllquiz(){
        this.quickExam = this._quizdetailsService.getQuiz()
        this.setPage(1);
       this.tokenBalance = this.quickExam[0].POINTS_BALANCE
        console.log('AllQuiz',this.quickExam);
      }
    
      passSubject(subject_code:any){
          //console.log('Subject_code', subject_code);
          this.subjectCode = subject_code;
      }

      backToSubject(){
          this.router.navigate(['/subject']);
      }    


      logout() {
        // remove user from local storage to log user out
        localStorage.removeItem('currentUser');
        this.router.navigate(['/']);
    }
      
    goToLessons(){
       // this.router.navigate(['/lesson']);
       window.location.href = "https://www.lesson.cloudplace.org";
    }

 }