﻿import { Component, OnInit, AfterViewChecked } from '@angular/core';
import { User } from '../_models/index';
import { UserService } from '../_services/index';
import { Router, ActivatedRoute } from '@angular/router';


declare let paypal : any;

@Component({
    moduleId: module.id.toString(),
    templateUrl: 'paypal.component.html',
   
})

export class PaypalComponent  {
    currentUser: User;
    users: User[] = [];
   

    constructor(
           private userService: UserService,
           private router: Router, 
           private route: ActivatedRoute
        ) {
        this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
    }
}





        
        