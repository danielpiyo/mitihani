import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { User } from '../_models/index';
import { Observable } from 'rxjs/Observable';
import {  Subject } from 'rxjs/Subject';  
import 'rxjs'; //get everything from Rx  
import 'rxjs/add/operator/toPromise';  
import 'rxjs/add/observable/forkJoin';
import { LessonModel } from './lessonModel';

@Injectable()
export class LdetailsService {
//apiUrl: string = "http://173.255.200.221:4000/api/question";// Web API URL
apiUrl2: string = "https://www.api.cloudplace.org:4000/api/exam";// Web API URL
apiUrl: string = "https://www.api.cloudplace.org:4000/api/lessonstart/";// Web API URL
apiUrl1: string = "https://www.api.cloudplace.org:4000/api/lessonquizno/";// Web API URL
//apiUrl2: string = "https://iquiz.quizmasters.org:4000/api/lessonnarration/";// Web API URL

private static lessonDetails:any;
sqqId : Number;

constructor(private _http: Http) { }  
 
       getAllLessonsNarration(LSH_ID: any){
           return this._http.get(this.apiUrl + LSH_ID)
           .map(res => res.text().length > 0 ? res.json() : null)
           .catch((error:any)=> Observable.throw(error.json() || 'Server Error'));
       }
       

    getQuiz():any{
       // console.log('this.lessonDetails2',localStorage.getItem('LdetailsService.lessonDetails'));
        return   JSON.parse(localStorage.getItem('LdetailsService.lessonDetails'));
       }

    setQuiz(lesson:any){

        LdetailsService.lessonDetails=lesson;
      //  console.log('this.lessonDetails',LdetailsService.lessonDetails);
        localStorage.setItem('LdetailsService.lessonDetails',JSON.stringify(lesson));
      
    }

   getQuizNumbers(qh_id: any){
       return this._http.get(this.apiUrl1 + qh_id)
       .map(res => res.text().length > 0 ? res.json() : null)
       .catch((error:any)=> Observable.throw(error.json() || 'Server Error'));
   }
   startQuiz(lessonModel: LessonModel) {
    return this._http.post(this.apiUrl2, lessonModel)      
    .catch((error: any) => Observable.throw(error.json() || 'Server error'));  
}

 } 

    

