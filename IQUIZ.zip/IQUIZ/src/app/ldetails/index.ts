﻿export * from './ldetails.component';
