﻿import { Component } from '@angular/core';
import { LdetailsService } from './ldetails.service';
import { UserService, LessonPagerService } from '../_services/index';
import { Router } from '@angular/router';
import { User } from '../_models/index';
import { Observable } from 'rxjs/Observable';
import { Exam } from '../_models/exam';
import { Subscription } from 'rxjs/Subscription';
import { LessonModel } from './lessonModel';
import { QuizsummaryService } from '../quizsummary/quizsummary.service';
import { HomeService } from '../home/home.service';
import { AlertService } from '../_services/index';
import { QuizConfig, Lesson, Head, Option } from '../_models/index';
import { Details } from './details';


@Component({
  moduleId: module.id.toString(),
  selector: 'ldetails.component',
  templateUrl: 'ldetails.component.html',
  providers: [LdetailsService]
})

export class LdetailsComponent {

  //quickUpload : UploadModel = new UploadModel(); //upload object
  ///quickExam : Observable<Details[]>;
  quickLesson: LessonModel = new LessonModel();
  quickExam = [];
  public lessons = [];
  public lessonNarration = [];
  public lessonTopic = [];
  currentUser: User;
  users: User[] = [];
  startQuizSubscription: Subscription;
  subjectCode: String;
  mode: string = 'details'
  public smartLesson = [];
  lessonId: any;
  topicName: string;
  lessonQuizNo: any;
  toggleMenu = false;
  paged1Items: any[]

  pager = {
    index: 0,
    size: 1,
    count: 1
  };

  //////complicated be keen
  head: Head = new Head(null);

  config: QuizConfig = {
    'allowBack': true,
    'allowReview': true,
    'autoMove': false,  // if true, it will move to next question automatically when answered.
    'duration': 0,  // indicates the time in which quiz needs to be completed. 0 means unlimited.
    'pageSize': 1,
    'requiredAll': false,  // indicates if you must answer all the questions before submitting.
    'richText': false,
    'shuffleQuestions': false,
    'shuffleOptions': false,
    'showClock': false,
    'showPager': true,
    'theme': 'none'
  };



  constructor(
    private quizsummaryService: QuizsummaryService,
    private alertService: AlertService,
    private router: Router,
    private _ldetailsService: LdetailsService,
    private userService: UserService) {

    this.currentUser = JSON.parse(localStorage.getItem('currentUser'));

  }
  lesson2: any;

  ngOnInit() {
    this.lesson2 = this._ldetailsService.getQuiz()
    //  console.log('Lesson2', this.lesson2);
    //  this.lesson2 = JSON.parse(localStorage.getItem('lesson1'));

  }



  onToggleMenu() {
    if (this.toggleMenu === true) {
      this.toggleMenu = false;
    }
    else {
      this.toggleMenu = true;
    }
  }


  startLesson(lsh_id: any) {
    console.log('LSHID', lsh_id);
    this._ldetailsService.getAllLessonsNarration(lsh_id)
      .subscribe((res) => {
        //  console.log('AllInOne', res);
        this.head = new Head(res);
        //  console.log('Head', this.head);
        this.pager.count = this.head.lessons.length;
        this.paged1Items = this.head.lessons;
        //console.log('Lesson', this.head.lsh_id);
        this.lessonId = this.head.quiz_qh_id;
        this.topicName = this.head.lesson_description;
        this.mode = 'narration';

      })
  }


  get filteredLessons() {

    return (this.head.lessons) ?
      // this.smartLesson = this.lessonNarration.slice(this.pager.index, this.pager.index + this.pager.size) : [];
      this.smartLesson = this.head.lessons.slice(this.pager.index, this.pager.index + this.pager.size) : [];
  }


  goTo(index: number) {
    console.log('Index', index);
    if (index >= 0 && index < this.pager.count) {
      this.pager.index = index;
      //this.mode = 'details';
    }
  }

  startQuiz(lessonId: any) {
    console.log('LessonId', lessonId);
    this.quickLesson.class_level_code = this.lessonQuizNo.CLASS_LEVEL_CODE;
    this.quickLesson.entity_sys_id = this.currentUser.entity_sys_id;
    this.quickLesson.quiz_number = this.lessonQuizNo.QUIZ_NUMBER;
    this.quickLesson.subject_code = this.lessonQuizNo.SUBJECT_CODE;

    // console.log('QuickLesson', this.quickLesson);
    this._ldetailsService.startQuiz(this.quickLesson)
      .subscribe((res) => {
        // console.log('StartedQuiz', res);
        alert('Quiz Started succesfully. Click OK to proceed');
        this.quizsummaryService.setQuiz(JSON.parse(res._body).user)
        this.router.navigate(['/start']);
        // console.log('body', res._body);
      },
        (error) => {
          this.alertService.error(error.message);
          this.router.navigate(['/land']);
          console.log('error', error);
        })

  }

  getQuizNo(qh_id: any) {
    console.log('QH_ID', qh_id);
    this._ldetailsService.getQuizNumbers(qh_id)
      .subscribe((response) => {
        // console.log('QUIZNUMBERS', Object.assign({}, response[0]));
        this.lessonQuizNo = response[0];
        //console.log('LessonQuizNo', this.lessonQuizNo);
      },
    (error)=>{
      alert(error.message);
    })

  }

  logout() {
    localStorage.removeItem('currentUser')
    this.router.navigate(['/']);
  }

}