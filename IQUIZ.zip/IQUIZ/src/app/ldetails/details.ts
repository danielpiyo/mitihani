export class Details{
    ACTIVE_FROM_DATE: Date;
    ACTIVE_TO_DATE: Date;
    ACTIVE_YN: String;
    CLASS_LEVEL_CODE: String;
    CREATED_BY: String;
    CREATED_DATE: Date;
    PREPARED_BY: String;
    PREPARED_DATE: Date;
    LQH_ID: Number;
    LESSON_DESCRIPTION: String;
    LESSON_SERIAL_NO: Number;
    SUBJECT_CODE: String;
    LESSON_SUMMARY:String;

}