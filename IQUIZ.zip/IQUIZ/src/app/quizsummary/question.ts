export class Questions{

   // entity_sys_id: Number;
   // question_narration: String;
   // question_number: Number;
   // question_sys_id: Number;
   // several_possible_answers_yn: String;
   // sqh_id: Number;
   // sqq_id: Number;
  
    sqq_id: Number;
    question_sys_id: Number;
    question_narration:String;
    answers: [
      {
        answer_id:Number;
        answer_narration: String;
      }
    ]
 

}