export class SummModel {
    
    control_no: String;
    quote_no: String;
    CLASS: Number;
    trans_type: String;
    sum_insured: Number;
    lc_pol_net_premium: Number;
    lc_pol_admin_fee: Number;
    fc_pol_sgf_amount: Number
    tax: Number;
    total_premium: Number;
    period_from: Date;
    perio_to: Date;
    cover_days: Number;
    client_number: Number;
    insured: String;
    currency_code: String;
}