export class SubbmitModel {
     P_SQQ_ID: Number;
     P_ANSWER_ID: Number;
     P_QUESTION_SYS_ID:Number;
     P_STUDENT_CHECKED_ANSWER:String;
}