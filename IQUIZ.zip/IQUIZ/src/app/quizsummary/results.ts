export class Results{
    constructor(
        CORRECT_ANSWERS:'number',
        PERFORMANCE_GRADE:'string',
        TOTAL_QUIZ_QUESTIONS:'number'
    )
    {}
}