export class Quizs {
    SQQ_ID: Number;
    SQH_ID: Number;
    ENTITY_SYS_ID: Number;
    QUESTION_SYS_ID: Number;
    QUESTION_NARRATION: String;
    SEVERAL_POSSIBLE_ANSWERS_YN: String;
    QUESTION_NUMBER: Number;
   


}
