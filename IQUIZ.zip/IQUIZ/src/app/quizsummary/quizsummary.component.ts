﻿import { Component } from '@angular/core';
import { QuizsummaryService } from './quizsummary.service';
import { UserService } from '../_services/index';
import { Router } from '@angular/router';
import { User } from '../_models/index';
import { Quizs } from './quote';
import { Observable } from 'rxjs/Observable';
import { SummModel } from './summModel';
import { Exam } from '../_models/exam';
import { Subscription } from 'rxjs/Subscription';
import { Questions } from './question';
import { PagerService } from '../_services/index'
import { AnswerModel } from './answerModel';
import { HelperService } from '../_services/helper.service';
import { Option, Question, Quiz, QuizConfig } from '../_models/index';
import { AlertService } from '../_services/index';
import { SubbmitModel } from './submitModel';
import { AnswerTypeModel } from './answerTypeModel';
import { MyAnswerModel } from './myAnswer';
import { Http, Headers, RequestOptions, Response } from '@angular/http';

@Component({
  moduleId: module.id.toString(),
  selector: 'quizsummary.component',
  templateUrl: 'quizsummary.component.html',
  providers: [QuizsummaryService]
})

export class QuizsummaryComponent {
  apiUrl: string = "https://www.api.cloudplace.org:4000/api/submit";
  benefits: any;
  risk: any;
  //quickUpload : UploadModel = new UploadModel(); //upload object
  quickExam: Exam = new Exam();
  quickSubbmit: SubbmitModel = new SubbmitModel();
  quickAnswerType: AnswerTypeModel = new AnswerTypeModel();
  quickMyanswer: MyAnswerModel = new MyAnswerModel()
  public smartQuestion = [];
  currentExam: Exam;
  currentUser: User;
  users: User[] = [];
  Users = [];
  indexed: Number;
  correctAnswer: any;
  correctTypedAnswer: any;
  correctSecondaryAnswer: any;
  correctAnswerId: any;
  numberSpace : any;
  ////////////////////
  //////////////////
  quizes: any[];
  quiz: Quiz = new Quiz(null);
  mode: string = 'quiz';
  config: QuizConfig = {
    'allowBack': true,
    'allowReview': true,
    'autoMove': false,  // if true, it will move to next question automatically when answered.
    'duration': 0,  // indicates the time in which quiz needs to be completed. 0 means unlimited.
    'pageSize': 1,
    'requiredAll': false,  // indicates if you must answer all the questions before submitting.
    'richText': false,
    'shuffleQuestions': false,
    'shuffleOptions': false,
    'showClock': false,
    'showPager': true,
    'theme': 'none'
  };
  results :any;
  myAnswer: boolean;
  loading = false;
  pager = {
    index: 0,
    size: 1,
    count: 1
  };

  ////////////////////
  /////////////////////
  constructor(
    private _http: Http,
    private pagerService: PagerService,
    private router: Router,
    private alertService: AlertService,
    private _quizsummaryService: QuizsummaryService,
    private userService: UserService) {

    this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
    //  this.currentExam = JSON.parse(localStorage.getItem('currentExam'));

  }

  // pager object
  pager1: any = {};

  // paged items
  pagedItems: any[];
  paged1Items: any[];
  wewe: any[];
  toggleMenu = false;
  
  myTime : number;
  ngOnInit() {
    this.numberSpace = this.pager.index + 1 + '.)'
    this.quickExam = this._quizsummaryService.getQuiz();
   // console.log('model', this.quickExam);
    this.getQuestion();
    this.myTime = Date.now();

  //console.log('Description',this.quiz.description);
  
  }

  onToggleMenu(){
    if(this.toggleMenu === true){
        this.toggleMenu = false;
    }
    else{
        this.toggleMenu = true;
    }
}

  //////////////////////
  //////////////////////
  getQuestion() {
    this._quizsummaryService.getQuestion(this.quickExam.sqh_id)
    .subscribe(res => {
      this.quiz = new Quiz(res);
     // console.log('Response', this.quiz);
   //   console.log('Description', this.quiz.id)
      this.pager.count = this.quiz.questions.length;
      this.paged1Items = this.quiz.questions;
      console.log('Description',this.quiz.description);
    // console.log('Paged1Item', this.paged1Items[0].options);
    // console.log('AnswerNarration', this.paged1Items[0].answer_narration);
    // console.log('quiz.description', this.quiz.description)
     
    },
  (error)=>{
    alert(error.message);
  });
  }
  //////////////////////////
  ////////////////////////
  get filteredQuestions(): any {
    return (this.quiz.questions) ?
      this.smartQuestion = this.quiz.questions.slice(this.pager.index, this.pager.index + this.pager.size) : [];
  }

  onSelect(question: Question, option: Option) {
    if (question.questionTypeId === 1) {
      question.options.forEach((x) => {
        if (x.id !== option.id) x.selected = false; x.isAnswer;
        if (x.selected != false) {
          if (String(x.selected) == x.isAnswer) {
            this.myAnswer = true;
         //  console.log('Answer right');

          }
          else {
            this.myAnswer = false;
       //  console.log('Answer wrong');
          }
          this.quickSubbmit.P_STUDENT_CHECKED_ANSWER = String(this.myAnswer);
          this.quickSubbmit.P_ANSWER_ID = x.id;
          this.quickSubbmit.P_SQQ_ID = question.id;
          this.quickSubbmit.P_QUESTION_SYS_ID = x.questionId;

          this._quizsummaryService.answerUpdate(this.quickSubbmit)
            .subscribe((response) => {
            //  this.alertService.success('You selected: ' + String(x.id))
            },
              error => {
                this.alertService.error(error.message )
              });
       //   console.log('quickSubbmit', this.quickSubbmit);

       //  console.log(x.id, x.questionId, question.id);
        // console.log('selected', x.selected)
       //   console.log('this.myAnswer', this.myAnswer);
        }
      });

    }

    if (this.config.autoMove) {
      this.goTo(this.pager.index + 1);
    }
  }

///////////////////////
//////////////////////////// On typing the answere
onTypedAnswer(question: Question) {
  this.quickAnswerType.P_SQQ_ID = question.id;
  this.quickAnswerType.P_TYPED_ANSWER = question.typedAnswered;
  this._quizsummaryService.typedAnswerUpdate(this.quickAnswerType)
  .subscribe((response) =>{
   // alert('Good');
  },
  (error) =>{
    alert(error.message);
  }
)
//  console.log('QuickAnswerType', this.quickAnswerType);
 
}


  goTo(index: number) {
    if (index >= 0 && index < this.pager.count) {
      this.pager.index = index;
      this.mode = 'quiz';
    }
  }

  isAnswered(index) {
    this.indexed = index
    return this.quiz.questions[index].options.find((x) => x.selected) ? 'Answered' : 'Not Answered';

  };
/////Kiswahili
   isSawa(question: Question) {
  return question.options.every((x) => String(x.selected) == x.isAnswer) ? 'sawa' : 'umenowa'

};

////kiswali right response
isSawaAnswer(question: Question) {
  let correct1;
  correct1 = question.options.find((x) => x.isAnswer == 'true')
  this.correctAnswer = correct1.id +". " + correct1.name;
//console.log('Answer1', this.correctAnswer);
  return this.correctAnswer
};

  isCorrect(question: Question) {
    return question.options.every((x) => String(x.selected) == x.isAnswer) ? 'correct' : 'wrong'

  };
/////correct typed answer checking
  isCorrectTypedAnswer(question: Question) {
    return question.typedAnswered == question.actual_answer ? 'correct' : 'wrong'

  };

////correct typed answer confirmed
isCorrectTypedAnswerRight(question: Question) {

  this.correctTypedAnswer = question.actual_answer;
//console.log('Answer1', this.correctAnswer);
  return this.correctTypedAnswer
};


  isCorrectAnswer(question: Question) {
    let correct1;
    correct1 = question.options.find((x) => x.isAnswer == 'true')
    this.correctAnswer = correct1.id +". " + correct1.name;
  //console.log('Answer1', this.correctAnswer);
    return this.correctAnswer
  };

  isCorrectAnswerSecondary(question: Question) {
    let correctSecondary;
    correctSecondary = question.options.find((x) => x.isAnswer == 'true')
    this.correctSecondaryAnswer =  correctSecondary.name;
    //console.log('Answer1', this.correctAnswer);
    return this.correctSecondaryAnswer;
  };



  onSubmit() {

    //alert('Want to submit Quiz?');
    let answers = [];
    let answerObject = {};
    this.quiz.questions.forEach(x => { answers.push({ 'SQH_ID': this.quiz.id, 'SQQ_ID': x.id, 'Answered': x.answered, 'MyAnsweres': this.myAnswer }) });
    // console.log('Answers', answers);
    answerObject = Object.assign({}, answers);
    // console.log('AnswerOblect', answerObject);
    this.loading = true;
    this.quickMyanswer.SQH_ID = this.quiz.id;
    let summeryObject;
    summeryObject = Object.assign(this.quickMyanswer)
     //console.log('QuickMyanswer', this.quickMyanswer.SQH_ID);
    this._http.post(this.apiUrl, this.quickMyanswer)
      .subscribe((response) => {
       // this.alertService.success('Quiz submitted succesfully')
       // alert('Quiz Submitted. To view result,c lick on Display result button.')
      },
        (error) => {
         // this.alertService.error(error)
         alert(error.message);
          this.loading = false;
        })
        
    // Post your data to the server here. answers contains the questionId and the users' answer.
    //console.log('quiz.questionsID', this.quiz.questions);

    this.mode = 'result';
   
  }

  display: boolean = false;

  showDialog() {
    this.display = true;
  }
 
  getResults(){
    this._quizsummaryService.getResults(this.quiz.id)
    .subscribe((response) =>{
      this.results = response
    //  console.log('ResultsAfter',response);
    },
  (error)=>{
    alert(error.message)
    console.log('ResultsError',error);
  })
  }
  
  logout(){
    localStorage.removeItem('currentUser')
    this.router.navigate(['/']);
  }

  goToLessons(){
    //this.router.navigate(['/lesson']);
    window.location.href = "https://www.lesson.cloudplace.org"
}

attempNew()
{ 
  this.router.navigate(['/home']);
}

}