export class AnswerTypeModel {
    P_SQQ_ID: Number;
    P_TYPED_ANSWER: String;
   
}
