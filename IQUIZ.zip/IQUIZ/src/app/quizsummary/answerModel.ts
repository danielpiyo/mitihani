export class AnswerModel {
    answer_id: Number;
}