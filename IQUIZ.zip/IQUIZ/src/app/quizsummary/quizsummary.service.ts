import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { User } from '../_models/index';
import { Observable } from 'rxjs/Observable';
import {  Subject } from 'rxjs/Subject';  
import 'rxjs'; //get everything from Rx  
import 'rxjs/add/operator/toPromise';  
import { Quizs } from './quote';
import 'rxjs/add/observable/forkJoin';
import { SubbmitModel} from './submitModel';
import { AnswerTypeModel } from './answerTypeModel';
import { MyAnswerModel} from './myAnswer';
import { Results } from './results';



@Injectable()
export class QuizsummaryService {
//apiUrl: string = "http://173.255.200.221:4000/api/question";// Web API URL
apiUrl: string = "https://api.cloudplace.org:4000/api/question";// Web API URL
apiUrl1: string = "https://api.cloudplace.org:4000/api/answer/";// Web API URL
//apiUrl2: string = "http://173.255.200.221:4000/api/answerss";// Web API URL
apiUrl2: string = "https://www.api.cloudplace.org:4000/api/questionsAnswers";// Web API URL
apiUrl3: string = "https://www.api.cloudplace.org:4000/api/questionsiquiz"; //updating the quiz upon selection
apiUrl7: string = "https://www.api.cloudplace.org:4000/api/updatetype"; ///updating typed answers
apiUrl4: string = "https://www.api.cloudplace.org:4000/api/updatepro/";
apiUrl5: string = "https://www.api.cloudplace.org:4000/api/submit"; // Submitting the quiz upon complition
apiUrl6: string = "https://www.api.cloudplace.org:4000/api/result/"; // Getting results upon submision
private static quizSummary:any;
sqqId : Number;

constructor(private _http: Http) { }  

    getQuiz():any{
       // console.log('this.quizSummary2',localStorage.getItem('QuizsummaryService.quizSummary'));
        return   JSON.parse(localStorage.getItem('QuizsummaryService.quizSummary'));
       }

    setQuiz(quote:any){

        QuizsummaryService.quizSummary=quote;
       // console.log('this.quizSummary',QuizsummaryService.quizSummary);
        localStorage.setItem('QuizsummaryService.quizSummary',JSON.stringify(quote));
        
     
    }
        
     
        getQuestion(sqh_id:any) {
            return this._http.get(this.apiUrl3 + "/" + sqh_id)
            .map(res => res.text().length > 0 ? res.json() : null)
            .catch((error:any)=> Observable.throw(error.json() || 'Server Error'));
          }

     /* answerUpdate(submitModel:SubbmitModel){
          return this._http.put(this.apiUrl4, submitModel)
          .map((res) =>res.json())
          .catch((error:any)=> Observable.throw(error.json().error || 'Server Error'));
      }*/

///////////updating the database upon answerclick
      answerUpdate(submitModel:SubbmitModel){
        return this._http.post(this.apiUrl4, submitModel)
        
    }


///////////////// Updating the database upon answertype
    typedAnswerUpdate(answerTypeModel:AnswerTypeModel){
        return this._http.post(this.apiUrl7, answerTypeModel);
        
    }
      
      submitAnswer(myAnswer:MyAnswerModel){
           return this._http.post(this.apiUrl5, myAnswer)
           .map((res) => res.json())
           .catch((error:any) => Observable.throw(error.JSON() || 'Server Error'));
      }

      getResults(sqh_id:any):Observable<Results>{
    return this._http.get(this.apiUrl6 + sqh_id)
    .map((res) => res.json())
    .catch((error:any) => Observable.throw(error.JSON() || 'Server Error'));
      }
    } 

    

