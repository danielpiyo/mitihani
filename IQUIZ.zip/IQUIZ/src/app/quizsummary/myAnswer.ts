export class MyAnswerModel{
   
        SQH_ID: Number;
    
}