﻿import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './home/index';
import { LoginComponent } from './login/index';
import { Register1Component } from './register1/index';
import { ClaimsComponent } from './claims/index';
import { QuizsummaryComponent} from './quizsummary/index';
import { QuizdetailsComponent} from './quizdetails/index';
import { AuthGuard } from './_guards/index';
import { ProfileComponent} from './profile/index';
import { LandComponent} from './land/index';
import { IncompleteComponent } from './incomplete/index'
import { DashbordComponent} from './dashbord/index';
import { PaypalComponent } from  './paypal/index';
import { LessonComponent} from './lesson/index';
import { LessonDetailsComponent} from './lessonDetails/index';
import { LdetailsComponent } from './ldetails/index';


const appRoutes: Routes = [
    
    { path: '', component: HomeComponent },
    { path: 'start', component: QuizsummaryComponent, canActivate: [AuthGuard] },
    { path: 'details', component: QuizdetailsComponent, canActivate: [AuthGuard] },
    { path: 'profile', component: ProfileComponent, canActivate: [AuthGuard] },
    { path: 'land', component: LandComponent, canActivate: [AuthGuard] },
    { path: 'paypal', component: PaypalComponent, canActivate: [AuthGuard] },
    { path: 'quiz', component: IncompleteComponent, canActivate: [AuthGuard] },
    { path: 'home', component: DashbordComponent, canActivate: [AuthGuard] },
    //{ path: 'l-details', component: LdetailsComponent, canActivate: [AuthGuard] },
    { path: 'subject', component: ClaimsComponent , canActivate: [AuthGuard]},
   // { path: 'lesson', component: LessonComponent},
    //{ path: 'lesdetails', component: LessonDetailsComponent},

    { path: 'login', component: LoginComponent },
    { path: 'signup', component: Register1Component },


    // otherwise redirect to home
    { path: '**', redirectTo: '' }
];

export const routing = RouterModule.forRoot(appRoutes,  {useHash: true}); 