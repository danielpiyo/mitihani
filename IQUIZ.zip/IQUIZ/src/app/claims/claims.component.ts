import { Component } from '@angular/core';  
import { ClaimsService } from './claims.service';  
import { User } from '../_models/index';
import { UserService } from '../_services/index';
import { AlertService } from '../_services/index';
import { Router } from '@angular/router';
import{ HomeComponent } from '../home/home.component';
import { Observable } from 'rxjs/Observable';  
import { Subscription } from 'rxjs/Subscription';
import { HomeService} from '../home/home.service';
import { ActivatedRoute, Params } from '@angular/router';
import { QuoteModel} from '../home/quoteModel';
import { QuizsummaryService} from '../quizsummary/quizsummary.service';
import { QuizdetailsService } from '../quizdetails/quizdetails.service';

@Component({  
moduleId: module.id.toString(),  
selector: 'claims.component',  
templateUrl: 'claims.component.html',  
providers: [ClaimsService]  
})  

export class ClaimsComponent {
   
    currentUser: User;
    subjectCode: String;
    users: User[] = [];
    testSubject = [];
    allQuiz = [];
    test : String;
    quickQuote: QuoteModel = new QuoteModel();
    quizNumber: String;
    startQuizSubscription : Subscription;
  toggleMenu: boolean =false;


    constructor(
        private _quizdetailsService : QuizdetailsService,
        private quizsummaryService: QuizsummaryService,
        private _homeService : HomeService,
        private routes: ActivatedRoute,
        private router: Router,
        private _claimsService: ClaimsService,
        private alertService: AlertService) 
       { 
        this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
      
       }

     //  quiz1 :any;
       quizToken: any;
      
       ngOnInit() {           
           this.testSubject = this._claimsService.getQuiz();
         // this.quiz1 = this.router.getNavigatedData();
          this.quizToken  = JSON.parse(localStorage.getItem('1'));
          console.log('QuizToken', this.quizToken);
         //  console.log('Wanted', this.testSubject);
          
        }
    
        onToggleMenu(){
          if(this.toggleMenu === true){
              this.toggleMenu = false;
          }
          else{
              this.toggleMenu = true;
          }
      }
        
        goToQuiz(subject_code:any, subject:any){
           // console.log('Selected Subject', subject_code)
            this.test = this.currentUser.entity_sys_id + '/' + this.quizToken  + "/" + subject_code
            console.log('SubjectCode', this.test);  
            this.subjectCode = subject_code;  
           this._homeService.getTest(this.test)
           .subscribe(
               (response) =>{
            this.allQuiz = response;
            this._quizdetailsService.setQuiz(JSON.parse(JSON.stringify(response)))
           ////////////////////

           this.router.navigate(['/details']);
           /*this.router.navigateByData({
            url: ['/details'],
            data: this.quizToken, //data - <any> type            
            //extras: {} - <NavigationExtras> type, optional parameter
        });  */
          
           // console.log('Quiz', this.allQuiz);
           },     
           (error) => {
            this.alertService.error(error.message);
             console.log('error', error);
        }
        );
          }
  
          startQuiz(quiz_number: any){
            this.quizNumber = quiz_number;
            this.quickQuote.entity_sys_id = this.currentUser.entity_sys_id;
            this.quickQuote.class_level_code = this.quizToken;
            this.quickQuote.subject_code = this.subjectCode;
            this.quickQuote.quiz_number = this.quizNumber;
            console.log('QuizNumber', this.quizNumber);
     //  console.log('QuickQuote', this.quickQuote);
       this.startQuizSubscription = this._homeService.startQuiz(this.quickQuote)
       .subscribe(
           (response) => {
         //  console.log('Data Results', response);
           this.alertService.success('Quiz Starts successful', true);
           this.quizsummaryService.setQuiz(JSON.parse(response._body).user)
         //  this.router.navigate(['/login']);
          // console.log('body', response._body);
       },     
       (error) => {
        this.alertService.error(error.message);
         console.log('error', error);
    })
        }
  
        backToClass(){
          this.router.navigate(['/home']);
        }

        logout() {
          // remove user from local storage to log user out
          localStorage.removeItem('currentUser');
          this.router.navigate(['/']);
      }
        
      goToLessons(){
         // this.router.navigate(['/lesson']);
         window.location.href = "https://www.lesson.cloudplace.org";
      }
  
}  

