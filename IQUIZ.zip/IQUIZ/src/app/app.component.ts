﻿import { Component } from '@angular/core';
//import { ClaimsComponent } from './claims/claims.component'
import './rxjs-operators';
import { MatSnackBar } from '@angular/material';
import '../assets/app.css';
import { Directive } from '@angular/core/src/metadata/directives';
import { COMMON_DIRECTIVES } from '@angular/common/src/directives';
import { NgModule } from '@angular/core';
import { NgServiceWorker } from '@angular/service-worker';

@Component({
    moduleId: module.id.toString(),
    selector: 'app',
    templateUrl: 'app.component.html'


})


//@NgModule({
//   declarations: <any>[ ClaimsComponent]

//})
export class AppComponent {

     insyncYear : number;

    constructor(private snackBar: MatSnackBar,
        private ngsw: NgServiceWorker
    ) { }

    updateNetworkStatusUI() {
        ////check if its online or offline to change the UI
        if (navigator.onLine) {
            //// you are online
            (document.querySelector("body") as any).style = "";
        }
        else {
            /// 100% sure you are offline
           
            (document.querySelector("body") as any).style = "filter:grayscale(1)";
            this.snackBar.open("Please Check your connection", "OK", {duration:10000});
          
        }

    }

    ngOnInit() {
        ////////////copyright year
        
        this.insyncYear = (new Date()).getFullYear();

         // Checking SW Update Status
    this.ngsw.push.subscribe(update => {
        if (update.type == 'pending') {
          const sb = this.snackBar.open("There is an update available", "Install Now", {duration: 4000});
          sb.onAction().subscribe( () => {
            (this.ngsw as any).activateUpdate(update.version).subscribe(event => {
              console.log("The App was updated");
              location.reload();
            })
          });
          
        }
      });
      this.ngsw.checkForUpdate();

        this.updateNetworkStatusUI();
        window.addEventListener("online", this.updateNetworkStatusUI);/// changing UI when moving from offline to online
        window.addEventListener("offline", this.updateNetworkStatusUI); /// chaning UI when moving from online to offline
        ////// to check whether we are using an browser or stand alone
        if ((navigator as any).standalone == false) {
            /// its an ios device and we are on the browser
            this.snackBar.open("Want to add IQUIZ as an APP", "", { duration: 4000 })
        }

        if ((navigator as any).standalone == undefined) {
            /// its not an ios
            if (window.matchMedia("display-mode: browser").matches) {
                ////this is a browser
                window.addEventListener("beforeinstallprompt", event => {
                    event.preventDefault();
                    const sb = this.snackBar.open("Doyou want to insatll this App?", "Install", { duration: 5000 });
                    sb.onAction().subscribe(() => {
                        (event as any).prompt();
                        (event as any).userChoice.then(result => {
                            if (result.outCome == "dismised") {
                                ///for tracking it was not installed
                            }
                            else {
                                ///tracking it was installed
                            }
                        });
                    });
                    return false;
                })
            }
        }

    }



}




