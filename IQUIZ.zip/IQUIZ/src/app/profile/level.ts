export class LevelCode {
    CLASS_LEVEL_CODE: string;
}