import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map'
import { Subject } from 'rxjs/Subject';  
import 'rxjs'; //get everything from Rx  
import 'rxjs/add/operator/toPromise';  
import 'rxjs/add/operator/catch';
import 'rxjs/add/observable/throw';


@Injectable()

export class ProfileService {

    apiUrl: string = "https://www.api.cloudplace.org:4000/api/iquizPerfom/"; // list of class levels
    apiUrl1: string ="https://www.api.cloudplace.org:4000/api/iquizGraph/";// Results per subject
    apiUrl2: string ="https://www.api.cloudplace.org:4000/api/yourResultIquiz/";  //All result

    constructor(private http: Http) { }
    

    getAvailableClass(entity_id: any){
         return this.http.get(this.apiUrl + entity_id)
         .map((res)=> res.json())
         .catch((error:any)=> Observable.throw(error.json() || 'Serve Error'));
    }
   
    getAnalysis(class_level_code: any, entity_id: any){
           return this.http.get(this.apiUrl1 + class_level_code + '/' + entity_id)
           .map((res)=> res.json())
           .catch((error: any)=> Observable.throw(error.json() || 'Servr error'));
    }

    getAllResult(entity_id:any){
            return this.http.get(this.apiUrl2 + entity_id)
            .map((res)=> res.json())
            .catch((error:any)=> Observable.throw(error.json() || 'Server Error'));
    }
    
}