﻿import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { LoginService } from '../login/login.service';
import { User } from '../_models/index';
import { Subscription } from 'rxjs/Subscription';
import { ProfileService } from './profile.service';
import { LevelCode} from './level';
import { Observable } from 'rxjs';

@Component({
    moduleId: module.id.toString(),
    templateUrl: 'profile.component.html',
    providers: [ProfileService]
})

export class ProfileComponent implements OnInit {
    currentUser: User;
    users: User[] = [];
    usersSubscription: Subscription;
    toggleMenu = false;
    myTime: number;
    //availableClass: string[];
    availableClass: LevelCode = new LevelCode();
    analysisBrought = [];
    selectedClass: any;
    mode : any;
    allYourResult = [];
   

    constructor(private loginService: LoginService,
        private profileService: ProfileService,
        private router: Router,
    ) {
        this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
       
    }

    ngOnInit() {
        this.getAvailableCalss();
        this.myTime = Date.now();
    }

    onToggleMenu() {
        if (this.toggleMenu === true) {
            this.toggleMenu = false;
        }
        else {
            this.toggleMenu = true;
        }
    }

///////////

/////////graph trial

/*
public barChartOptions:any = {
    scaleShowVerticalLines: false,
    responsive: true
  };
  public barChartLabels:string[] = ['2006', '2007', '2008', '2009', '2010', '2011', '2012'];
  public barChartType:string = 'bar';
  public barChartLegend:boolean = true;
 
  public barChartData:any[] = [
    {data: [65, 59, 80, 81, 56, 55, 40], label: 'Series A'},
    {data: [28, 48, 40, 19, 86, 27, 90], label: 'Series B'}
  ];
 
  // events
  public chartClicked(e:any):void {
    console.log(e);
  }
 
  public chartHovered(e:any):void {
    console.log(e);
  }*/
 
 /* public randomize():void {
    // Only Change 3 values
    let data = [
      Math.round(Math.random() * 100),
      59,
      80,
      (Math.random() * 100),
      56,
      (Math.random() * 100),
      40];
    let clone = JSON.parse(JSON.stringify(this.barChartData));
    clone[0].data = data;
    this.barChartData = clone;
    /**
     * (My guess), for Angular to recognize the change in the dataset
     * it has to change the dataset variable directly,
     * so one way around it, is to clone the data, change it and then
     * assign it;
     */
//} 

//////////////////
    getAvailableCalss() {
        this.profileService.getAvailableClass(this.currentUser.entity_sys_id)
            .subscribe((response) => {
                this.availableClass = response;
                let classObject = {}
                classObject = Object.assign({}, this.availableClass)
                console.log('AvailableClasses',classObject );
            },
                (error) => {
                    alert(error.message);
                });
    }

    goAnalysis(level_code: any){
        this.selectedClass = level_code;
        console.log('SelectedClassLevel', level_code);
        this.profileService.getAnalysis(level_code, this.currentUser.entity_sys_id)
        .subscribe((response) =>{
            this.analysisBrought = response;
            this.mode = 'performance'
            console.log('Analysis', this.analysisBrought);
           
        },
    (error)=>{
        alert(error.message);
    });
    }

getAllResults(){
    this.profileService.getAllResult(this.currentUser.entity_sys_id)
    .subscribe((response)=>{
        this.allYourResult = response;
        console.log('AllYourResult', this.allYourResult);
        this.mode = 'allresults';
    },
(error)=>{
    alert(error.message);
});
}
    



    ngonDestroy() {
        if (this.usersSubscription) {
            this.usersSubscription.unsubscribe();
        }
    }

    logout() {
        this.loginService.logout()
        this.router.navigate(['/']);
    }



}