﻿export * from './profile.component';
