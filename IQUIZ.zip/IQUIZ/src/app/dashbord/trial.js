///////////////////////
///////////////// Trying Iquiz procidure start exams

//quickQuote API
router.post('/exams', function (req, res,db,quoteData) {

    quoteData =  {
        p_entity_sys_id :'1',
        p_class_level_code :'PRIMARY8',
        p_subject_code:'CRE',
        p_quiz_number : '1',   //set as default
        p_sqh_id :0,
       
    }

    oracledb.getConnection(connAttrs, function (err, connection) {
        if (err) {
            // Error connecting to DB
            res.set('Content-Type', 'application/json');
            res.status(500).send(JSON.stringify({
                status: 500,
                message: "Error connecting to DB",
                detailed_message: err.message
            }));
            return;
        }
//TO_DATE(:P6_HIREDATE,'MM/DD/YYYY')

            var plsql = "begin " +
                "     IQUIZ.GENERATE_STUDENT_QUIZ (:p_entity_sys_id , :p_class_level_code, :p_subject_code ,:p_quiz_number,:p_sqh_id); " +
                "        end; ";
             // console.log('plsql', plsql);
            var bindvars = {
                p_entity_sys_id: req.body.entity_sys_id,
                p_class_level_code:req.body.code_id,
                p_subject_code : req.body.subject_code,
                p_quiz_number :req.body.quiz_number,
             
                p_sqh_id:{ type: db.number, dir: db.bind_out }
            };
            connection.execute(
                plsql,
                bindvars,
                function(err, result){
                   // console.log('compute_prem: ',result);
                    if (err) {
                        console.error(err.message);
						if (connection)   dbConfig.doRelease(connection);
                        res.status(500);
						res.json({error: err.message});
                        return;
                    }

                    quoteData.p_sqh_id=result.outBinds.p_sqh_id;

                    var timetaken=Date.now()-req.startTime;
				//	dbConfig.fetchRCFromStream(req,res,connection, result.outBinds.p_curs_quote);
                   // dbConfig.PromiseRCFromStream(connection, result.outBinds.p_curs_quote)

                   // res.json({data:quoteData,time:timetaken});
                });

        }); //end db.getConnection

});  //end quickQuote API function

//end quickQuote API

