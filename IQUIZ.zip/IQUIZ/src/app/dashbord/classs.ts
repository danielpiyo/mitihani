export class Classs {
    CODE_ID: String;
    CODE_DESCRIPTION: String;
    CODE_HINT_1:String;
    CODE_SEQUENCE: Number;

}