export class QuoteModel {
    
    entity_sys_id :Number;
    subject_code :String;
    quiz_number:Number;
    class_level_code :String;
    //sqh_id :Number=0;
}

