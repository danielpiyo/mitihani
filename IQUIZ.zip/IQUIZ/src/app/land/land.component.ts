﻿import { Component, OnInit, AfterViewChecked } from '@angular/core';
import { User } from '../_models/index';
import { UserService } from '../_services/index';
import { Router, ActivatedRoute } from '@angular/router';
import { Type } from './transaction';
//import { promise } from 'selenium-webdriver';
//import { Type } from './transaction';


@Component({
    moduleId: module.id.toString(),
    templateUrl: 'land.component.html',
   
})

export class LandComponent implements OnInit {
    currentUser: User;
    users: User[] = [];
    model: any = {};
   // selectedType: Type = new Type(<any>0);
   selectId : any;
    types = []
    selected : boolean;
    mode: string = 'payement';
    loading = false;

    constructor(
           private userService: UserService,
           private router: Router, 
           private route: ActivatedRoute
        ) {
        this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
    }

   ngOnInit(){
     console.log('EntityId', this.currentUser.entity_sys_id);
   this.types = [
        {"id":1, "name":"Mpesa", "image": "../assets/Mpesa.jpg", "selected": this.selected},
        {"id":2, "name":"Paypal", "image":"../assets/PayPal.jpg", "selected": this.selected}
    ]
   }
      
  

    goToDetails(){
        this.router.navigate(['/details']);
    }

    sendTransaction(){
        console.log('Transaction Sent' )
    }
   
    onSelect(id: any){
        console.log(id);
        this.selectId = id;
        console.log('selectedId', this.selectId);
        this.mode = 'selected';
    }
 
    back(){
        this.mode = 'payement';
    }

///// paypal stuff

 
}
