export class Type {
    id: number;
    name: string;
    image: string    
    selected: boolean;
    
    constructor(data: any) {
        data = data || {};
        this.id = data.id;
        this.image = data.image;
        this.name = data.name;
        
    }
}