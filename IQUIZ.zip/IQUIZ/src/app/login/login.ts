export class User {
    cust_code: String;
    username: String;
    password: String;
    
}
