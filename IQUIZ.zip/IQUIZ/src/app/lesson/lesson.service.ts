import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions, Response } from '@angular/http';
import { User } from '../_models/index';
import { Observable } from 'rxjs/Observable';
import { Subject } from 'rxjs/Subject';
import 'rxjs'; //get everything from Rx  
import 'rxjs/add/operator/toPromise';
import { Classs } from './classs';
import { QuoteModel} from './quoteModel';

@Injectable()

export class LessonService {

    apiUrl: string = "https://www.api.cloudplace.org:4000/api/classiquiz/";// Web API URL
    apiUrl1: string = "https://www.api.cloudplace.org:4000/api/classiquizdet/"
    apiUrl2: string = "https://www.api.cloudplace.org:4000/api/lesssubj/"
    apiUrl5: string = "https://www.api.cloudplace.org:4000/api/iquizlesson/"
    apiUrl6: string =  "https://www.api.cloudplace.org:4000/api/exam";

    constructor(private _http: Http) { }




    getClassLevel() {
        return this._http.get(this.apiUrl)
            .map((response) => response.json())
            .catch((error: any) => Observable.throw(error.json() || 'Server error'));           
    }

    getClassDetails(code_id: any):Observable<any[]> {
        return this._http.get(this.apiUrl1 + code_id)
            .map((response) => response.json())
            .catch((error: any) => Observable.throw(error.json() || 'Server error'));  
    }

    getSubjects(code_id: any) {
        return this._http.get(this.apiUrl2 + code_id)
            .map((response) => response.json())
            .catch((error: any) => Observable.throw(error.json() || 'Server error'));  
    }

    getTest(quiz:any){
        return this._http.get(this.apiUrl5 + quiz )
        .map((response) => response.json())
        .catch((error: any) => Observable.throw(error.json() || 'Sorry your have lost your Token. kindly start the process Again')); 
       }

       startQuiz(QuoteModel: QuoteModel) {
        return this._http.post(this.apiUrl6, QuoteModel)      
        .catch((error: any) => Observable.throw(error.json() || 'Server error'));  
    }
  
}

