﻿import { Component, OnInit, OnDestroy, Output, EventEmitter } from '@angular/core';
import { User, Level } from '../_models/index';
import { UserService } from '../_services/index';
import { Subscription } from 'rxjs/Subscription';
import { LessonService } from './lesson.service';
import { Classs } from './classs';
import { AlertService } from '../_services/index';
import { QuoteModel} from './quoteModel';
import { Router, NavigationExtras } from '@angular/router';
import { QuizsummaryService } from '../quizsummary/quizsummary.service';
import { ClaimsService}  from '../claims/claims.service';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA} from '@angular/material';


@Component({
    moduleId: module.id.toString(),
    templateUrl: 'lesson.component.html',
   
})

export class LessonComponent implements OnInit {  
     toggleMenu = false;
    currentUser: User;
    iquizClassLevels : Level;
    users: User[] = [];
    allClassLevel = [];    
    classDetails = [];
    allSubjects = [];
    //allQuiz = [];
    subjectSubscription : Subscription;
    classDetailsSubscription: Subscription;
    startQuizSubscription : Subscription;
    selectedClass : Classs = new Classs();
    loading = true;
    test: string;
    codeId: String;
    subjectCode: String;
    quizNumber: Number;
    quickQuote: QuoteModel = new QuoteModel();
    
   // @Output() quizEvent = new EventEmitter<String>();

    constructor(
        
        public dialog: MatDialog,
        private _claimsService : ClaimsService,
        private router: Router,
        private quizsummaryService :QuizsummaryService,
        private alertService: AlertService,
        private _lessonService : LessonService,
        private userService: UserService) 
        {
        this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
        this.iquizClassLevels = JSON.parse(localStorage.getItem('iquizClassLevels'));
      
    }

    ngOnInit() {
       // this.loadAllUsers();
        this.getClasses();

    }    


    onToggleMenu(){
        if(this.toggleMenu === true){
            this.toggleMenu = false;
        }
        else{
            this.toggleMenu = true;
        }
    }
    
  
    getClasses(){
        this._lessonService.getClassLevel()
        .subscribe((response) =>{
          this.allClassLevel = response;
        //  console.log('response', response);
          localStorage.setItem('iquizClassLevels', JSON.stringify(response));
        },
    (error) =>{
        alert(error.message);
    });
    }
 
    goToClassDetailsPage(code_id:any){
        console.log('CODE_ID', code_id); 
            this.classDetailsSubscription = this._lessonService.getClassDetails(code_id)
            .subscribe((data) => {
             this.classDetails = data;
           //  console.log('data', this.classDetails);
          
            },
        (error) =>{
            alert(error.message);
        })
           
     
    
      }

      goToSubjectPage(code_id:any){
        console.log('code_id', code_id);
        this.codeId = code_id;
        //let foo = this.codeId;
       this.subjectSubscription = this._lessonService.getSubjects(code_id)
        .subscribe(
            (response) =>{
          this.allSubjects = response;
         // console.log('AllSubjects', this.allSubjects);
          ///////
          localStorage.setItem('lesson1', JSON.stringify(this.codeId));
          ////////////
          this.router.navigate(['/lesdetails']);
          
        /*  this.router.navigateByData({
            url: ['/subject'],
            data: this.codeId, //data - <any> type
            //extras: {} - <NavigationExtras> type, optional parameter
        });   */    
 
          this._claimsService.setQuiz(JSON.parse(JSON.stringify(response)))
       //  this.router.navigate(['/claims',this.codeId] );
        },
           (error) => {
            this.alertService.error(error.message);
             console.log('error', error);
        });
      }

      ngonDestroy() {
        if (this.classDetailsSubscription && this.subjectSubscription) {
            this.subjectSubscription.unsubscribe();
        }
    }

    goToSignup(){
        this.router.navigate(['/signup']);
    }
    goToLogin(){
        this.router.navigate(['/login']);
    }


    }
